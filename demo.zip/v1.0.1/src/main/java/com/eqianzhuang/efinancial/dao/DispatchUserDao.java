package com.eqianzhuang.efinancial.dao;

public interface DispatchUserDao {

    void setDispatchUser(String openId);

    boolean isDispatchUser(String openid);

    void deleteDispatchUser(String openId);

    void clearDispatchUser();
}
