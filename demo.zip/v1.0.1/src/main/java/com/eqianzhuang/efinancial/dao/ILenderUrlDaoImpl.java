package com.eqianzhuang.efinancial.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chenbing
 * @since 2.2.4
 * @create_date 2017年8月1日 上午9:41:41
 */
@Repository
public class ILenderUrlDaoImpl implements ILenderUrlDao {


    @Autowired
    JdbcTemplate jdbcTemplate;

	@Override
	public String get(int id) {
        try {
            return jdbcTemplate.queryForObject("select url from credit_cpa.v3_lender_url where id = ? limit 1 ",String.class, id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
	}

}
