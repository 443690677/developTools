package com.eqianzhuang.efinancial.ai.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.SendProdLinkUtil;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.service.AdditionalDataService;
import com.eqianzhuang.efinancial.ai.service.MsgReceiveService;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.QLoanBindWXDAO;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 微信公众号平台功能相关控制器
 * @author chenbing
 *
 */
@RequestMapping(value = "/efinancial/ai")
@RestController
public class MsgReceiveController
{
	
	private static Log logger = LogFactory.getLog(MsgReceiveController.class);
	
	@Autowired
	private MsgReceiveService MsgReceiveService;
	
	@Autowired
	private QLoanBindWXDAO QLoanBindWXDAO;
	
	@Autowired
	private IWechatListConfigDao iWechatListConfigDao;
	
	@Autowired
	private UserStatusDao userStatusDao;
	
	@Autowired
	private RedisClient redisClient;
	
	@Autowired
	private AIWorker aIWorker;
	
	@Autowired
	private KeFuMsgUtil keFuMsgUtil;
	
	@Autowired
	private SendProdLinkUtil sendProdLinkUtil;
	
	@Autowired
	private WeChatConfig weChatConfig;
	
	@Autowired
	private WeiXinUserInfoUtil weiXinUserInfoUtil;

	@Autowired
	private AdditionalDataService additionalDataService;


	// 用于接收微信消息
	@RequestMapping(value = "/xmlMsgReceive",method = RequestMethod.POST,produces = {"text/plain;charset=UTF-8"})
	public String xmlMsgReceive(HttpServletRequest req)
	{
		Map<String,String> processRequestXml = processRequestXml(req);
		MsgReceiveService.receiveWeiXinMsg(processRequestXml);
		return "";
	}
	
	// 用于验证微信服务器
	@RequestMapping(value = "/xmlMsgReceive",method = RequestMethod.GET)
	public String authService(@RequestParam("echostr") String echostr)
	{
		return echostr;
	}


	/**
	 * 线上产品申请
	 */
	@RequestMapping(value = "/to-online",method = RequestMethod.GET)
	public String redirectOnline(HttpServletRequest request,@RequestParam("openid") String openid,@RequestParam("channel") String channel,@RequestParam("lenderId") String lenderId,@RequestParam("groupId") String groupId,
	        @RequestParam("urlId") String urlId)
	{
		additionalDataService.parseRequest(openid,request);
		HashMap<String,Object> dataMap = MsgReceiveService.applyOnline(openid,channel,lenderId,groupId,urlId,false);
		
		if(Integer.valueOf(0).equals(dataMap.get("resultCode")))
		{
			return "<script>window.location.href = '" + dataMap.get("url") + "'</script>";
		} else
		{
			return "<script>alert('您可以选择其他产品!')</script>";
		}
	}
	
	/**
	 * 根据wxcode获取openId
	 * @param wxcode 微信code
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/load-openid",method = RequestMethod.GET)
	public String productApply( @CookieValue( name = "efinancial_access_cookie",required = false) String cookieOpenid , @RequestParam("wxcode") String wxcode, HttpServletRequest request,HttpServletResponse httpServletResponse)
	{

        String openid = "";
        logger.info(cookieOpenid);
        if (StringUtils.isEmpty(cookieOpenid)||cookieOpenid.length() != 28) {
            String domain2 = request.getServerName();
            JSONObject jsonObject = weiXinUserInfoUtil.htmlLogin(wxcode, domain2);
            logger.info("根据wxcode获取openId jsonObject = " + jsonObject);
            openid = jsonObject.getString("openid");
            logger.info("根据wxcode获取openId openid = " + openid);
            Cookie cookie= new Cookie("efinancial_access_cookie", openid);
            cookie.setDomain(domain2);
            httpServletResponse.addCookie(cookie);

        }else {
            openid = cookieOpenid;
        }

		additionalDataService.parseRequest(openid,request);
		return openid;
	}
	
	@RequestMapping(value = "/reply",method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
	public Map getReply()
	{
		HashMap<String,Object> result = new HashMap<>();
		result.put("code","0");
		result.put("message","success");
		HashMap<String,Object> reply = new HashMap<>();
		Class uRLConstant = URLConstant.class;
		Field[] fields = URLConstant.class.getDeclaredFields();
		
		for(int i = 0;i < fields.length;i++ )
		{
			Field field = fields[i];
			String key = weChatConfig.getConstantKeyPrefix() + field.getName();
			
			if("java.lang.String".equals(field.getGenericType().getTypeName()))
			{
				try
				{
					reply.put(key,field.get(uRLConstant));
				} catch(IllegalAccessException e)
				{
					e.printStackTrace();
				}
			}
			
			if("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName()))
			{
				try
				{
					reply.put(key,field.get(uRLConstant));
				} catch(IllegalAccessException e)
				{
					e.printStackTrace();
				}
			}
			
			if("com.alibaba.fastjson.JSONArray".equals(field.getGenericType().getTypeName()))
			{
				try
				{
					reply.put(key,field.get(uRLConstant));
				} catch(IllegalAccessException e)
				{
					e.printStackTrace();
				}
			}
		}
		
		result.put("reply",reply);
		return result;
	}
	
	@RequestMapping(value = "/reply",method = RequestMethod.PUT,produces = {"application/json;charset=UTF-8"})
	public Map setReply(@RequestBody JSONObject reply)
	{
		Class uRLConstant = URLConstant.class;
		Field[] fields = URLConstant.class.getDeclaredFields();
		for(int i = 0;i < fields.length;i++ )
		{
			Field field = fields[i];
			String key = weChatConfig.getConstantKeyPrefix() + field.getName();
			String fieldsValue = reply.getString(key);
			if(!StringUtils.isEmpty(fieldsValue))
			{
				if("java.lang.String".equals(fields[i].getGenericType().getTypeName()))
				{
					try
					{
						field.set(uRLConstant,fieldsValue);
						redisClient.set(key,fieldsValue);
					} catch(IllegalAccessException e)
					{
						e.printStackTrace();
					}
				}
				
				if("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName()))
				{
					try
					{
						field.set(uRLConstant,reply.getJSONObject(key));
						redisClient.set(key,reply.getJSONObject(key));
					} catch(IllegalAccessException e)
					{
						e.printStackTrace();
					}
				}
				
				if("com.alibaba.fastjson.JSONArray".equals(field.getGenericType().getTypeName()))
				{
					try
					{
						field.set(uRLConstant,reply.getJSONArray(key));
						redisClient.set(key,reply.getJSONArray(key));
					} catch(IllegalAccessException e)
					{
						e.printStackTrace();
					}
				}
				
			}else if ("".equals(fieldsValue)){
                redisClient.del(key);
            }
		}
		
		HashMap<String,Object> result = new HashMap<>();
		result.put("code","0");
		result.put("message","success");
		result.put("reply",getReply());
		
		return result;
	}
	
	@RequestMapping(value = "/offlineProd/apply",method = RequestMethod.POST,produces = {"application/json;charset=UTF-8"})
	public ResponseEntity<Map<String,Object>> offlineProdApply(@RequestBody JSONObject userInfo,HttpServletRequest request)
	{


		String name = userInfo.getString("name");
		String mobile = userInfo.getString("mobile");
		String openId = userInfo.getString("openId");
		String lenderId = userInfo.getString("lenderId");
		additionalDataService.parseRequest(openId,request);
		
		if(StringUtils.isEmpty(name) || StringUtils.isEmpty(mobile) || StringUtils.isEmpty(openId) || StringUtils.isEmpty(lenderId))
		{
			
			HashMap<String,Object> map = new HashMap<>();
			map.put("code","11111");
			map.put("message","参数不正确 :");
			return new ResponseEntity<>(map,HttpStatus.BAD_REQUEST);
			
		} else
		{
			
			Map mobileDM = QLoanBindWXDAO.queryDMByMobileNumber(mobile);
			String mobileArea = "当前城市";
			if(!CollectionUtils.isEmpty(mobileDM))
			{
				mobileArea = (String)mobileDM.get("MobileArea");
				if(mobileArea.contains(" "))
				{
					mobileArea = mobileArea.split(" ")[1];
				}
			}
			
			Map city = QLoanBindWXDAO.selectCity(mobileArea);
			HashMap<String,Object> map = new HashMap<>();
			boolean isSuccess;
			if(!CollectionUtils.isEmpty(city))
			{
				String cityId = (String)city.get("id");
				try
				{
					isSuccess = MsgReceiveService.applyOffline(openId,name,mobile,lenderId,cityId);
				} catch(Exception e)
				{
					logger.error(String.format("线下产品出库失败  openid:%s lenderId:%s",openId,lenderId),e);
					isSuccess = false;
				}
				
			} else
			{
				isSuccess = false;
			}
			if(isSuccess)
			{
				
				map.put("code","00000");
				map.put("message","成功");
				
			} else
			{
				if(StringUtils.isEmpty(mobileArea))
				{
					mobileArea = "";
				}
				map.put("code","11111");
				map.put("cityName",mobileArea);
				map.put("message","失败");
			}
			
			return new ResponseEntity<>(map,HttpStatus.OK);
		}
		
	}


    //发送的客服消息
	@RequestMapping(value = "/send-json-message",method = RequestMethod.POST,produces = {"application/json;charset=UTF-8"})
	public ResponseEntity<String> sendJsonMessage(@RequestBody JSONObject message,HttpServletRequest request)
	{
		
		String openId = message.getString("openId");
        JSONArray msgList = message.getJSONArray("msgList");
		Integer status = message.getInteger("status");
		String label = message.getString("label");
		
		if(StringUtils.isEmpty(openId) || CollectionUtils.isEmpty(msgList) || status == null)
		{
            JSONObject result = new JSONObject();
            result.put("errcode",400);
            result.put("errmsg","参数不正确");
			return new ResponseEntity<>(result.toJSONString(),HttpStatus.BAD_REQUEST);
		} else
		{
			UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
			if(userStatusEntity == null)
			{

                JSONObject result = new JSONObject();
                result.put("errcode",404);
                result.put("errmsg","用户不在线，无法发送。");
				return new ResponseEntity<>(result.toJSONString(),HttpStatus.OK);
			} else
			{
				userStatusEntity.setStatus(status);
				userStatusDao.setUserStatusEntity(openId,userStatusEntity);

                JSONArray result = new JSONArray();

                for (int i = 0; i < msgList.size() ; i++) {

                    if(StringUtils.isEmpty(label))
                    {
                        result.add(JSONObject.parseObject(keFuMsgUtil.syncJsonMsg(openId,msgList.getJSONObject(i),keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity)));
                    } else
                    {
                        result.add(JSONObject.parseObject(keFuMsgUtil.syncJsonMsg(openId,msgList.getJSONObject(i),label,userStatusEntity)));
                    }
                }
				return new ResponseEntity<>(result.toJSONString(),HttpStatus.OK);
			}
		}
	}

	//发送文本类型的客服消息
	@RequestMapping(value = "/send-message",method = RequestMethod.POST,produces = {"application/json;charset=UTF-8"})
	public ResponseEntity<Map<String,Object>> sendMessage(@RequestBody JSONObject message,HttpServletRequest request)
	{
		
		String openId = message.getString("openId");
		String text = message.getString("text");
		Integer status = message.getInteger("status");
		String label = message.getString("label");
		
		if(StringUtils.isEmpty(openId) || StringUtils.isEmpty(text) || status == null)
		{
			HashMap<String,Object> map = new HashMap<>();
			map.put("code","400");
			map.put("message","参数不正确");
			return new ResponseEntity<>(map,HttpStatus.BAD_REQUEST);
		} else
		{
			UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
			if(userStatusEntity == null)
			{
				HashMap<String,Object> map = new HashMap<>();
				map.put("code","400");
				map.put("message","用户不在线，发送失败。");
				return new ResponseEntity<>(map,HttpStatus.OK);
			} else
			{
				userStatusEntity.setStatus(status);
				userStatusDao.setUserStatusEntity(openId,userStatusEntity);

				if(StringUtils.isEmpty(label))
				{
					keFuMsgUtil.say(openId,text,userStatusEntity);
				} else
				{
					keFuMsgUtil.say(openId,text,label,userStatusEntity);
				}

				HashMap<String,Object> map = new HashMap<>();
				map.put("code","0");
				map.put("message","发送成功");
				return new ResponseEntity<>(map,HttpStatus.OK);
			}
		}
	}


	
	// 通过产品组ID获取产品
	@RequestMapping(value = "/lender-by-groupId",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
	public Map getLenderByGroup(@RequestParam("groupId") String groupId,@RequestParam("openId") String openId,HttpServletRequest request)
	{


		additionalDataService.parseRequest(openId,request);
	    HashMap<String,Object> result = new HashMap<>();
		result.put("code","0");
		result.put("message","成功");
        UserStatusEntity userStatusEntity = new UserStatusEntity();
        userStatusDao.initUserQualification(openId,userStatusEntity);
        logger.info("lender-by-groupId,openId="+openId+",QualificationMap="+JSONObject.toJSONString(userStatusEntity.getQualificationMap())+",groupId="+groupId);
		List<Map<String,Object>> productInfo = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openId);
        result.put("data",productInfo);
		return result;

	}
	
	/**
	 * 机构贷后数据运用，产品列表
	 * @param groupId 产品分组编号
	 * @param lenderId 产品id，多个产品id已，号分割（待排除的产品）
	 * @return {@link Map} 包含产品列表数据
	 * @author zhangqiuping
	 */
    @RequestMapping(value = "/lender-by-groupId2",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    public Map<?,?> getLenderByGroup2(@RequestParam("groupId") String groupId,@RequestParam("lenderId") String lenderId,@RequestParam("openId") String openId,HttpServletRequest request)
    {


		additionalDataService.parseRequest(openId,request);
        UserStatusEntity userStatusEntity = new UserStatusEntity();
        userStatusDao.initUserQualification(openId,userStatusEntity);
        logger.info("lender-by-groupId2,openId="+openId+",QualificationMap="+JSONObject.toJSONString(userStatusEntity.getQualificationMap())+",groupId="+groupId);
        List<Map<String,Object>> lenders = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openId);
        excludeLender(lenders,lenderId);
        HashMap<String,Object> result = new HashMap<>();
        result.put("code","0");
        result.put("message","成功");
        result.put("data",lenders);
        return result;
    }
	
	/**排除产品*/
	private void excludeLender(List<Map<String,Object>> lenders,String lenderId)
	{
		if(StringUtils.isEmpty(lenderId) || CollectionUtils.isEmpty(lenders))
			return;
		
		String[] lenderIds = lenderId.split(",");
		for(String lenderid:lenderIds)
		{
			Iterator<Map<String,Object>> iterator = lenders.iterator();
			while(iterator.hasNext())
			{
				Map<String,Object> next = iterator.next();
				if(next.get("id").toString().equals(lenderid))
				{
					iterator.remove();
					break;
				}
			}
		}
		
	}
	
	// 通过产品组ID获取产品
	@RequestMapping(value = "/right-lender",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
	public Map getRightProd(@RequestParam("openId") String openId,HttpServletRequest request)
	{

		additionalDataService.parseRequest(openId,request);
		HashMap<String,Object> result = new HashMap<>();
		result.put("code","0");
		result.put("message","成功");
		UserStatusEntity userStatusEntity = new UserStatusEntity();
		userStatusDao.initUserQualification(openId,userStatusEntity);
		ArrayList<Map<String,Object>> data = new ArrayList<>();
		HashSet<Object> companySet = new HashSet<>();
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId("25030",userStatusEntity,openId);
        logger.info("right-lender,openId="+openId+",QualificationMap="+JSONObject.toJSONString(userStatusEntity.getQualificationMap())+",groupId=25030");
        for (int i = 0; i < prodList.size() ; i++) {
            Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if(sendProdLinkUtil.isMeet(lenderId,userStatusEntity.getQualificationMap(),openId))
            {
                Object companyId = productInfo.get("companyId");
                if(!companySet.contains(companyId))
                {
                    data.add(productInfo);
                    companySet.add(companyId);
                }
            }
		}
		result.put("data",data);
		return result;
	}

	// 通过产品组ID获取产品
	@RequestMapping(value = "/last-lender",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
	public Map getLastProd(@RequestParam("openId") String openId,HttpServletRequest request)
	{

		additionalDataService.parseRequest(openId,request);
		HashMap<String,Object> result = new HashMap<>();
		result.put("code","0");
		result.put("message","成功");
        UserStatusEntity userStatusEntity = new UserStatusEntity();
        userStatusDao.initUserQualification(openId,userStatusEntity);
        logger.info("last-lender,openId="+openId+",QualificationMap="+JSONObject.toJSONString(userStatusEntity.getQualificationMap())+",groupId=25038");
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId("25038",userStatusEntity,openId);
		result.put("data",prodList);
		return result;
	}


	//开启主流程
	@RequestMapping(value = "/ai-start",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
	public Map AIStart(@RequestParam("openId") String openId)
	{

		HashMap<String,Object> result = new HashMap<>();
		if (openId.length() != 28) {
			result.put("message","openId不合规");
			return result;
		}
		UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
		if (userStatusEntity != null){
            aIWorker.chooseQuestion(openId,userStatusEntity.getQualificationMap(),userStatusEntity,"");
            userStatusDao.setUserStatusEntity(openId,userStatusEntity);
            result.put("message","成功");
		}else {
			result.put("message","用户离线");
		}

		return result;
	}

	//提醒AI用户资质变更
	@RequestMapping(value = "/user-attr/change",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
	public Map userAttrChange(@RequestParam("openId") String openId)
	{

		HashMap<String,Object> result = new HashMap<>();
		if (openId.length() != 28) {
			result.put("message","openId不合规");
			return result;
		}
		UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
		if (userStatusEntity != null){
            userStatusDao.initUserQualification(openId,userStatusEntity);
            userStatusDao.setUserStatusEntity(openId,userStatusEntity);
            result.put("message","成功");
		}else {
			result.put("message","用户离线");
		}

		return result;
	}

	private static Map<String,String> processRequestXml(HttpServletRequest request)
	{
		Map<String,String> map = new HashMap<>();
		SAXReader reader = new SAXReader();
		ServletInputStream inputStream = null;
		try
		{
			inputStream = request.getInputStream();
			Document document = reader.read(inputStream);
			Element root = document.getRootElement();
			List<Element> elements = root.elements();
			for(Element e:elements)
			{
				map.put(e.getName(),e.getText());
			}
		} catch(DocumentException | IOException e)
		{
			logger.error("微信消息解析异常",e);
		}
		finally
		{
			if(inputStream != null)
			{
				try
				{
					inputStream.close();
				} catch(IOException e)
				{
					logger.error("解析微信消息IO异常",e);
				}
			}
		}
		return map;
	}

}
