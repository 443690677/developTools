package com.eqianzhuang.efinancial.ai.controller;

import com.eqianzhuang.efinancial.ai.service.feedback.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description: 机构反馈相关接口
 * @Author : Junjin Lin
 * @Creation Date : 2019/02/26 10:09
 */
@RestController
@RequestMapping(value = "/efinancial/ai")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @GetMapping("/feedback")
    public Object handleOrgFeedbackStatus(@RequestParam("openId") String openId,
                                          @RequestParam(value = "feedbackStatus", defaultValue = "0") Integer status) {

        return feedbackService.handleOrgFeedbackStatus(openId, status);
    }

}
