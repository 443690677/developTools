package com.eqianzhuang.efinancial.dao;

public interface HongbaoPartyDao {

    void insertUser(String follower ,String leader);

    int getUserCount();

    int getUserByLeader(String leader);

    String getMediaIdByOpenid(String openid);

    void insertMedia(String openid,String media);
}
