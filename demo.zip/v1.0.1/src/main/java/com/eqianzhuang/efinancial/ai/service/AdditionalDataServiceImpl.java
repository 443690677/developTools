package com.eqianzhuang.efinancial.ai.service;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.common.RequestUtil;
import com.eqianzhuang.efinancial.common.userAgent.UserAgent;
import com.eqianzhuang.efinancial.dao.AdditionalDataDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.eqianzhuang.efinancial.common.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.MalformedParameterizedTypeException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 记录请求头
 */
@Service
public class AdditionalDataServiceImpl implements AdditionalDataService{

    private static Log logger = LogFactory.getLog(AdditionalDataServiceImpl.class);
    @Autowired
    private  AdditionalDataDao additionalDataDao;


    @Autowired
    private WeiXinUserInfoUtil weiXinUserInfoUtil;

    private static Pattern cityPattern = Pattern.compile("(北京|天津|上海|重庆)");

    @Override
    public void updateAdditionalData(Map<String,String> fields){
        try {
            Map record = additionalDataDao.selectAdditionalDataByOpenId(fields.get("open_id"));
            if ((record.get("gender") == null || (record.get("gender") != null && "0".equals(record.get("gender").toString())))
                    ||  (record.get("gender") != null && !"0".equals(record.get("gender").toString()) && !record.get("gender").toString().equals(fields.get("gender")))
                    || StringUtils.isEmpty(record.get("city"))){
                JSONObject userInfo = weiXinUserInfoUtil.getWeChatUserInfo(fields.get("open_id"));
                if (userInfo != null) {
                    fields.put("gender", userInfo.getString("sex"));
                    String province = userInfo.getString("province");
                    if (!StringUtils.isEmpty(province)) {
                        Matcher m = cityPattern.matcher(province);
                        if (m.find()) {
                            fields.put("city", province);
                        } else {
                            fields.put("city", userInfo.getString("city"));
                        }
                    }else{
                        fields.put("city", userInfo.getString("city"));
                    }
                }
            }
            if (CollectionUtils.isEmpty(record)) {
                Integer gender = fields.get("gender") == null ? null : Integer.valueOf(fields.get("gender"));
                additionalDataDao.add(fields.get("open_id"), gender, fields.get("city"), fields.get("req_url"), fields.get("model"), fields.get("brand"), fields.get("user_agent"), fields.get("ip"), fields.get("os"));
            } else {
                Iterator<Map.Entry<String, String>> it = fields.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry entry = it.next();
                    if (entry != null && !StringUtils.isEmpty(entry.getValue())) {
                        record.put(entry.getKey(), entry.getValue());
                    }
                }
                additionalDataDao.update(StringUtils.valueOf(record.get("open_id")),
                        record.get("gender") == null ? null :Integer.valueOf(record.get("gender").toString()),
                        StringUtils.valueOf(record.get("city")),
                        StringUtils.valueOf(record.get("req_url")),
                        StringUtils.valueOf(record.get("model")),
                        StringUtils.valueOf(record.get("brand")),
                        StringUtils.valueOf(record.get("user_agent")),
                        StringUtils.valueOf(record.get("ip")),
                        StringUtils.valueOf(record.get("os")));
            }
        }catch(Exception e){
            logger.error(String.format("记录请求异常：fields=%s",fields.toString()),e);
        }
    }

    public void parseRequest(String openid,HttpServletRequest request){
        String userAgents = request.getHeader("User-Agent");
        try {
            String ip = RequestUtil.getClientIP(request);
            UserAgent userAgent = RequestUtil.getUserAgent(userAgents);
            logger.debug(String.format("request_info ip=%s  useragent=%s  userAgents=%s",ip,userAgent,userAgents));
            Map<String,String> record = new HashMap<String,String>();
            record.put("open_id",openid);
            record.put("ip",ip);
            record.put("req_url",request.getRequestURI().toString());
            record.put("model",userAgent.getMobileType());
            record.put("brand",userAgent.getBrand());
            record.put("user_agent",userAgents);
            record.put("os",userAgent.getPlatform());
            updateAdditionalData(record);
        }catch(Exception e){
            logger.error(String.format("记录请求异常：userAgents=%s",userAgents),e);
        }
    }
}
