package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.entity.CompLenderJoinConfigPO;

public interface CompJoinConfigDAO {

    /**
     *
     * @param lenderId 产品id
     * @return CompLenderJoinConfigPO
     */
//    CompLenderJoinConfigPO getCompLenderJoinConfig(Long lenderId);

    String getCompLenderJoinConfig(Long lenderId);
}
