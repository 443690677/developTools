/*
 * 文件名：IWechatListConfigDaoImpl.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:05:31 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import com.alibaba.fastjson.JSONArray;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年7月31日 下午5:05:31
 */
@Repository
public class IWechatListConfigDaoImpl implements IWechatListConfigDao
{

    private static Log logger = LogFactory.getLog(IWechatListConfigDaoImpl.class);

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private static List<Map<String,Object>> prodInfo ;

    private static HashMap<String,List<Map<String,Object>>> prodCache = new HashMap<>();


    @Override
    public Map<String,Object> getProdInfoByLenderId(Integer lenderId) {

        for ( Map<String,Object> prod  : prodInfo){
            if ((int)prod.get("id") == lenderId) {
                return prod;
            }
        }
        return new HashMap<>();
    }

    @Override
    public List<Map<String,Object>> getProdInfoByGroupId(String groupId, UserStatusEntity userStatusEntity,String openId) {
        List<Map<String,Object>> prodList;
        prodList = prodCache.get(groupId);
        if (CollectionUtils.isEmpty(prodList)) {
            prodList = getProductAllInfoByGroupId(groupId);
            //【最新】关键字产品组不处理
            if (!"25038".equals(groupId)) {
                //拼接全部产品组产品
                for (Map<String,Object> prod : prodInfo){
                    if (!prodList.contains(prod)) {
                        prodList.add(prod);
                    }
                }
            }

            prodCache.put(groupId,prodList);
        }

        //过滤一批产品
        return filter(prodList,userStatusEntity,openId);
    }

	@Override
	public String getProdNameByLenderId(String lenderId)
	{
		try
		{
			return jdbcTemplate.queryForObject("select a.name from credit_cpa.v3_lender a WHERE a.id = ? limit 1 ;",String.class,lenderId);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		return "";
	}

    @Override
    public List<Map<String, Object>> getProdInfoByName(JSONArray prodName) {

        List<Map<String,Object>> prodList = new ArrayList<>();
        for ( Map<String,Object> prod :prodInfo){
            String name = (String) prod.get("name");
            for (int i = 0; i < prodName.size(); i++) {
                if (name.contains(prodName.getString(i))) {
                    prodList.add(prod);
                }
            }
        }
        return prodList;
    }


    @Override
	public List<Map<String,Object>> getProductAttr(String lenderId)
	{
		return jdbcTemplate.queryForList(" SELECT t.* FROM credit_xyb.e_financial_v3_product_attr t WHERE lenderid = ? ;",lenderId);
	}


	@Override
	public void addWxOps(String openId,String wechat_type,String mark,String words,String prod_id,String source,String remarks)
	{
		jdbcTemplate.update("INSERT INTO credit_cpa.v3_wechat_ops (open_id, wechat_type, mark, words, prod_id, source, remarks, create_time) VALUES ( ?, ?, ?, ?, ?, ?, ?,now());",openId,wechat_type,
		        mark,words,prod_id,source,remarks);
	}


    private List<String> getProductIDByLabel(String label) {
        return jdbcTemplate.queryForList("SELECT b.id FROM credit_cpa.v3_lender b WHERE b.lable like ? and b.status =0 ;",String.class,"%"+label+"%");
    }

    private List<Map<String,Object>> getProductAllInfoByGroupId(String groupId)
    {
        List<String> lenderIds = null;

        if ("25049".equals(groupId)){
            lenderIds = getProductIDByLabel("易通过");
        }else if ("25050".equals(groupId)){
            lenderIds = getProductIDByLabel("不查征信");
        }else if ("25061".equals(groupId)||"25067".equals(groupId)){
            lenderIds = getProductIDByLabel("利率低");
        }else if ("25062".equals(groupId)||"25068".equals(groupId)){
            lenderIds = getProductIDByLabel("白户可贷");
        }else if ("25063".equals(groupId)||"25069".equals(groupId)){
            lenderIds = getProductIDByLabel("额度高");
        }else if("25038".equals(groupId)){
            //筛选最新的20个产品
            lenderIds = jdbcTemplate.queryForList(
                    " SELECT b.id FROM "
                            + "  ( SELECT confi_.id, groupid_.group_id groupId,confi_.lenderId,confi_.lenderUrlId urlid,confi_.nPriority priority,confi_.currentOrder,confi_.baseOrder from credit_cpa.v3_wechat_list_config confi_ "
                            + "   left join credit_cpa.v3_lender_group_num groupnum_ on confi_.groupId = groupnum_.group_num "
                            + "   left join credit_cpa.v3_lender_group_id groupid_ on groupnum_.group_num = groupid_.group_num " + " where groupid_.group_id = ? ) a ,credit_cpa.v3_lender b"
                            + "   WHERE b.id = a.lenderid AND b.status=0 ORDER BY b.createdDate DESC LIMIT 20 ",String.class,groupId);
            //动态排序
            List<Map<String,Object>> prods =jdbcTemplate.queryForList(" SELECT a.urlid urlId,b.* FROM "
                    + "  ( SELECT confi_.id, groupid_.group_id groupId,confi_.lenderId,confi_.lenderUrlId urlid,confi_.nPriority priority,confi_.currentOrder,confi_.baseOrder from credit_cpa.v3_wechat_list_config confi_ "
                    + "   left join credit_cpa.v3_lender_group_num groupnum_ on confi_.groupId = groupnum_.group_num "
                    + "   left join credit_cpa.v3_lender_group_id groupid_ on groupnum_.group_num = groupid_.group_num " + "   where groupid_.group_id = ? ) a ,credit_cpa.v3_lender b"
                    + "   WHERE b.id = a.lenderid AND b.status=0 ORDER BY a.currentOrder ASC,a.baseOrder ASC;",groupId);

            List<Map<String,Object>> prodList = new ArrayList<>();
            for (Map<String, Object> lender : prods) {
                if (lenderIds.contains(String.valueOf(lender.get("id")))) {
                    prodList.add(lender);
                }
            }
            return prodList;
        }

        if ( lenderIds != null){
            List<Map<String,Object>> prodList = new ArrayList<>();
            for (Map<String, Object> lender : prodInfo) {
                if (lenderIds.contains(String.valueOf(lender.get("id")))) {
                    prodList.add(lender);
                }
            }
            return prodList;
        }else {
            return jdbcTemplate.queryForList(" SELECT a.urlid urlId,b.* FROM "
                            + "  ( SELECT confi_.id, groupid_.group_id groupId,confi_.lenderId,confi_.lenderUrlId urlid,confi_.nPriority priority,confi_.currentOrder,confi_.baseOrder from credit_cpa.v3_wechat_list_config confi_ "
                            + "   left join credit_cpa.v3_lender_group_num groupnum_ on confi_.groupId = groupnum_.group_num "
                            + "   left join credit_cpa.v3_lender_group_id groupid_ on groupnum_.group_num = groupid_.group_num " + "   where groupid_.group_id = ? ) a ,credit_cpa.v3_lender b"
                            + "   WHERE b.id = a.lenderid AND b.status=0 ORDER BY a.currentOrder ASC,a.baseOrder ASC;",groupId);
        }
    }

	@PostConstruct
    private void init(){
        cacheProductInfo();
    }

    @Scheduled(cron="0 */5 * * * ? ")
    public void cacheProductInfo() {
	    //初始化全部产品
        prodInfo = jdbcTemplate.queryForList(" SELECT a.urlid urlId,b.* FROM ( SELECT confi_.id, confi_.lenderId,confi_.lenderUrlId urlid,confi_.nPriority priority, " +
                "  confi_.currentOrder,confi_.baseOrder from credit_cpa.v3_wechat_list_config confi_ " +
                "  left join credit_cpa.v3_lender_group_num groupnum_ on confi_.groupId = groupnum_.group_num " +
                "  WHERE groupnum_.group_num = 45031 ) a ,credit_cpa.v3_lender b " +
                "  WHERE b.status=0 AND b.id = a.lenderid ORDER BY a.currentOrder ASC,a.baseOrder ASC;");
        //清空缓存
        prodCache.clear();
    }

    private List<Map<String,Object>> filter(List<Map<String,Object>> prodList ,UserStatusEntity userStatusEntity ,String openId){

        List<Map<String,Object>> prods =  new ArrayList<>();

        //用户的注册记录
        String sql= "SELECT DISTINCT b.data_status,b.comp_id FROM credit_cpa.v3_cpa_apply_rec a LEFT OUTER JOIN credit_cpa.v3_comp_user_detailed b  on  a.id = b.apply_id  WHERE businessId = ? ;";
        List<Map<String,Object>> records = jdbcTemplate.queryForList(sql,openId);
        for (Map<String, Object> prod : prodList) {

            //过滤贷超产品
            String type = String.valueOf(prod.get("type"));
            if ("贷款超市".contains(type)) {
                HashMap<String, String> qualification = userStatusEntity.getQualificationMap();
                String creditCard_DC = qualification.get("creditCard");
                if (!"True".equals(creditCard_DC)) {
                    creditCard_DC = qualification.get("creditCard_DC");
                }
                String zhimaScore_DC = qualification.get("zhimaScore");
                if (StringUtils.isEmpty(zhimaScore_DC)) {
                    zhimaScore_DC = qualification.get("zhimaScore_DC");
                }
                if ("True".equals(creditCard_DC) || (ValidUtils.isNumeric(zhimaScore_DC) && zhimaScore_DC.length() < 5 && Integer.valueOf(zhimaScore_DC) >= 600)) {
                    continue;
                }
            }

            //过滤已经已经注册的产品
            boolean isRegs = false;
            String companyId = String.valueOf(prod.get("companyId"));
            for ( Map<String,Object> record : records) {
                String comp_id = String.valueOf(record.get("comp_id"));
                if ( companyId.equals(comp_id)) {
                    String data_status  = String.valueOf(record.get("data_status"));
                    if ( "10289".equals(companyId) && !"-1".equals(data_status)) {
                        isRegs =true;
                        break;
                    }

                    if( !"10289".equals(companyId) && !"0".equals(data_status)){
                        isRegs =true;
                        break;
                    }
                }
            }

            if (!isRegs) {
                prods.add(prod);
            }
        }

        return prods;
    }
}
