package com.eqianzhuang.efinancial.dao;

public interface UserActionAuditDAO {
    void insert(String openid, int action);
}
