/**
 * 
 */
package com.eqianzhuang.efinancial.dao.lender.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.eqianzhuang.efinancial.dao.lender.LenderDimensionDao;

/**
 * 产品筛选维度Dao impl
 * @author huangzhigang
 */
@Repository
public class LenderDimensionDaoImpl implements LenderDimensionDao {

	@Autowired
    JdbcTemplate jdbcTemplate;
	
	/**
	 * 查询产品维度List
	 * @param type 维度类型
	 * @return Map<String, String>
	 */
	@Override
	public List<Map<String, Object>> selData(String type) {
		List<Map<String, Object>> dataList = jdbcTemplate.queryForList(
				"SELECT negative_dimension nd, recommend_dimension rd, lender_id lenderId FROM credit_cpa.v3_lender_dimension WHERE type = ?  ",
				type);
		if (dataList == null || (dataList != null && dataList.size() == 0)) {
			return new ArrayList<Map<String, Object>>();
		}
		return dataList;
	}

}
