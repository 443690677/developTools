package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;


/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年8月3日 下午2:06:45
 */
@Repository
public class IV3CpaApplyRecDaoImpl implements IV3CpaApplyRecDao {


	@Autowired
	JdbcTemplate jdbcTemplate;

    @Autowired
    WeChatConfig weChatConfig;

    @Override
    public long insertApplyRec(int bType, String businessId, String prodId, String createdBy, String updatedBy, String groupId, int nPriority, int status, String redirectUrl) {

        try {
        	jdbcTemplate.update("insert into credit_cpa.v3_cpa_apply_rec" +
						"(prodId,redirctUrl,status,createdBy,updatedBy,businessId,bType,groupId,nPriority,createdDate,updatedDate)" +
						" values (?,?,?,?,?,?,?,?,?,now(),now());", prodId,redirectUrl,status,createdBy,updatedBy,businessId,bType,groupId,nPriority);
            String SQL = "select last_insert_id() as id from credit_cpa.v3_cpa_apply_rec limit 1;";
            return jdbcTemplate.queryForObject(SQL,Long.class);
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0L;
    }

    @Override
	public void insertUserQualification(String amount, String name, String mobile, String mobile_des, String cityName, String cityId, String creditCard, String zhimaScore, String social_insurance,String publicFund ,String ownCar, String ownHousing, String insurance, String insuranceFee, String salary,String openid) {
		jdbcTemplate.update("insert into credit_cpa.v3_apply_record " +
				" (amount,name,mobile,mobile_des,cityName,cityid,creditCard,zhimaScore,social_insurance,ownCar,ownHousing,insurance,insuranceFee,publicFund,salary,createdDate,updatedDate,createdBy,updatedBy,mediaSource,mediaId) " +
				" values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now(),now(),?,?,?,?);"
                 ,amount,name,mobile,mobile_des,cityName,cityId,creditCard,zhimaScore,social_insurance,ownCar,ownHousing,insurance,insuranceFee,publicFund,salary, weChatConfig.getMediaName(openid), weChatConfig.getMediaName(openid), weChatConfig.getMediaName(openid), weChatConfig.getMediaId(openid));
	}


	@Override
	public Map<String,Object> selectUserQualification(String mobile) {

		try {
			String SQL = "SELECT applyId, mobile_des FROM  credit_cpa.v3_apply_record WHERE mobile = ? ORDER BY createdDate DESC LIMIT 1 ;";
			return  jdbcTemplate.queryForMap(SQL,mobile);
		}catch (Exception e){
			e.printStackTrace();
		}
		return new HashMap<>();
	}

	@Override
	public boolean usersGroupBool(int lenderId, String openid) {
		// TODO Auto-generated method stub 
		Integer check = 0;
		try {
			check = jdbcTemplate.queryForObject("select count(1) from  credit_cpa.v3_users_group where prodId=? and openid=? and createdDate BETWEEN DATE_FORMAT(now(),'%Y-%m-%d 00:00:00') and DATE_FORMAT(now(),'%Y-%m-%d 23:59:59') limit 1 ;" , Integer.class,lenderId,openid);
        }catch (Exception e){
            e.printStackTrace();
        }
		
		if (check!=null && check > 0){
			return false;
		}
		return true;
	}

	@Override
	public String usersGroupRecordNew(int lenderId, String wxType) {
		// TODO Auto-generated method stub
		try {
            return jdbcTemplate.queryForObject("select groupNumber from  credit_cpa.v3_users_group where prodId=? and wxType=? and createdDate BETWEEN DATE_FORMAT(now(),'%Y-%m-%d 00:00:00') and DATE_FORMAT(now(),'%Y-%m-%d 23:59:59') ORDER BY createdDate DESC limit 1;",String.class,lenderId,wxType);
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
	}

	@Override
	public void insertUsersGroupRecord(int lenderId, String wxType, String openid, String groupNumber) {
		// TODO Auto-generated method stub
		 jdbcTemplate.update("insert into credit_cpa.v3_users_group(prodId,wxType,openid,groupNumber,createdDate,updatedDate)" +
	                " values(?,?,?,?,now(),now());",
	                lenderId,wxType,openid,groupNumber);
	}
  
}
