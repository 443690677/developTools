package com.eqianzhuang.efinancial.ai.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.constant.WebChatConstant;
import com.eqianzhuang.efinancial.ai.service.AIProcessService;
import com.eqianzhuang.efinancial.ai.service.MsgReceiveService;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.dao.ChatDAO;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.MsgProcessDAO;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping(value = "/efinancial/ai")
@RestController
public class WebChatController {

    private Log  logger= LogFactory.getLog(this.getClass());

    @Autowired
    AIWorker aiWorker;

    @Autowired
    AIProcessService aIProcessService;

    @Autowired
    UserStatusDao userStatusDao;

    @Autowired
    SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    private ChatDAO chatDAO;

    @Autowired
    private MsgProcessDAO msgProcessDAO;

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    private MsgReceiveService msgReceiveService;

    @Autowired
    private IWechatListConfigDao iWechatListConfigDao;

    @Autowired
    private WeiXinUserInfoUtil weiXinUserInfoUtil;

    @Autowired
    private KeFuMsgUtil keFuMsgUtil;

    @Autowired
    private RedisClient redisClient;


    @MessageMapping("/web-message")
    public void webMessage(JSONObject webMessage) {

        String openId = webMessage.getString("openId");
        if ( openId == null || openId.length() !=28 ) {
            logger.error("webMessage,openId不正确"+openId);
            return;
        }
        logger.info("webChat用户消息：" + webMessage.toJSONString());
        String message = webMessage.getString("message");
        String ghId = weChatConfig.getGhid(openId);

        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if(userStatusEntity == null){
            userStatusEntity = new UserStatusEntity();
            userStatusDao.initUserQualification(openId,userStatusEntity);
        }

        //添加对话到mongodb
        try{
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message",message);
            jsonObject.put("msgtype","text");
            chatDAO.insertWebChats(openId, "WebI",jsonObject.toJSONString());
            //记录对话到mysql
            msgProcessDAO.insertMsg(openId,ghId,null,3,message.replaceAll("[^\\u0000-\\uFFFF]", ""),"webChat",keFuMsgUtil.getLabel(userStatusEntity));
            // 记录埋点
            msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId), 9002,openId);

        }catch(Exception e){
            logger.error("记录AI对话失败:",e);
        }

        aIProcessService.webChatProcess(openId,message,userStatusEntity);
    }

    @RequestMapping(value = "/webChat/getMore",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    public Map<String, Object> getMore(@RequestParam("openId") String openId){
        HashMap<String,Object> result = new HashMap<>();
        if (openId.length() != 28) {
            result.put("message","openId不合规");
            return result;
        }
        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if (userStatusEntity != null){
            aIProcessService.webChatProcess(openId,"换一批",userStatusEntity);
            result.put("message","成功");
        }else {
            result.put("message","用户离线");
        }

        return result;
    }



    @RequestMapping(value = "/webChat/previous",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    public Map<String, Object> previous(@RequestParam("openId") String openId){
        HashMap<String,Object> result = new HashMap<>();
        if (openId.length() != 28) {
            result.put("message","openId不合规");
            return result;
        }
        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if (userStatusEntity != null){
            aIProcessService.webChatPrevious(openId,userStatusEntity);
            result.put("message","成功");
        }else {
            result.put("message","用户离线");
        }

        return result;
    }

    @RequestMapping(value = "/get-web-chats",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    public Map getWebChats(@RequestParam("openId") String openId,@RequestParam(value = "nextIndex",required = false) Integer nextIndex)
    {

        HashMap<String,Object> result = new HashMap<>();
        if (openId.length() != 28) {
            result.put("message","openId不合规");
            return result;
        }
        Map map = chatDAO.getWebChats(openId);
        if (CollectionUtils.isEmpty(map)) {
            result.put("chats","");
            return result;
        }

        List<Map<String,Object>> chats = (List<Map<String, Object>>) map.get("comments");
        int chatSize = chats.size();
        int index = 0;
        if ( nextIndex == null) {
            if (chatSize > 50) {
                index = chatSize - 50;
            }
            chats = chats.subList( index ,chatSize);
        }else if (nextIndex > 0){
            if ( nextIndex > 50) {
                index = nextIndex - 50;
            }
            chats = chats.subList( index ,nextIndex);
        }else {
            result.put("chats","");
            result.put("nextIndex",index);
            return result;
        }

        for (Map<String,Object> chat :chats) {
            String from  = (String) chat.get("from");
            JSONObject msg = JSONObject.parseObject((String) chat.get("msg"));
            if ("WebY".equals(from)){
                if ( "prod".equals(msg.getString("msgtype"))) {
                    List<Map<String,Object>> prodInfoList = new ArrayList<>();
                    JSONArray prodList = msg.getJSONArray("prodList");
                    for (int i = 0; i < prodList.size(); i++) {
                        Map<String,Object> prodInfo = iWechatListConfigDao.getProdInfoByLenderId(prodList.getInteger(i));
                        if (!CollectionUtils.isEmpty(prodInfo)) {
                            prodInfoList.add(prodInfo);
                        }
                    }
                    if (prodInfoList.size() == 0) {
                        msg = new JSONObject();
                        msg.put("message","当前产品不可以用，请进入公众号菜单申请产品。");
                        msg.put("msgtype","text");
                    }else {
                        msg.put("prodList",prodInfoList);
                    }
                }
            }
            chat.put("msg",msg);
        }
        result.put("chats",chats);
        result.put("nextIndex",index);
        return result;
    }

    /**
     * 线上产品申请
     */
    @RequestMapping(value = "/online/apply",method = RequestMethod.GET)
    public Map onlineApply(@RequestParam("openid") String openid, @RequestParam("lenderId") String lenderId, @RequestParam("groupId") String groupId,
                           @RequestParam("urlId") String urlId)
    {
        HashMap<String,Object> dataMap = msgReceiveService.applyOnline(openid,weChatConfig.getMediaName(openid) + "_WEB",lenderId,groupId,urlId,true);

        HashMap<String,Object> result = new HashMap<>();
        if(Integer.valueOf(0).equals(dataMap.get("resultCode")))
        {
            result.put("code","00000");
            result.put("url",dataMap.get("url"));
            result.put("message","申请成功");
        }else {
            result.put("code","11111");
            result.put("message","申请失败");
        }
        return result;
    }

    /**
     * 根据wxcode获取openId
     * @param wxcode 微信code
     * @param request
     * @return
     */
    @RequestMapping(value = "/web-chat/getUserInfo",method = RequestMethod.GET)
    public Map getUserInfo(@CookieValue( name = "efinancial_access_cookie",required = false) String cookieOpenid , @CookieValue( name = "head_img_url",required = false) String cookieUrl ,@RequestParam("wxcode") String wxcode, HttpServletRequest request, HttpServletResponse httpServletResponse)
    {


        logger.info("getUserInfo(),开始获取用户信息,cookieOpenid="+cookieOpenid+",cookieUrl="+cookieUrl+",wxcode="+wxcode);
        String openid = cookieOpenid;
        String imgUrl = cookieUrl;
        HashMap<String,String> result = new HashMap<>();
        if (StringUtils.isEmpty(cookieOpenid) || StringUtils.isEmpty(cookieUrl)||cookieOpenid.length() != 28) {
            String domain2 = request.getServerName();
            JSONObject jsonObject = weiXinUserInfoUtil.htmlLogin(wxcode, domain2);
            logger.info("getUserInfo(),根据 wxcode="+ wxcode+" 获取openId jsonObject = " + jsonObject);
            openid = jsonObject.getString("openid");
            imgUrl = jsonObject.getString("headimgurl");

            if ( !StringUtils.isEmpty(openid)) {
                Cookie cookie= new Cookie("efinancial_access_cookie", openid);
                cookie.setDomain(domain2);
                httpServletResponse.addCookie(cookie);
            }else {
                openid = "";
            }

            if (!StringUtils.isEmpty(imgUrl)) {
                Cookie Img = new Cookie("head_img_url", imgUrl);
                Img.setDomain(domain2);
                httpServletResponse.addCookie(Img);
            }else {
                imgUrl = "";
            }

        }else {
            logger.info("getUserInfo(),cookie里面的信息,openid="+openid+",imgurl="+imgUrl);
        }
        result.put("openid",openid);
        result.put("imgurl",imgUrl);
        logger.info("getUserInfo(),完成获取用户信息,openid="+openid+",imgUrl="+imgUrl);
        return result;
    }


    @RequestMapping(value = "/webChat/reply",method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public Map getReply()
    {
        HashMap<String,Object> result = new HashMap<>();
        result.put("code","0");
        result.put("message","success");
        HashMap<String,Object> reply = new HashMap<>();
        Class webChatConstant = WebChatConstant.class;
        Field[] fields = webChatConstant.getDeclaredFields();

        for(int i = 0;i < fields.length;i++ )
        {
            Field field = fields[i];
            String key = weChatConfig.getWebChatConstantKeyPrefix() + field.getName();

            if("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName()))
            {
                try
                {
                    reply.put(key,field.get(webChatConstant));
                } catch(IllegalAccessException e)
                {
                    e.printStackTrace();
                }
            }

            if ("java.lang.String".equals(field.getGenericType().getTypeName())) {
                try {
                    field.set(key,field.get(webChatConstant));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }

        }

        result.put("reply",reply);
        return result;
    }

    @RequestMapping(value = "/webChat/reply",method = RequestMethod.PUT,produces = {"application/json;charset=UTF-8"})
    public Map setReply(@RequestBody JSONObject reply)
    {
        Class webChatConstant = WebChatConstant.class;
        Field[] fields = webChatConstant.getDeclaredFields();
        for(int i = 0;i < fields.length;i++ )
        {
            Field field = fields[i];
            String key = weChatConfig.getWebChatConstantKeyPrefix() + field.getName();
            String fieldsValue = reply.getString(key);
            if(!StringUtils.isEmpty(fieldsValue))
            {
                if("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName()))
                {
                    try
                    {
                        field.set(webChatConstant,reply.getJSONObject(key));
                        redisClient.set(key,reply.getJSONObject(key));
                    } catch(IllegalAccessException e)
                    {
                        e.printStackTrace();
                    }
                }
                if ("java.lang.String".equals(field.getGenericType().getTypeName())) {
                    try {
                        field.set(webChatConstant,reply.getString(key));
                        redisClient.set(key,reply.getString(key));
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            }else if ("".equals(fieldsValue)){
                redisClient.del(key);
            }
        }

        HashMap<String,Object> result = new HashMap<>();
        result.put("code","0");
        result.put("message","success");
        result.put("reply",getReply());

        return result;
    }

    @RequestMapping(value = "/webChat/add-exception-log",method = RequestMethod.POST,produces = {"application/json;charset=UTF-8"})
    public Map addExceptionLog(@RequestBody JSONObject ExceptionLog)
    {
        HashMap<String,Object> result = new HashMap<>();
        logger.error("addExceptionLog(),前端异常信息：" + ExceptionLog);
        result.put("code","0");
        result.put("message","success");
        return result;
    }
}
