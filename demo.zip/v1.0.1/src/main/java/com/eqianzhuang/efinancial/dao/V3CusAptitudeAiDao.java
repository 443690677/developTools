package com.eqianzhuang.efinancial.dao;

import java.util.Map;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年7月31日 下午5:00:01
 */
public interface V3CusAptitudeAiDao
{
	Map getCusAptitudeAi(String openid);

    void updateCusAptitudeAi(String open_id, String field_name, String field_value, String unionId, String wx_type);

    void insertCusAptitudeAi(String open_id, String field_name, String field_value, String unionId, String wx_type);

    Integer selectV3CustomerAI(String mobile);

    void updateCustomerAI(String full_name, String mobile, String city_id, String amount,String openid);

    void insertCustomerAI(String full_name, String mobile, String city_id, String amount,String openid);

    Map selectUpdateOr(String open_id, String field_name);

    void insertUpdateOr(String open_id, String field_name, String field_value);

    void insertUserAction(String openid, String action_name, String action_content);

    int checkCusAptitudeIsSatisfy(String openId, String sql);

    int checkCusCitysIsSatisfy(String openId, String param);

}
