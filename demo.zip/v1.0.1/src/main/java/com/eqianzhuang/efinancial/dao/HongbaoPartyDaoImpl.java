package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class HongbaoPartyDaoImpl implements HongbaoPartyDao {


    Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    WeChatConfig weChatConfig;

    @Override
    public void insertUser(String follower, String leader) {
        //不能拉自己
        if (follower.equals(leader))
        {
            return;
        }

        try {
            jdbcTemplate.update("INSERT INTO credit_xyb.e_financial_hongbao_party (follower, leader, createdDate, createdBy) VALUES ( ?, ? , now(), ?);", follower,leader,weChatConfig.getMediaName(leader));
        }catch (Exception e){
            logger.error("拉新活动，重复关注。保留最新",e);
            jdbcTemplate.update("UPDATE credit_xyb.e_financial_hongbao_party a SET a.leader = ? , a.createdDate=now() WHERE a.follower = ?", leader,follower);
        }
    }

    @Override
    public int getUserCount() {
        return jdbcTemplate.queryForObject("SELECT count(*) FROM credit_xyb.e_financial_hongbao_party ;",Integer.class);
    }

    @Override
    public int getUserByLeader(String leader) {
        return jdbcTemplate.queryForObject("SELECT count(*) FROM credit_xyb.e_financial_hongbao_party a LEFT JOIN credit_agency.v2_qloan_bindwx b ON a.follower=b.openId WHERE a.leader=? AND b.state = 0 ;",Integer.class,leader);
    }

    @Override
    public String getMediaIdByOpenid(String openid) {
        try {
            return jdbcTemplate.queryForObject("SELECT a.media_id FROM credit_xyb.e_financial_hongbao_party_media a WHERE a.openid = ?;",String.class,openid);
        } catch (EmptyResultDataAccessException ignored) {
            return null;
        }
    }

    @Override
    public void insertMedia(String openid, String media) {
        jdbcTemplate.update("INSERT INTO credit_xyb.e_financial_hongbao_party_media (openid, media_id, createdDate, createdBy) VALUES ( ?, ?, now(), ?);", openid,media,weChatConfig.getMediaName(openid));
    }
}
