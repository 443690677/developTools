package com.eqianzhuang.efinancial.ai.timerJob;


import com.eqianzhuang.efinancial.dao.UserStatusDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.HashSet;


@Component
public class SatisfactionSurveyJob {

    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private SatisfactionSurveyFunction satisfactionSurveyFunction;


    @Autowired
    private UserStatusDao userStatusDao;

    @Async("asyncWorker")
    public void satisfactionSurvey(String openidPrefix){

        Calendar calendar = Calendar.getInstance();
        int hour  = calendar.get(Calendar.HOUR_OF_DAY);
        boolean isWorkingTime = true;
        if ( hour < 9 ){
            isWorkingTime =false;
        }
        logger.info("satisfactionSurvey starting,openidPrefix=" + openidPrefix);
        HashSet<String> onlineUsers = userStatusDao.getOnlineUsers(openidPrefix);
        long currentTime = System.currentTimeMillis();
        logger.info(openidPrefix + ",在线用户数量："  + onlineUsers.size());

        for (String openId : onlineUsers) {
            //295秒就停止。
            if ( currentTime + 295 * 1000 < System.currentTimeMillis()){
                logger.info("satisfactionSurvey timeOut,openidPrefix="+openidPrefix);
                return;
            }

            try {

                satisfactionSurveyFunction.execute(openId,isWorkingTime,false);

            }catch (Exception e){

                logger.error("定时任务执行报错,openid"+openId ,e);

            }

        }
        logger.info("satisfactionSurvey end,openidPrefix="+openidPrefix);
    }

    @Async("asyncWorker")
    public void testJob(String[] openIds){
        logger.info("testJob start");
        for (int i =0 ; i< openIds.length ;i++){
            satisfactionSurveyFunction.execute(openIds[i],true,true);
        }
        logger.info("testJob stop");
    }
}