package com.eqianzhuang.efinancial.common.configbean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;


@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    ThreadPoolTaskScheduler threadPoolTaskScheduler;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {

        config.enableSimpleBroker("/receive").setHeartbeatValue(new long[]{10000L,10000L}).setTaskScheduler(threadPoolTaskScheduler);
        config.setApplicationDestinationPrefixes("/send");
        config.setUserDestinationPrefix("/receive");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/efinancial/ai/web-chat-endpoint").setAllowedOrigins("*").withSockJS();
    }

}