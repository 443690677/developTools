package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.entity.CompLenderJoinConfigPO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CompJoinConfigDAOImpl implements CompJoinConfigDAO {

    private static Log logger = LogFactory.getLog(CompJoinConfigDAOImpl.class);

    @Autowired
    JdbcTemplate jdbcTemplate;

//    @Override
//    public CompLenderJoinConfigPO getCompLenderJoinConfig(Long lenderId) {
//
//        String sql = "select id, comp_id  compId, lender_id lenderId, join_url joinUrl, description from v3_comp_lender_join_config where is_valid=0 and lender_id="+lenderId ;
//        return jdbcTemplate.queryForObject(sql,CompLenderJoinConfigPO.class);
//    }
    
    @Override
    public String getCompLenderJoinConfig(Long lenderId) {
    	String object = null;
        try {
            object =  jdbcTemplate.queryForObject("SELECT join_url FROM credit_cpa.v3_comp_lender_join_config where is_valid=0 and lender_id= ? limit 1",String.class, lenderId);
        } catch (EmptyResultDataAccessException e) {
            // e.printStackTrace(); // 可以选择打印信息
        	logger.error("打印信息:",e);
            return null;
        }
        return object;
    }
}
