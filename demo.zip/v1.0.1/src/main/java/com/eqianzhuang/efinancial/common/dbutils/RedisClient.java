package com.eqianzhuang.efinancial.common.dbutils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.stereotype.Repository;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.TreeSet;

/**
 * Redis java客户端
 * <p>
 * TODO 详细描述
 *
 *
 * @author luduntao
 * @since 2.2.4
 * @create_date 2017-7-31 下午4:37:09
 */
@Repository
public class RedisClient extends ApplicationObjectSupport {
    
    private JedisCluster jedisCluster;

    private Logger logger = LoggerFactory.getLogger(RedisClient.class);

    @Autowired
    RedisClient(JedisCluster jedisCluster){
        this.jedisCluster = jedisCluster;
    }

    /**
     * 向缓存中设置字符串内容
     *
     * @param key
     *            key
     * @param value
     *            value
     * @return
     * @throws Exception
     */
    public boolean set(String key, String value) {
        try {
            jedisCluster.set(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    /**
     * 向缓存中设置对象
     *
     * @param key
     * @param value
     * @return
     */
    public boolean set(String key, Object value) {
        try {
            jedisCluster.set(key.getBytes(), serialize(value));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除缓存中得对象，根据key
     *
     * @param key
     * @return
     */
    public boolean del(String key) {

        try {
            jedisCluster.del(key);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据key 获取内容
     *
     * @param key
     * @return
     */
    public Object get(String key) {
        try {
            byte[] value = jedisCluster.get(key.getBytes());
            return unserialize(value);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据key 获取内容
     *
     * @param key
     * @return
     */
    public String getString(String key) {
        try {
            return jedisCluster.get(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public  TreeSet<String> keys(String pattern)
    {
        try
        {
            TreeSet<String> keys = new TreeSet<>();
            Map<String,JedisPool> clusterNodes = jedisCluster.getClusterNodes();
            for(String k:clusterNodes.keySet())
            {
                JedisPool jp = null;
                Jedis connection = null;
                try
                {
                    logger.debug("Getting keys from: {}",k);
                    jp = clusterNodes.get(k);
                    connection = jp.getResource();
                    keys.addAll(connection.keys(pattern));
                } catch(Exception e)
                {
                    logger.error("Getting keys error: {}",e);
                }
                finally
                {
                    if(jp != null && connection != null)
                    {
                        logger.debug("Connection closed.");
                        jp.returnResource(connection);
                    }
                }
            }
            return keys;
        } catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public <T> T pop(String key,T t){

        try {

            if (t instanceof String){
                return (T)jedisCluster.lpop(key);
            }else{
                return (T)unserialize(jedisCluster.lpop(key.getBytes()));
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public <T> void push(String key,T val){

        try {
            if (val instanceof String){
                jedisCluster.lpush(key, (String)val);
            }else{

                jedisCluster.lpush(key.getBytes(), serialize(val));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] serialize(Object object) {
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;
        try {
            // 序列化
            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
            byte[] bytes = baos.toByteArray();
            return bytes;
        } catch (Exception e) {

        }
        return null;
    }

    public static Object unserialize(byte[] bytes) {
        ByteArrayInputStream bais = null;
        try {
            // 反序列化
            bais = new ByteArrayInputStream(bytes);
            ObjectInputStream ois = new ObjectInputStream(bais);
            return ois.readObject();
        } catch (Exception e) {

        }
        return null;
    }

}
