package com.eqianzhuang.efinancial.ai.controller;

import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.dao.DispatchUserDao;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 微信公众号平台功能相关控制器
 * @author chenbing
 *
 */
@RequestMapping(value = "/efinancial/ai/dispatcher")
@RestController
public class MsgDispatchController
{
	
	private static Log logger = LogFactory.getLog(MsgDispatchController.class);
	
	@Autowired
	private DispatchUserDao dispatchUserDao;

	@Autowired
	private AIWorker aIWorker;

	@Autowired
	private UserStatusDao userStatusDao;


    /**
     * 下线用户
     */
    @RequestMapping(value = "/stop-dispatch",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Map stopDispatch(@RequestParam("openId") String openId)
    {
        //需要用到缓存
        HashMap<String,Object> result = new HashMap<>();
        if (openId == null || openId.length() != 28) {
            result.put("code","999");
            result.put("message","openid不合法。openid=" + openId);
            logger.info("stopDispatch(),openid不合法。openid=" + openId);
        }else {
            result.put("code","0");
            result.put("message","用户："+openId+"，停止转发。");
            logger.info("stopDispatch(),停止转发。openid=" + openId);
            dispatchUserDao.deleteDispatchUser(openId);

            UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
            aIWorker.ProcessAnswerStatus996(openId,"换一批丫",userStatusEntity);

            Map<String,String> qualificationMap = userStatusEntity.getQualificationMap();
            //任何资金用途的产品
            ArrayList<String> groupProdList = aIWorker.selectGroupProdList(qualificationMap.get("zhimaScore"), qualificationMap.get("creditCard"), qualificationMap.get("userPlan"), qualificationMap.get("amount"), userStatusEntity,openId);
            userStatusEntity.setMediaNo(0);
            aIWorker.setProductGroupQuestion(groupProdList,userStatusEntity.getQuestionsSet());
            qualificationMap.put("questionNum", "0");
            qualificationMap.put("prodGroupSize",String.valueOf(groupProdList.size()));
            //更新用户状态
            userStatusDao.setUserStatusEntity( openId,userStatusEntity);
        }
        return result;
    }
    /**
     * 下线全部用户
     */
    @RequestMapping(value = "/stop-all-dispatch",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Map stopAllDispatch()
    {

        HashMap<String,Object> result = new HashMap<>();
        result.put("code","0");
        result.put("message","停止全部转发成功");
        dispatchUserDao.clearDispatchUser();
        return result;
    }
}
