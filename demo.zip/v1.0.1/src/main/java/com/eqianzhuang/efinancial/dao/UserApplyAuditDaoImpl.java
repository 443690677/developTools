/*
 * 文件名：IWechatListConfigDaoImpl.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:05:31 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import java.util.List;
import java.util.Map;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chenbing
 * @since 2.2.4
 */
@Repository
public class UserApplyAuditDaoImpl implements UserApplyAuditDao
{

    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    WeChatConfig weChatConfig;
    @Override
    public void insert(String openid,int amount , int subscribeCount, int chatCount, int weekApplyCount, int monthApplyCount,int ApplyCount) {
        jdbcTemplate.update("INSERT INTO  credit_xyb.e_financial_user_apply_audit (openid,amount,subscribeCount ,chatCount,weekApplyCount,monthApplyCount,ApplyCount,createdDate,createdBy,updatedDate,updatedBy)" +
                " VALUES (?,?,?,?,?,?,?,now(),?,now(),?);",openid,amount,subscribeCount,chatCount,weekApplyCount,monthApplyCount,ApplyCount, weChatConfig.getMediaName(openid), weChatConfig.getMediaName(openid));
    }

    @Override
    public void update(String openid,int amount ,int subscribeCount, int chatCount, int weekApplyCount, int monthApplyCount, int ApplyCount) {
        jdbcTemplate.update("UPDATE credit_xyb.e_financial_user_apply_audit SET amount = ? ,subscribeCount = ? ,chatCount = ? ,weekApplyCount = ?,monthApplyCount = ?,ApplyCount = ? ,updatedBy = ? ,updatedDate= now() WHERE openid = ?;",amount,subscribeCount,chatCount,weekApplyCount,monthApplyCount,ApplyCount, weChatConfig.getMediaName(openid),openid);
    }

    @Override
    public int selectSubscribeCount(String openid) {
        List<Map<String, Object>> subscribeCount = jdbcTemplate.queryForList("SELECT a.subscribeCount FROM credit_xyb.e_financial_user_apply_audit a WHERE openid = ?",openid);
        if (CollectionUtils.isEmpty(subscribeCount)){
            return 0;
        }
        Map<String, Object> wxTypeMap  = subscribeCount.get(0);
        if (CollectionUtils.isEmpty(wxTypeMap)){
            return 0;
        }
        return (int) wxTypeMap.get("subscribeCount");
    }

    @Override
    public int selectChatCount(String openid) {
        List<Map<String, Object>> chatCount = jdbcTemplate.queryForList("SELECT a.chatCount FROM credit_xyb.e_financial_user_apply_audit a WHERE openid = ?",openid);
        if (CollectionUtils.isEmpty(chatCount)){
            return 0;
        }
        Map<String, Object> wxTypeMap  = chatCount.get(0);
        if (CollectionUtils.isEmpty(wxTypeMap)){
            return 0;
        }
        return (int) wxTypeMap.get("chatCount");
    }
    @Override
    public int selectAmount(String openid) {
        List<Map<String, Object>> amount = jdbcTemplate.queryForList("SELECT a.amount FROM credit_xyb.e_financial_user_apply_audit a WHERE openid = ?",openid);
        if (CollectionUtils.isEmpty(amount)){
            return 0;
        }
        Map<String, Object> amountMap  = amount.get(0);
        if (CollectionUtils.isEmpty(amount)){
            return 0;
        }
        return (int) amountMap.get("amount");
    }
}
