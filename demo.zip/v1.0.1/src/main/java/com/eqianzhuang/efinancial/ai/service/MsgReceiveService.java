package com.eqianzhuang.efinancial.ai.service;

import org.springframework.scheduling.annotation.Async;

import java.util.HashMap;
import java.util.Map;

/**
 * 微信公众号相关服务
 * @author kongzhimin
 *
 */
public interface MsgReceiveService {

	/**
	 * 接收微信消息
	 */
    void receiveWeiXinMsg(Map<String, String> processRequestXml);


    boolean applyOffline(String openid, String name, String mobile, String lenderId, String cityName);


    HashMap<String,Object> applyOnline(String openid, String channel, String lenderId, String groupId, String urlId, boolean isWebChat);

    /**
     * 线下产品申请
     * @param openid   openid
     * @param channel  渠道
     * @param applyId  获客id
     * @param lenderId 产品id
     * @param outChnId  出库渠道号编号
     * @param outChnCode  出库渠道号
     * @param outRuleId  入库规则编号
     * @return
     */

    void advisorMenu(String openid);

}
