/*
 * 文件名：IWechatListConfigDao.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:00:01 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import java.util.Date;
import java.util.List;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年7月31日 下午5:00:01
 */
public interface V3CpaApplyRec
{
    List<String> selectProdApplyRec(String openid, Date date);

    List<String> selectApplyRec(String openid, Date date);
}
