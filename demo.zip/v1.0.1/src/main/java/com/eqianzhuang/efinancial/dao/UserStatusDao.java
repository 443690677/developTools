package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.entity.UserStatusEntity;

import java.util.HashSet;

public interface UserStatusDao {

    //获取用户
    UserStatusEntity getUserStatusEntity(String openId);

    void setUserStatusEntity(String openId,UserStatusEntity UserStatus);

    void delUserStatusEntity(String openId);

    UserStatusEntity updateLastDate(String openId);

    HashSet<String> getOnlineUsers(String openidPrefix);

    //初始化用户资质
    void initUserQualification(String openId, UserStatusEntity userStatusEntity);
}
