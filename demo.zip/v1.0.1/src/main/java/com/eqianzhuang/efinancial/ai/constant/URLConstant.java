package com.eqianzhuang.efinancial.ai.constant;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;

@Component
public class URLConstant {

    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    RedisClient redisClient;

    @Autowired
    WeChatConfig weChatConfig;

    /**
     * 欢迎语
     */
    public static JSONArray WELCOME_MSG  = new JSONArray();

    /**
     *菜单，问客户需要什么服务
     */
    public static JSONObject QUESTIONS30_MENU = new JSONObject();

    /**
     * 问金额
     */
    public static  String QUESTIONS0="请问要贷多少钱呢？我们的贷款金额可在500元~20万元之间的";


    /**
     * 问信用卡
     */
    public static  String QUESTIONS3="请问信用卡使用是否超过6个月呢？";

    /**
     * 芝麻分
     */
    public static  String QUESTIONS4="ok，芝麻分有多少分啊？";

    /**
     * 贷款偏好
     */
    public static  String QUESTIONS6="好的，对贷款产品有什么要求呢" +
            "\n1.费用低" +
            "\n2.批款快" +
            "\n3.额度高" ;

    /**
     * 贷款偏好的KEK
     */
    public static  String QUESTIONS6_KEY = "[\"费用低\",\"批款快\",\"额度高\"]";

    /**
     *问社保
     */
    public static  String QUESTIONS7="好，请问社保缴纳有超过六个月么";


    /**
     * 问公积金
     */
    public static  String QUESTIONS10 = "你有公积金么？";

    /**
     * 问逾期
     */
    public static  String QUESTIONS11 = "征信有没有逾期呢？";

    /**
     * 问车
     */
    public static  String QUESTIONS12 = "了解一下有没有车啊？";

    /**
     * 问房
     */
    public static  String QUESTIONS13 = "请问有房么？";

    /**
     * 问保单
     */
    public static  String QUESTIONS14 = "有没有寿险保单呢？";


    /**
     * 问淘宝账号
     */
    public static  String QUESTIONS15 = "请问是否使用过淘宝呢？";

    /**
     * 问收入
     */
    public static  String QUESTIONS16 = "好的，月收入是否大于3000啊?";

    /**
     * 问代发
     */
    public static  String QUESTIONS17 = "请问工资是否银行代发？";


    /**
     * 引导到菜单
     */
    public static  String TO_MENU_REPLY = "推荐了这么多产品你都没申请\uD83D\uDE31，若还需要借钱，也可以直接点击菜单【我要】-【找产品】挑选心仪的产品，马上有钱！" ;

    public static String AI_TIPS1 = "以后需要贷款再来找我吧，也可以直接点击菜单【我要】-【找产品】挑选心仪的产品，马上有钱！" ;

    public static String AI_TIPS7 = "根据您的资质已经全部推荐给您啦，可以过一段时间再试试，我们会有新的产品上线也许可以申请哦。";

    public static String AI_TIPS12 = "您需要咨询什么？";

    public static String AI_TIPS13 = "请选择您所需要的服务。";

    public static String AI_TIPS14 = "上次了解您要贷款 ${amount} 元，想了解下您的信用卡是否超过6个月，我们更精准推荐产品。";

    public static String AI_TIPS15 = "了解您要贷款 ${amount} 元，我们有很多产品是要芝麻分的，您的芝麻分是多少，好给您推荐。";

    public static String AI_TIPS16 = "其他满足条件能申请产品如下：\n";

    public static String AI_TIPS17 = "您的芝麻分超过600分，或者信用卡使用超过6个月，可以申请下面这几个产品：\n";

    public static String AI_TIPS20 = "申请 ${amount} 元比较简单，在此之前想了解下您的其它资质信息，看看有什么样的产品合适你。";

    public static String AI_TIPS21 = "申请 ${amount} 元比较简单，一般在1-2天就能到款，在此之前想了解下您的其它资质信息，以便帮你出谋划策。";

    public static String AI_TIPS22 = "申请 ${amount} 元涉及的金额比较大，我需要详细了解下你的信息，以便更好的帮你推荐产品。";

    public static String AI_TIPS24 = "根据你的资质，初步筛选出 ${prodGroupSize} 个符合你的产品。";

    public static String AI_TIPS25 = "你好，欢迎咨询你的私人贷款顾问，目前只能贷500~20万，请问你需要贷多少钱呢?";


    public static String AI_TIPS27 = "[\"1.一对一服务,借钱，我要借钱，贷款，我要贷款，借款\",\"2.推荐可申请产品\",\"3.贷款问题咨询\"]";

    public static String AI_TIPS28 = "[\"1.不合适\",\"2.不想借\",\"3.已经申请过\"]";

    public static String AI_TIPS30 = "那下次想借钱记得来找小易哦～么么哒";


    /**
     *主流程发送产品的语音
     */
    public static JSONObject AI_TIPS41 = new JSONObject();

    public static String AI_TIPS42 = "<#if nickname?? >${nickname}<#else>贷款用户</#if>您好，感谢关注；您之前贷款%s有变化吗，麻烦说下您要贷款金额。";

    public static String AI_TIPS43 = "欢迎再次关注，回复\"借钱\"我们继续为您服务";

    public static String AI_TIPS45 = "80%%的用户申请7个产品才成功拿到钱，您当前申请了%d个产品，批款可能性为%d%%，建议您多申请几个小易推荐的产品，更容易拿到钱哦。";

    public static String AI_TIPS46 = "要借%s元您可以尝试多申请几个小易推荐产品，因为不是一申请就100%%下款的。要想借到钱，千万不要怕麻烦";

    public static String AI_TIPS47 = "每个机构的风控是不一样的，这家拒贷不代表另一家也不给您批款，换个贷款产品申请说不定就拿到钱了，您可以多申请几个小易推荐的产品";

    public static String AI_TIPS51 = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，以下是根据您的信息推荐的贷款解决方案，点击即可申请：\n";

    public static String AI_TIPS52 = "<#if nickname?? >${nickname}<#else>贷款用户</#if> 您好，以下是最新上线好口子，点击即可申请：\n";

    public static String AI_TO_URL = "\uD83D\uDC49<a href=\"%s/efinancial/ai/to-online?openid=%s&channel=%s&lenderId=%s&groupId=%s&urlId=%s\">%s</a>\n\n";

    public static String AI_TO_URL_OFFLINE = "%s/under/index.html?openId=%s&lenderId=%s&name=%s&mobile=%s&source=AI_R1004&groupId=25016&channel=%s";


    public static String AI_TIPS29 = "%s/xyguwen/index.html?menuId=30019&source=AI_R1001#/personal";

    public static String AI_TIPS31 = "%s/Aiwts/index.html?menuId=30018&source=AI_R1002";

    public static String AI_TIPS53_URL = "%s/jzpp/index.html?openId=%s&groupId=25030&channel=%s&pageType=P1056&source=R1041";
    public static String AI_TIPS53 = "查看更多产品";

    public static String AI_TIPS54_URL = "%s/pro20/index.html?openId=%s&groupId=25038&channel=%s&pageType=P1040&source=R1029";
    public static String AI_TIPS54 = "查看更多产品";

    public static JSONObject AI_TIPS54_VOICE  = new JSONObject();


    /**
     * "放水"关键字下发话术
     */
    public static String AI_TIPS55_START  = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，机构大放水啦，申请下面这些产品审核超好通过~\n";
    public static String AI_TIPS55_END = "（缺钱别错过，赶紧申请吧）\n\n";
    public static String AI_TIPS55_MORE_URL = "%s/pro20/index.html?openId=%s&groupId=25049&channel=%s&pageType=P1050&source=R1027";
    public static String AI_TIPS55_MORE = "查看更多产品";

    /**
     * "不查征信"关键字下发话术
     */
    public static String AI_TIPS56_START = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，下面这些贷款产品都不查征信哦，请放心申请\n" ;
    public static String AI_TIPS56_END = "（极速放款，实力秒批）\n\n";
    public static String AI_TIPS56_MORE_URL = "%s/pro20/index.html?openId=%s&groupId=25050&channel=%s&pageType=P1051&source=R1028";
    public static String AI_TIPS56_MORE = "查看更多产品" ;

    public static String AI_TIPS57 = "你之前申请的【%s】、【%s】有被拒的么？回复您申请情况，我们给您推荐新方案" ;

    public static String AI_TIPS58_START = "根据您提交的信息，为您制定的贷款方案如下：\n" +
            "第一步：申请下面的产品，至少两个【待完成】\n" ;
    public static String AI_TIPS58_END = "第二步：把申请结果告诉小易，我根据结果为您调整方案，直到帮你借到钱【待完成】\n" +
            "第三步：再申请几个小易给您推荐的贷款产品【待完成】\n" +
            "第四步：80%的用户走到这一步都借到钱了\n" +
            "温馨提示：您目前处于第一步，一定要申请两个以上产品哦！\n" +
            "据统计，93%借到钱的人都申请了至少两个以上产品";

    public static String AI_TIPS59_START = "先恭喜亲借到钱啦，根据您的反馈给您制定的贷款方案如下：\n" +
            "第一步：申请下面的产品，至少两个【您已完成】\n" +
            "第二步：把申请结果告诉小易，我根据结果为您调整方案，直到帮你借到钱【您已完成】\n" +
            "第三步：再申请几个小易给您推荐的贷款产品【待完成】\n" ;
    public static String AI_TIPS59_END = "第四步：80%的用户走到这一步都借到钱了\n" +
            "温馨提示：您目前处于第三步，如果还需要借钱的话，可以继续选择上面小易为您挑选的产品进行申请哦！";


    public static String AI_TIPS60_START = "申请贷款被拒也别灰心哦，82.7%贷款成功的人都曾被拒过，根据您的反馈给您重新制定的贷款方案如下：\n" +
            "第一步：申请下面的产品，至少两个【您已完成】\n" +
            "第二步：把申请结果告诉小易，我根据结果为您调整方案，直到帮你借到钱【您已完成】\n" +
            "第三步：再申请几个小易给您推荐的贷款产品【待完成】\n" ;
    public static String AI_TIPS60_END = "第四步：80%%的用户走到这一步都借到钱了\n" +
            "温馨提示：您目前处于第三步，据统计借到钱的人平均申请产品数量为5个，你已申请了%d个，建议继续多申请几个小易上面给你挑选的贷款产品，马上就能拿到钱啦！\n\n";



    /**
     * "低息"关键字下发话术
     */
    public static String AI_TIPS66_START = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，这是小易精心为您挑选的低息好口子，请放心申请[坏笑]\n" ;
    public static String AI_TIPS66_END = "（缺钱别错过，赶紧申请吧）\n\n";
    public static String AI_TIPS66_MORE_URL = "%s/pro20/index.html?openId=%s&groupId=25061&channel=%s&pageType=P1055&source=R1040";
    public static String AI_TIPS66_MORE = "查看更多产品" ;

    /**
     * "白户"关键字下发话术
     */
    public static String AI_TIPS67_START = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，下面这些口子白户也能贷，速来申请：[耶]\n" ;
    public static String AI_TIPS67_END = "（秒批放款，缺钱别错过）\n\n";
    public static String AI_TIPS67_MORE_URL = "%s/pro20/index.html?openId=%s&groupId=25062&channel=%s&pageType=P1053&source=R1038";
    public static String AI_TIPS67_MORE = "查看更多产品" ;

    /**
     * "大额"关键字下发话术
     */
    public static String AI_TIPS68_START = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>，申请下面这些不愁钱，大额度超长分期还款无压力[转圈]\n" ;
    public static String AI_TIPS68_END = "（极速放款，实力秒批）\n\n";
    public static String AI_TIPS68_MORE_URL = "%s/pro20/index.html?openId=%s&groupId=25063&channel=%s&pageType=P1054&source=R1039";
    public static String AI_TIPS68_MORE = "查看更多产品" ;


    public static String AI_TIPS70 = "您也可以尝试申请一下最近批款还不错的产品:\n" +
            "为您推荐无需太多资质就能贷到款的产品，制定拿到钱的方案如下：\n" +
            "*第一步：请申请下面产品中的两个以上\n";

    public static String AI_TIPS71 = "第二步：把申请结果告诉小易,小易根据您的结果调整方案\n"+
            "第三步；再申请两个产品\n"+
            "第四步：80%用户在这一步成功拿到钱\n"+
            "温馨提示：当前您处于第一步，需要您自己申请两个产品，然后反馈情况才有贷款到款的可能哦。";

    public static String AI_TIPS72 = "为了能帮您快速贷到款，再了解您最后一项资质。";

    public static String AI_TIPS73 = "为了能帮您快速贷到款，了解最后%d个资质。给您做更加准确的贷款产品推荐。";

    public static String AI_TIPS74 = "亲爱的 <#if nickname?? >${nickname}<#else>贷款用户</#if>,当前芝麻分${zhimaScore}，<#if creditCard == \"True\" >有<#else>无</#if>信用卡，超越80%的用户，为您制定拿到钱的方案如下：\n"+
                                        "*第一步：请申请下面产品中的两个以上\n";

    public static String AI_TIPS75 = "第二步：把申请结果告诉小易，小易根据您的结果调整方案\n" +
            "第三步：再申请两个产品\n" +
            "第四步：80%用户在这一步成功拿到钱\n" +
            "温馨提示：当前您处于第一步，需要您自己申请两个产品，然后反馈情况才有贷款到款的可能哦。";

    public static String AI_TIPS76 = "半小时给您推荐的产品记得申请哈，多申请几个能提高贷款成功率。如果申请了3个以上，回复“下一步”给您推荐新的贷款方案；\n" +
            "根据您提交的信息，为您制定的贷款方案如下：\n"+
            "第一步：申请下面的产品，至少两个【待完成】\n" ;

    public static String AI_TIPS77 ="当前您处于【第一步】，建议尝试申请之前推荐给您还未申请的产品。那些都是比较靠谱的产品。";

    public static String AI_TIPS78 = "昨天给您推荐的产品记得申请哈，多申请几个能提高贷款成功率。如果申请了3个以上，回复“下一步”给您推荐新的贷款方案；\n" +
            "根据您提交的信息，为您制定的贷款方案如下：\n"+
            "第一步：申请下面的产品，至少两个【待完成】\n" ;
    public static String AI_TIPS79 = "<#if creditCard?? ><#if creditCard == \"True\" >有<#else>无</#if>信用卡，</#if><#if zhimaScore?? >当前芝麻分${zhimaScore}，</#if>您满足条件能申请产品如下：\n";

    public static String AI_TIPS80 = "好的";

    public static String AI_TIPS82 = "符合您资质的产品已推荐完了，这些都没有批到款吗？";


    public static String AI_TIPS83 = "你想要的是产品如下，点击产品名进行申请：\n";


    public static String AI_TIPS84 = "可以直接点击菜单【我要】-【找产品】挑选心仪的产品，马上有钱！";

    public static JSONObject AI_TIPS85 = new JSONObject();


    /**
     * 机构反馈状态流程
     */
    // 未注册提问
    public static String AI_Q_FEEDBACK2 = "亲爱的%s，您申请的【51人品贷】还未完成信息验证获取额度,具体是什么原因呢？\n" +
        "1.已经验证了，但是没有额度\n" +
        "2.太麻烦了，不想验证\n" +
        "3.验证中遇到了问题，进行不下去\n" +
        "4.其他";
    // 未注册ai匹配选项
    public static String AI_FEEDBACK2 = "[\"1.已经验证了，但是没有额度\",\"2.太麻烦了，不想验证\",\"3.验证中遇到了问题，进行不下去\",\"4.其他\"]";

    public static String AI_FEEDBACK2_EASY_PASS_MSG = "帮你推荐几款比较容易通过的产品\n";
    public static String AI_FEEDBACK2_EASY_PASS_URL = "%s/pro20/index.html?openId=%s&groupId=25125&channel=%s&pageType=P1027&source=R10921";
    public static String AI_FEEDBACK2_EASY_PASS = "\uD83D\uDC49点我立即申请";

    public static String AI_FEEDBACK2_EASY_OPS_MSG = "帮你推荐几款申请操作简单的产品\n";
    public static String AI_FEEDBACK2_EASY_OPS_URL = "%s/pro20/index.html?openId=%s&groupId=25126&channel=%s&pageType=P1027&source=R10922";
    public static String AI_FEEDBACK2_EASY_OPS = "\uD83D\uDC49点我立即申请";

    // 未验证提问
    public static String AI_Q_FEEDBACK3 = "亲爱的%s，您申请的【51人品贷】还未完成运营商验证,具体是什么原因呢？\n" +
        "1.不愿意验证运营商、查询通讯录\n" +
        "2.已经验证但没有通过\n" +
        "3.其他\n\n";
    public static String AI_FEEDBACK3 = "[\"1.不愿意验证运营商、查询通讯录\",\"2.已经验证但没有通过\",\"3.其他\"]";
    public static String AI_FEEDBACK3_URL = "%s/bYouQian/index.html?pageType=P1027&source=AI_R1093&resultUrl=http://u51.me/3pg1";
    public static String AI_FEEDBACK3_TIPS = "\uD83D\uDC49点我继续验证";

    //消息2：（语音3）验证完运营商就可以进入审核阶段啦，在此过程中您会收到多条短信信息，属正常情况：
    public static JSONObject AI_FEEDBACK3_VOICE = new JSONObject();

    // 未提交订单
    public static String AI_Q_FEEDBACK4 = "亲爱的%s，您在【51人品贷】还未提交借款申请，具体是什么原因呢？\n" +
        "1.资金已解决，不需要贷款了\n" +
        "2.暂时不需要，过两天再申请\n" +
        "3.利息太高，不想要了\n" +
        "4.其他\n" +
        "只有提交申请后才会进入贷款审核，赶紧去APP上完成吧！[机智] \n";
    public static String AI_FEEDBACK4_URL = "%s/bYouQian/index.html?pageType=P1027&source=AI_R1094&resultUrl=http://u51.me/3pg1";
    public static String AI_FEEDBACK4_TIPS = "\uD83D\uDC49点我继续申请";
    public static String AI_FEEDBACK4 = "[\"1.资金已解决，不需要贷款了\",\"2.暂时不需要，过两天再申请\",\"3.利息太高，不想要了\",\"4.其他\"]";



    //初始化所以静态常量
    @PostConstruct
    private void init(){

        {
            WELCOME_MSG = new JSONArray();
            String content = "借钱找小易，这就对了！！！\n这里有300多个贷款产品供您选择，每天有3-5款产品更新，500~20万贷款在这里一定能快速满足需求。\n" +
                    "您现在想要：\n" +
                    "1.借钱，小易为您一对一推荐\n" +
                    "2.推荐几个合适产品，您自己挑\n" +
                    "3.贷款问题咨询\n" +
                    "（输入数字回复哦）";
            JSONObject msg  = new JSONObject();
            msg.put("msgtype","text");
            JSONObject text = new JSONObject();
            text.put("content",content);
            msg.put("text",text);
            JSONObject msg1 = new JSONObject();
            msg1.put("default",msg);
            WELCOME_MSG.add(msg1);
        }

        {
            String content  = "被发现了^_^，点【在线顾问】菜单可以随时撩小易哦~\n\n" +
                    "小易做贷款咨询5年了，跟60多家贷款公司都很熟呢，\n" +
                    "只要告诉我您的需求和情况，就能帮您挑选最合适的贷款，快速拿到钱呢。\n\n" +
                    "您现在想要：\n" +
                    "1.借钱，小易为您一对一推荐\n" +
                    "2.推荐几个合适产品，自己挑\n" +
                    "3.贷款问题咨询\n" +
                    "（输入数字回复哦）";

            JSONObject msg  = new JSONObject();
            msg.put("msgtype","text");
            JSONObject text = new JSONObject();
            text.put("content",content);
            msg.put("text",text);
            QUESTIONS30_MENU.put("default",msg);
        }

        //语音消息与公众号绑定，无法初始化，需在线上配置。
        {
            String media_id  = "VmaR01zIIa6sRxOp9FWIaXTFP-t-B5Ug-_6ykz3CvQ0";
            JSONObject msg  = new JSONObject();
            msg.put("msgtype","voice");
            JSONObject voice = new JSONObject();
            voice.put("media_id",media_id);
            msg.put("voice",voice);
            AI_TIPS41.put("default",msg);
            AI_TIPS54_VOICE.put("default",msg);
            AI_FEEDBACK3_VOICE.put("default",msg);
        }

        {

            JSONObject article = new JSONObject();
            String title = "<#if nickname?? >${nickname} <#else>急用钱？</#if>这些口子超适合你借，3分钟到账20000！";
            article.put("title",title);
            article.put("description","");
            article.put("picurl","http://imgsrc.baidu.com/forum/pic/item/36a58c16fdfaaf5152846fae805494eef11f7aff.jpg");

            JSONArray articles = new JSONArray();
            articles.add(article);
            JSONObject news = new JSONObject();
            news.put("articles",articles);

            JSONObject msg = new JSONObject();
            msg.put("msgtype","news");
            msg.put("news",news);
            AI_TIPS85.put("default",msg);
        }






        Class uRLConstant = URLConstant.class;
        Field[] fields = URLConstant.class.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {

            Field field= fields[i];

            String key = weChatConfig.getConstantKeyPrefix() + field.getName();

            String fieldsValue = redisClient.getString(key);
            if (!StringUtils.isEmpty(fieldsValue)) {
                if ("java.lang.String".equals(field.getGenericType().getTypeName())) {
                    try {
                        field.set(uRLConstant,fieldsValue);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }

                if ("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName())) {
                    try {
                        field.set(uRLConstant,redisClient.get(key));
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }

                if ("com.alibaba.fastjson.JSONArray".equals(field.getGenericType().getTypeName())) {
                    try {
                        field.set(uRLConstant,redisClient.get(key));
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }

            }
        }
    }


    @Scheduled(cron="0 */5 * * * ? ")
    public void redisToConstant() {
        init();
    }

}
