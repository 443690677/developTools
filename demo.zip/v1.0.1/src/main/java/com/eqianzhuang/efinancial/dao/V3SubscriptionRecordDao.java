package com.eqianzhuang.efinancial.dao;

public interface V3SubscriptionRecordDao {

    void delete(String openid);
}
