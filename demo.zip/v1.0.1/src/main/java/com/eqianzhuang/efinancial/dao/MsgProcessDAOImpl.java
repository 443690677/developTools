package com.eqianzhuang.efinancial.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MsgProcessDAOImpl implements MsgProcessDAO {


    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public void insertMsg(String othId, String openId, String nickName, int cType, String content, String remark, String label) {
        jdbcTemplate.update(" INSERT INTO credit_agency.v2_chat_log(openId,othId,nickName,cType,content,remark,label,currTime) VALUES ( ?,?,?,?,?,?,?,now());",openId,othId,nickName,cType,content,remark,label);
    }

    @Override
    public void addWeChatMenuOr(String wxType ,int menuId ,String openId) {
        jdbcTemplate.update("INSERT INTO credit_cpa.wechat_menu_or (wx_type, menu_id, openId, create_time) VALUES ( ? , ?, ?, now());",wxType,menuId,openId);
    }

}
