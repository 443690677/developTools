/*
 * 文件名：IWechatListConfigDaoImpl.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:05:31 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年7月31日 下午5:05:31
 */
@Repository
public class V3CusAptitudeAiDaoImpl implements V3CusAptitudeAiDao
{


    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    WeChatConfig weChatConfig;
    
    @Override
    public Map getCusAptitudeAi(String openid) {
        try {
            String SQL = "SELECT t.* FROM credit_cpa.v3_cus_aptitude_ai t WHERE t.open_id = ? ORDER BY create_time DESC LIMIT 1;";
            return  jdbcTemplate.queryForMap(SQL,openid);
        }catch (Exception e){
            e.printStackTrace();
        }
        return new HashMap<>();
    }

    @Override
    public void updateCusAptitudeAi(String open_id, String field_name, String field_value,String unionId, String wx_type) {
        jdbcTemplate.update("update credit_cpa.v3_cus_aptitude_ai set "+field_name+"=? ,unionid=?,wx_type=?,update_time=now(),update_user=? where open_id=?;"
                            ,field_value,unionId,wx_type, weChatConfig.getMediaName(open_id),open_id);

    }

    @Override
    public void insertCusAptitudeAi(String open_id, String field_name, String field_value, String unionId, String wx_type) {
        jdbcTemplate.update("insert into credit_cpa.v3_cus_aptitude_ai (open_id,"+field_name+",unionid,wx_type,create_user,create_time,update_user,update_time) values " +
                "(?,?,?,?,?,now(),?,now())",open_id,field_value,unionId,wx_type, weChatConfig.getMediaName(open_id), weChatConfig.getMediaName(open_id));
    }

    @Override
    public Integer selectV3CustomerAI(String mobile) {
        try {
            String SQL = "SELECT count(*) from credit_cpa.v3_customer_ai a where a.mobile = ? ;";
            return  jdbcTemplate.queryForObject(SQL,Integer.class,mobile);
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void updateCustomerAI(String full_name,String mobile,String city_id,String amount,String openid) {

        jdbcTemplate.update("update credit_cpa.v3_customer_ai set name= ?,city_id=?,amount=?,update_time=now(),update_user=? where mobile = ?",
                full_name,city_id,amount, weChatConfig.getMediaName(openid),mobile);

    }

    @Override
    public void insertCustomerAI(String full_name,String mobile,String city_id,String amount,String openid) {
        jdbcTemplate.update("insert into credit_cpa.v3_customer_ai( full_name,mobile,city_id,amount,create_user,create_time,update_user,update_time) " +
                "   values(?,?,?,?,?,now(),?,now());",
                full_name,mobile,city_id,amount, weChatConfig.getMediaName(openid), weChatConfig.getMediaName(openid));

    }

    @Override
    public Map selectUpdateOr(String open_id, String field_name) {
        long day30 = 30 * 24 * 60 * 60 * 1000L;
        //只查30天内的数据
        Date date = new Date(System.currentTimeMillis() - day30 );
        try {
            String SQL = "SELECT t.* FROM credit_cpa.v3_aptitude_ops t WHERE t.open_id = ? AND t.field_name = ?  AND create_time >= ? ORDER BY create_time DESC LIMIT 1;";
            return  jdbcTemplate.queryForMap(SQL,open_id,field_name,sdf.format(date));
        }catch (Exception e){
            e.printStackTrace();
        }
        return new HashMap<>();
    }

    
    @Override
    public void insertUpdateOr(String open_id, String field_name, String field_value) {
        jdbcTemplate.update("INSERT INTO credit_cpa.v3_aptitude_ops ( open_id, field_name, field_value, create_user, create_time)" +
                        "VALUES (?,? ,?,?, NOW());",
                          open_id,field_name,field_value, weChatConfig.getMediaName(open_id));
    }


    @Override
    public void insertUserAction(String openid, String action_name, String action_content) {
        jdbcTemplate.update("INSERT INTO credit_xyb.e_financial_v3_user_action ( openid, action_name, action_content, created_by ,created_date)" +
                        " VALUES (?,?,?,?,NOW());",
                            openid,action_name,action_content, weChatConfig.getMediaName(openid));

    }
    /**
     * 根据产品资质筛选条件判断用户资质是否符合
     * @param openId 用户openId
     * @param sql 产品资质筛选条件
     * @return int 1:满足，0：不满足
     */
    @Override
    public int checkCusAptitudeIsSatisfy(String openId, String sql) {
        String exSql = "SELECT COUNT(1) FROM credit_cpa.v3_cus_aptitude_ai WHERE open_id = ? AND " + sql;
        return jdbcTemplate.queryForObject(exSql,Integer.class, openId);
    }

    /**
     * 根据产品城市组要求判断用户资质是否符合
     * @param openId 用户openId
     * @param param 产品城市组筛选条件
     * @return 1:满足，0：不满足
     */
    @Override
    public int checkCusCitysIsSatisfy(String openId, String param) {
        String exSql = "SELECT  COUNT(1) FROM credit_cpa.v3_cus_aptitude_ai cai_ WHERE cai_.open_id = ? AND FIND_IN_SET( "
                + "cai_.city_id, (SELECT dg_.cityIds FROM credit_cpa.v3_dispatchcityb_group dg_ WHERE dg_.id = "+param+"))";
        Integer obj = jdbcTemplate.queryForObject(exSql, Integer.class, openId);
        if ( obj > 0){
            return 1;
        }
        return 0;
    }

}
