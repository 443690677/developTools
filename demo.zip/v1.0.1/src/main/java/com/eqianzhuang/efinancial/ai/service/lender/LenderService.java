package com.eqianzhuang.efinancial.ai.service.lender;

import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.alibaba.fastjson.JSONObject;

/**
 * 产品相关Service
 * 
 * @author huangzhigang
 */
public interface LenderService {

	/**
	 * 推荐产品
	 * @param message 消息内容JSON-{"openId":"","text":"","groupId":"","match":1/2,"num":10}
	 * @return ResponseEntity<Map<String,Object>>
	 */
	ResponseEntity<Map<String,Object>> recLender(JSONObject message);
	
}
