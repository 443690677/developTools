package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import redis.clients.jedis.JedisCluster;

import javax.annotation.PostConstruct;

@Repository
public class DispatchUserDaoImpl implements DispatchUserDao {

    private static String redisKey ;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    private JedisCluster jedisCluster;

    @PostConstruct
    private void init(){
        redisKey = weChatConfig.getDispatchUserKey();
    }

    @Override
    public void setDispatchUser(String openId) {
        long size = jedisCluster.scard(redisKey);
        if ( size > 512) {
            logger.info("转发用户达到上限512。");
        }else {
            jedisCluster.sadd(redisKey,openId);
        }
    }

    @Override
    public boolean isDispatchUser(String openid) {
        return jedisCluster.sismember(redisKey,openid);
    }

    @Override
    public void deleteDispatchUser(String openId) {
        jedisCluster.srem(redisKey,openId);
    }

    @Override
    public void clearDispatchUser() {
        jedisCluster.del(redisKey);
    }
}
