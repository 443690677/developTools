package com.eqianzhuang.efinancial.dao.sysparam.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.eqianzhuang.efinancial.dao.sysparam.SysParamDao;

/**
 * 系统设置 Dao impl
 * @author huangzhigang
 */
@Repository
public class SysParamDaoImpl implements SysParamDao {

	@Autowired
    JdbcTemplate jdbcTemplate;
	
	@Override
	public String getByPName(String pName) {
		return jdbcTemplate.queryForObject("SELECT pValue FROM credit_cpa.v2_sys_paramter WHERE pName = ? limit 1",String.class, pName);
	}

	@Override
	public String getByNameAndType(String pType, String pName) {
		return jdbcTemplate.queryForObject("SELECT pValue FROM credit_cpa.v2_sys_paramter WHERE pName = ? AND pType = ? limit 1", String.class,pName ,pType);
	}

}
