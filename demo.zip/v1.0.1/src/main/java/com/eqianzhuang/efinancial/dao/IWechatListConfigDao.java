/*
 * 文件名：IWechatListConfigDao.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:00:01 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import com.alibaba.fastjson.JSONArray;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;

import java.util.List;
import java.util.Map;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年7月31日 下午5:00:01
 */
public interface IWechatListConfigDao
{

    Map<String,Object> getProdInfoByLenderId(Integer lenderId);

    List<Map<String,Object>> getProdInfoByGroupId(String groupId, UserStatusEntity userStatusEntity, String openId);

    String getProdNameByLenderId(String lenderId);

    List<Map<String, Object>> getProdInfoByName(JSONArray prodName);

    List<Map<String, Object>> getProductAttr(String lenderid);

	void addWxOps(String openId, String wechat_type, String mark, String words, String prod_id, String source, String remarks);
}
