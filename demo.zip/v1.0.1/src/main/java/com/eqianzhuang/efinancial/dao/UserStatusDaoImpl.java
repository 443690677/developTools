package com.eqianzhuang.efinancial.dao;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.ai.service.AdditionalDataService;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;


@Repository
public class UserStatusDaoImpl implements UserStatusDao {


    protected Log logger = LogFactory.getLog(this.getClass());

    private V3CusAptitudeAiDao v3CusAptitudeAiDao;

    private WeiXinUserInfoUtil weiXinUserInfoUtil;

    private RedisClient redisClient;

    private UserApplyAuditDao userApplyAuditDao;

    private V3CpaApplyRec v3CpaApplyRec;

    @Autowired
    private AdditionalDataService additionalDataService;

    @Autowired
    UserStatusDaoImpl(V3CusAptitudeAiDao  v3CusAptitudeAiDao,  WeiXinUserInfoUtil weiXinUserInfoUtil,RedisClient redisClient,UserApplyAuditDao userApplyAuditDao,V3CpaApplyRec v3CpaApplyRec){
        this.v3CusAptitudeAiDao = v3CusAptitudeAiDao;
        this.weiXinUserInfoUtil = weiXinUserInfoUtil;
        this.redisClient = redisClient;
        this.userApplyAuditDao = userApplyAuditDao;
        this.v3CpaApplyRec = v3CpaApplyRec;
    }

    private static String  redisKeyPrefix = "UserStatus_wxba7248accdeb1e56";

    @Override
    public UserStatusEntity getUserStatusEntity(String openId) {

        Object object = redisClient.get( redisKeyPrefix+openId);
        if ( object == null) {
            return null;
        }
        return (UserStatusEntity)object;
    }


    public void setUserStatusEntity(String openId,UserStatusEntity UserStatus) {
        redisClient.set(redisKeyPrefix+openId,UserStatus);
    }

    @Override
    public void delUserStatusEntity(String openId) {

        UserStatusEntity userStatusEntity = getUserStatusEntity(openId);
        if ( userStatusEntity != null )
        {
            if (userStatusEntity.isInsertUserQualification()){
                weiXinUserInfoUtil.insertUserQualification(openId,userStatusEntity.getQualificationMap());
            }

            HashMap<String,String> qualification=  userStatusEntity.getQualificationMap();

            String subscribeCountStr =  qualification.get("subscribeCount");
            int subscribeCount = 1;
            if (!StringUtils.isEmpty(subscribeCountStr)){
                subscribeCount = Integer.valueOf(subscribeCountStr);
            }

            String chatCountStr =  qualification.get("chatCount");
            int chatCount = 1;
            if (!StringUtils.isEmpty(chatCountStr)){
                chatCount = Integer.valueOf(chatCountStr);
            }

            int amount = 0;
            String amountStr = qualification.get("amount");
            if (ValidUtils.isNumeric(amountStr) && amountStr.length() < 8) {
                amount = Integer.valueOf(amountStr);
            }

            long weekTime = System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000L;
            int weekApplyCount = v3CpaApplyRec.selectProdApplyRec( openId,new Date(weekTime)).size();
            long monthTime = System.currentTimeMillis() - 30 * 24 * 60 * 60 * 1000L;
            int monthApplyCount = v3CpaApplyRec.selectProdApplyRec( openId,new Date(monthTime)).size();
            int ApplyCount = v3CpaApplyRec.selectProdApplyRec( openId,new Date(0L)).size();

            if ( userApplyAuditDao.selectChatCount(openId) == 0 ) {
                userApplyAuditDao.insert(openId,amount,subscribeCount,chatCount,weekApplyCount,monthApplyCount,ApplyCount);
            }else {
                userApplyAuditDao.update(openId,amount,subscribeCount,chatCount,weekApplyCount,monthApplyCount,ApplyCount);
            }
        }

        redisClient.del(redisKeyPrefix + openId);
    }

    @Override
    public UserStatusEntity updateLastDate(String openId) {

        UserStatusEntity userStatusEntity = getUserStatusEntity(openId);

        if(userStatusEntity == null){
            userStatusEntity = new UserStatusEntity();
            initUserQualification(openId,userStatusEntity);
        }
        userStatusEntity.setLastSessionDate(System.currentTimeMillis());
        setUserStatusEntity(openId,userStatusEntity);
        return  userStatusEntity;
    }

    @Override
    public HashSet<String> getOnlineUsers(String openidPrefix) {
        HashSet<String> openIds = new HashSet<>();
        TreeSet<String> keySet = redisClient.keys(redisKeyPrefix + openidPrefix + "*");
        if (CollectionUtils.isEmpty(keySet)){
            return openIds;
        }else {
            for (String key :keySet){
                if (key.length() == 57) {
                    openIds.add(key.substring( redisKeyPrefix.length(),key.length()));
                }else {
                    redisClient.del(key);
                }
            }
            return openIds;
        }
    }

    //初始化用户资质
    @Override
    public void initUserQualification(String openId, UserStatusEntity userStatusEntity){

        HashMap<String,String> UserQualification = userStatusEntity.getQualificationMap();
        //从个人中心同步资质到session
        Map qualification  = v3CusAptitudeAiDao.getCusAptitudeAi(openId);
        if (!CollectionUtils.isEmpty(qualification)){

            String  full_name = String.valueOf(qualification.get("full_name"));
            if (ValidUtils.validName(full_name) && !CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"full_name"))){
                UserQualification.put("name",full_name);
            }

            String mobile = String.valueOf(qualification.get("mobile"));
            if (!StringUtils.isEmpty(mobile)&& mobile.length() == 11&&!CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"mobile"))){
                UserQualification.put("mobile",mobile);
            }

            String  credit_card = String.valueOf(qualification.get("credit_card"));

            if ("1".equals(credit_card)|| "4".equals(credit_card) ){
                UserQualification.put("creditCard_DC","True");
            } else {
                UserQualification.put("creditCard_DC","False");
            }

            if ("3".equals(credit_card) || CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"credit_card")) ){

            }else if ("1".equals(credit_card)){
                UserQualification.put("creditCard","True");
            } else {
                UserQualification.put("creditCard","False");
            }






            String  ownCar = String.valueOf(qualification.get("own_car"));
            if ("4".equals(ownCar)||CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"own_car"))){

            }else if ("3".equals(ownCar)){
                UserQualification.put("ownCar","True");
            }else {
                UserQualification.put("ownCar","False");
            }

            String  ownHousing = String.valueOf(qualification.get("own_housing"));
            if ("4".equals(ownHousing)||CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"own_housing"))){

            }else if ("3".equals(ownHousing)){
                UserQualification.put("ownHousing","True");
            }else {
                UserQualification.put("ownHousing","False");
            }


            String  publicFund = String.valueOf(qualification.get("public_fund"));
            if ("3".equals(publicFund)||CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"public_fund"))){

            }else if ("1".equals(publicFund)){
                UserQualification.put("publicFund","True");
            }else {
                UserQualification.put("publicFund","False");
            }

            String  insurance = String.valueOf(qualification.get("insurance"));
            if ("4".equals(insurance)||CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"insurance"))){

            }else if ("2".equals(insurance)){
                UserQualification.put("insurance","True");
            }else {
                UserQualification.put("insurance","False");
            }

            String  salary = String.valueOf(qualification.get("salary"));
            if ("4".equals(salary)||CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"salary"))){

            }else if ("2".equals(salary)||"3".equals(salary)){
                UserQualification.put("salary","True");
            }else {
                UserQualification.put("salary","False");
            }
            String  zhimaScore = String.valueOf(qualification.get("zhima_score"));

            if (ValidUtils.isNumeric(zhimaScore) && zhimaScore.length() < 10){
                UserQualification.put("zhimaScore_DC",zhimaScore);
            }

            if ( !ValidUtils.isNumeric(zhimaScore)|| CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"zhima_score"))){

            }else{
                UserQualification.put("zhimaScore",zhimaScore);
            }

            String  social_insurance = String.valueOf(qualification.get("social_insurance"));
            if ("4".equals(social_insurance)|| CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"social_insurance"))){

            }else if ("2".equals(social_insurance)){
                UserQualification.put("social_insurance","True");
            }else {
                UserQualification.put("social_insurance","False");
            }

            String  Bank_Credit = String.valueOf(qualification.get("is_overdue"));
            if (CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"is_overdue"))){

            }else if ("1".equals(Bank_Credit)){
                UserQualification.put("Bank_Credit","False");
            }else if ("0".equals(Bank_Credit)){
                UserQualification.put("Bank_Credit","True");
            }

            String  ownTBAccount = String.valueOf(qualification.get("ownTBAccount"));
            if("0".equals(ownTBAccount) || CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"ownTBAccount"))){

            }else if ("1".equals(ownTBAccount)|| "2".equals(ownTBAccount) ){
                UserQualification.put("ownTBAccount","False");

            }else if ("3".equals(ownTBAccount)){
                UserQualification.put("ownTBAccount","True");
            }

            String  Bank_Behalf = String.valueOf(qualification.get("Bank_Behalf"));
            if("0".equals(Bank_Behalf) || CollectionUtils.isEmpty( v3CusAptitudeAiDao.selectUpdateOr(openId,"Bank_Behalf"))){

            }else if ("1".equals(Bank_Behalf)|| "2".equals(ownTBAccount) ){

                UserQualification.put("Bank_Behalf","False");

            }else if ("3".equals(Bank_Behalf)){

                UserQualification.put("Bank_Behalf","True");

            }
        }

        if (StringUtils.isEmpty(UserQualification.get("subscribeCount"))) {

            int subscribeCount = userApplyAuditDao.selectSubscribeCount(openId);
            UserQualification.put("subscribeCount", String.valueOf(subscribeCount));

            int chatCount = userApplyAuditDao.selectChatCount(openId) + 1;
            UserQualification.put("chatCount", String.valueOf(chatCount));

            int amount = userApplyAuditDao.selectAmount(openId);
            if ( amount > 500 && amount < 200000){
                UserQualification.put("amount", String.valueOf(amount));
            }

            JSONObject userInfo = weiXinUserInfoUtil.getWeChatUserInfo(openId);
            if (userInfo != null){
                String nickname = userInfo.getString("nickname");
                if (!StringUtils.isEmpty(nickname)){
                    UserQualification.put("nickname",nickname);
                }

                Map<String,String> record = new HashMap<String,String>();
                record.put("open_id",openId);
                record.put("city",userInfo.getString("city"));
                record.put("gender",userInfo.getString("sex"));
                additionalDataService.updateAdditionalData(record);
            }

        }
    }
}
