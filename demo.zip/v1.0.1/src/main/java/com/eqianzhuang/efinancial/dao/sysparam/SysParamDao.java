package com.eqianzhuang.efinancial.dao.sysparam;

/**
 * 系统设置 Dao
 * @author huangzhigang
 */
public interface SysParamDao {

	String getByPName(String pName);
    
	String getByNameAndType(String pType,String pName);
}
