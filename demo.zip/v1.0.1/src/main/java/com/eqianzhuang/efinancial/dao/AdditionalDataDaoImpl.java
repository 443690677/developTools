package com.eqianzhuang.efinancial.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class AdditionalDataDaoImpl implements AdditionalDataDao {

    private static Log logger = LogFactory.getLog(AdditionalDataDaoImpl.class);

    @Autowired
    JdbcTemplate jdbcTemplate;
    public void add(String openid,int gender,String city,String reqUrl,String model,String brand,String userAgent,String ip,String os){
        jdbcTemplate.update("insert into credit_cpa.v3_additional_data(open_id,gender,city,req_url,model,brand,user_agent,ip,os,create_time,update_time)" +
                " values(?,?,?,?,?,?,?,?,?,now(),now())",openid,gender,city,reqUrl,model,brand,userAgent,ip,os);
    }

    public void update(String openid,int gender,String city,String reqUrl,String model,String brand,String userAgent,String ip,String os){
        jdbcTemplate.update("update credit_cpa.v3_additional_data set gender=?,city=?,req_url=?,model=?,brand=?,user_agent=?,ip=?,os=?,update_time=now()" +
                " where open_id=?",gender,city,reqUrl,model,brand,userAgent,ip,os,openid);
    }


    @Override
    public Map<String,Object> selectAdditionalDataByOpenId(String openId) {

        try {
            String SQL = "select * from credit_cpa.v3_additional_data t where t.open_id = ?";
            return  jdbcTemplate.queryForMap(SQL,openId);
        }catch (Exception e){
            // logger.error(String.format("查询请求信息异常： openid= %s",openId),e);
        }
        return new HashMap<>();
    }
}
