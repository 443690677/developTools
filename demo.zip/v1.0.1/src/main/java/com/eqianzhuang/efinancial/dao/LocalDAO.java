package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.entity.LocalEntity;

import java.util.List;
import java.util.Map;


public interface LocalDAO {
	/**
	 * 根据openid查询返回存在的openid
	 * @param openids openid列表
	 * @return  存在的openid列表
	 */
	List<String> queryOpenids(String... openids);
	
	
	/**
	 * 批量更新
	 * @param params
	 */
	void batchUpdateByOpenid(Map<String, List<LocalEntity>> params);
	
	/**
	 * 批量插入
	 * @param locals 位置信息
	 */
	void batchInsert(List<LocalEntity> locals);
	
	LocalDAO init();
}
