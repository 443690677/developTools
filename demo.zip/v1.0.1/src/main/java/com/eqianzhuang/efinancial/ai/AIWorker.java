
package com.eqianzhuang.efinancial.ai;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.constant.FeedbackStatusEnum;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.constant.WebChatConstant;
import com.eqianzhuang.efinancial.common.HttpUtil;
import com.eqianzhuang.efinancial.common.MediaUtil;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.dao.*;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

@Component
public class AIWorker {


    /**
	 * 调测日志记录器。
	 */
    protected Log logger = LogFactory.getLog(this.getClass());

    /**
     *
     *全部资质的key映射
     *
     */
    private static HashMap<String,String> keyMap = new HashMap<>();

    /**
     *
     *可以多解析资质的key
     *
     */
    private static ArrayList<String> keyList = new ArrayList<>();




    @PostConstruct
    private void init(){

        keyMap.put("amountIsChange","金额变更");
        keyMap.put("name","姓名");
        keyMap.put("amount","金额");
        keyMap.put("mobile","手机");
        keyMap.put("creditCard","卡");
        keyMap.put("ownCar","车");
        keyMap.put("ownHousing","房");
        keyMap.put("publicFund","公积金");
        keyMap.put("insurance","保单");
        keyMap.put("salary","收入");
        keyMap.put("zhimaScore","芝麻");
        keyMap.put("social_insurance","社保");
        keyMap.put("Bank_Credit","逾期");
        keyMap.put("ownTBAccount","淘宝");
        keyMap.put("Bank_Behalf","代发");
        keyMap.put("userPlan","偏好");

        keyList.add("insurance");
        keyList.add("ownCar");
        keyList.add("Bank_Behalf");
        keyList.add("publicFund");
        keyList.add("amount");
        keyList.add("social_insurance");
        keyList.add("Bank_Credit");
        keyList.add("zhimaScore");
        keyList.add("mobile");

    }

    @Autowired
    private IWechatListConfigDao iWechatListConfigDao;

    @Autowired
    private KeFuMsgUtil keFuMsgUtil;

    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private WeiXinUserInfoUtil weiXinUserInfoUtil;

    @Autowired
    private SendProdLinkUtil sendProdLinkUtil;

    @Autowired
    private QLoanBindWXDAO qloanBindWXDAO;

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    private V3CpaApplyRec v3CpaApplyRec;

    @Autowired
    private V3CusAptitudeAiDao v3CusAptitudeAiDao;

    @Autowired
    private DispatchUserDao dispatchUserDao;

    @Autowired
    private RedisClient redisClient;



    public JSONObject invokingAIService(  String openid, String key ,String answer,String question , JSONObject previousQuestion,HashMap<String,String> qualificationMap,String qualificationKey){
        JSONArray array = new JSONArray();
        if (!StringUtils.isEmpty(key)){
            JSONObject object = new JSONObject();
            object.put(key,question);
            array.add(object);
        }
        if (!CollectionUtils.isEmpty(previousQuestion)){
            array.add(previousQuestion);
        }
        LinkedMultiValueMap<String,String> parameter = new LinkedMultiValueMap<>();
        parameter.add("openid",openid);
        parameter.add("key",array.toJSONString());
        parameter.add("content",answer);
        JSONObject result = JSONObject.parseObject(httpUtil.postForObject(weChatConfig.getAIHost(),parameter));
        //处理资质
        JSONObject Have_information = result.getJSONObject("Have_information");
        if (Have_information != null) {
            precessQualification(Have_information,qualificationMap,openid,qualificationKey);
        }
        return result;
    }

    public void ProcessAnswerMain( String key, String question ,String qualificationKey, String openid,String answer, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();

        JSONObject result;
        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")&&("creditCard".equals(qualificationKey) ||"social_insurance".equals(qualificationKey)|| "salary".equals(qualificationKey)||"amount".equals(qualificationKey))){
            result = new JSONObject();
            result.put("Type","3");
            if ("creditCard".equals(qualificationKey)) {

                if ("没有".equals(answer)) {
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"credit_card","2");
                    qualificationMap.put(qualificationKey,"False");
                }else if ("6个月以下".equals(answer)){
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"credit_card","4");
                    qualificationMap.put(qualificationKey,"False");
                }else {
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"credit_card","1");
                    qualificationMap.put(qualificationKey,"True");
                }

            }else if ("social_insurance".equals(qualificationKey)) {

                if ("未缴".equals(answer)) {
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"social_insurance","1");
                    qualificationMap.put(qualificationKey,"False");
                }else if ("有缴小于6个月".equals(answer)){
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"social_insurance","3");
                    qualificationMap.put(qualificationKey,"False");
                }else {
                    weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"social_insurance","2");
                    qualificationMap.put(qualificationKey,"True");
                }

            }else if ("amount".equals(qualificationKey)) {
                if ("500-1000".equals(answer)) {
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","1000");
                    qualificationMap.put(qualificationKey,"1000");
                }else if ("1001-5000".equals(answer)){
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","5000");
                    qualificationMap.put(qualificationKey,"5000");
                }else if ("5001-1万".equals(answer)){
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","10000");
                    qualificationMap.put(qualificationKey,"10000");
                }else if ("1万-2万".equals(answer)){
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","20000");
                    qualificationMap.put(qualificationKey,"20000");
                }else if ("2万-5万".equals(answer)){
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","50000");
                    qualificationMap.put(qualificationKey,"50000");
                }else {
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount","50001");
                    qualificationMap.put(qualificationKey,"50001");
                }

            }else {
                if (ValidUtils.isNumeric(answer)) {
                    if (Integer.parseInt(answer) <  3000) {
                        weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"salary","1");
                        qualificationMap.put(qualificationKey,"False");
                    }else if (Integer.parseInt(answer) <  6000){
                        weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"salary","2");
                        qualificationMap.put(qualificationKey,"True");
                    }else {
                        weiXinUserInfoUtil.updateOrInsertCusAptitudeAi(openid,"salary","3");
                        qualificationMap.put(qualificationKey,"True");
                    }
                }
            }

        }else {
            result = invokingAIService(openid,key,answer,question,userStatusEntity.getPreviousQuestion(),qualificationMap,qualificationKey );
        }


        String type = result.getString("Type");
        JSONObject object = new JSONObject();
        object.put(key,question);
        if ( "3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            int status = userStatusEntity.getStatus();
            if ( status == 40 && !StringUtils.isEmpty(Have_information.getString("金额"))){
                qualificationMap.put("amountIsChange","False");
            }
            //主流程问题
            chooseQuestion(openid,qualificationMap,userStatusEntity,qualificationKey);
            //偏好不能作为前一个问题
            if ( status != userStatusEntity.getStatus() && status!=40 && status != 6  ) {
                    userStatusEntity.setPreviousQuestion(object);
            }
        }else if ("12".contains(type)){
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                chooseQuestion(openid,userStatusEntity.getQualificationMap(),userStatusEntity,"");
            }else{
                String Message = result.getString("Message");
                keFuMsgUtil.say(openid ,Message,userStatusEntity);
                chooseQuestion(openid,qualificationMap,userStatusEntity,qualificationKey);
            }
        }else if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
        }
    }

    public void ProcessAnswerStatus41( String key, String question ,String qualificationKey, String openid,String answer, UserStatusEntity userStatusEntity){

        HashMap<String,String> qualification = userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualification,qualificationKey);
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            String value = Have_information.getString(key);
            qualification.put(qualificationKey,value);
            sendProdStatus41(openid,userStatusEntity);
        }else if("12".contains(type)){
            userStatusEntity.setStatus(999);
            String Message = result.getString("Message");
            keFuMsgUtil.say(openid ,Message,userStatusEntity);
        }else if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
        }

    }

    public void ProcessAnswerStatus43( String key, String question ,String qualificationKey, String openid,String answer, UserStatusEntity userStatusEntity){

        HashMap<String,String> qualification =  userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualification,qualificationKey);
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            String value = Have_information.getString(key);
            qualification.put(qualificationKey,value);
            serviceStatus43(openid,userStatusEntity);
        }else if("12".contains(type)){
            userStatusEntity.setStatus(999);
            String Message = result.getString("Message");
            keFuMsgUtil.say(openid ,Message,userStatusEntity);
        }else if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
        }

    }


    public void ProcessAnswerStatus996(String openid,String answer, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualification =  userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,"",answer,"",new JSONObject(),qualification,"");

        String type = result.getString("Type");
        if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                sendProdLinkUtil.sendProductLinkWithQ(openid,userStatusEntity,5);
            }else{
                String Message = result.getString("Message");
                if (answer.equals(Message)&&ValidUtils.isNumeric(Message)){
                    keFuMsgUtil.say(openid ,URLConstant.AI_TIPS80,userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid ,Message,userStatusEntity);
                }
            }
        }

    }



    public void ProcessAnswerStatus997(String openid,String answer, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualification =  userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,"",answer,"",new JSONObject(),qualification,"");

        String type = result.getString("Type");
        if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                sendProdLinkUtil.sendProductLinkNotQ(openid,userStatusEntity,5,URLConstant.AI_TIPS16);
            }else{
                String Message = result.getString("Message");
                if (StringUtils.isEmpty(Message)){
                    keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
                }else {
                    if (answer.equals(Message)&&ValidUtils.isNumeric(Message)){
                        keFuMsgUtil.say(openid ,URLConstant.AI_TIPS80,userStatusEntity);
                    }else {
                        keFuMsgUtil.say(openid ,Message,userStatusEntity);
                    }
                }
            }
        }

    }

    public void ProcessAnswerStatus999( String openid,String answer, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualification =  userStatusEntity.getQualificationMap();
        JSONObject result = invokingAIService(openid,"",answer,"",new JSONObject(),qualification,"");

        String type = result.getString("Type");
        if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                chooseQuestion(openid,userStatusEntity.getQualificationMap(),userStatusEntity,"");
            }else{
                String Message = result.getString("Message");
                if (StringUtils.isEmpty(Message)){
                    keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
                }else {
                    if (answer.equals(Message)&&ValidUtils.isNumeric(Message)){
                        keFuMsgUtil.say(openid ,URLConstant.AI_TIPS80,userStatusEntity);
                    }else {
                        keFuMsgUtil.say(openid ,Message,userStatusEntity);
                    }
                }
            }
        }

    }


    public void ProcessAnswerStatus39( String key, String question ,String qualificationKey, String openid,String answer, UserStatusEntity userStatusEntity) {
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualificationMap,"");
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            if (!CollectionUtils.isEmpty(Have_information)){
                String qualification = Have_information.getString(key);
                if (!StringUtils.isEmpty(qualification)) {
                    try {
                        if ("1".equals(qualification)){
                        String msg = "可能是你的资料不够完善哦，更新后小易将推荐更多适合的产品～<a href=\"https://open.weixin.qq.com/connect/oauth2/authorize?appid="+ weChatConfig.getAppId(openid) + "&redirect_uri=" + URLEncoder.encode( String.format(URLConstant.AI_TIPS29,weChatConfig.getDomain(openid)),"utf-8") + "&response_type=code&scope=snsapi_userinfo&state=10005#wechat_redirect\">点我修改资料</a>";
                        keFuMsgUtil.say(openid,msg,userStatusEntity);
                        }else if ("2".equals(qualification)){
                            keFuMsgUtil.say(openid, URLConstant.AI_TIPS30,userStatusEntity);
                        }else {
                            String msg ="那再试试小易推荐的以下产品吧～<a href=\"https://open.weixin.qq.com/connect/oauth2/authorize?appid="+ weChatConfig.getAppId(openid) + "&redirect_uri=" + URLEncoder.encode( String.format(URLConstant.AI_TIPS31,weChatConfig.getDomain(openid)),"utf-8") + "&response_type=code&scope=snsapi_userinfo&state=25010#wechat_redirect\">点我立即申请</a>";
                            keFuMsgUtil.say(openid,msg,userStatusEntity);
                        }
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }
            userStatusEntity.setStatus(999);
        }else if ("12".contains(type)){
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                chooseQuestion(openid,qualificationMap,userStatusEntity,qualificationKey);
            }else{
                userStatusEntity.setStatus(999);
                String Message = result.getString("Message");
                keFuMsgUtil.say(openid ,Message,userStatusEntity);
            }
        }else if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
        }
    }


    public void ProcessAnswerChooseService( String key, String question ,String qualificationKey, String openid,String answer, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        //金额资质每次都要重新问超时之后
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualificationMap,"");
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            if (!CollectionUtils.isEmpty(Have_information)){
                String qualification = Have_information.getString(key);
                if (!StringUtils.isEmpty(qualification)) {
                    qualificationMap.put(qualificationKey,qualification);
                    userStatusEntity.setRepeat(false);
                }
            }
            chooseService(openid,qualificationMap,userStatusEntity);
        }else if ("12".contains(type)){
            String Category = result.getString("Category");
            if ("C".equals(Category) || "D".equals(Category)) {
                chooseService(openid,qualificationMap,userStatusEntity);
            }else{
                String Message = result.getString("Message");
                keFuMsgUtil.say(openid ,Message,userStatusEntity);
                if (!userStatusEntity.isRepeat()){
                    userStatusEntity.setRepeat(true);
                    chooseService(openid,qualificationMap,userStatusEntity);
                }
            }
        }else if ("7".equals(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            JSONArray Product_name = Have_information.getJSONArray("Product_name");
            sendProdLinkUtil.sendProductLink(openid,userStatusEntity,Product_name,5);
        }else {
            keFuMsgUtil.say(openid,"网络不稳定，请稍后重试。",userStatusEntity);
        }
    }


    @Value("${DISPATCH_HOST}")
    private String DISPATCH_HOST;

    public void chooseQuestion(String openid ,HashMap<String,String> qualificationMap ,UserStatusEntity userStatusEntity ,String qualificationKey){

        HashSet<String> questionsSet =  userStatusEntity.getQuestionsSet();

        logger.info( openid+ ":qualificationMap:" +qualificationMap);

        logger.info( openid+ ":questionsSet" + questionsSet);

        //查看是否重复问资质
        if (!StringUtils.isEmpty(qualificationKey) && StringUtils.isEmpty(qualificationMap.get(qualificationKey))) {
            if (userStatusEntity.isRepeatMain()){
                userStatusEntity.setStatus(999);
                keFuMsgUtil.say(openid,URLConstant.AI_TIPS1,userStatusEntity);
                userStatusEntity.setRepeatMain(true);
                return;
            }
            userStatusEntity.setRepeatMain(true);
        }else {
            userStatusEntity.setRepeatMain(false);
        }


        String amountIsChange = qualificationMap.get("amountIsChange");
        //金额否定有变化
        if( "True".equals(amountIsChange) ){
            qualificationMap.remove("amount");
            qualificationMap.remove("amountIsChange");
            userStatusEntity.setStatus(0);
            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                userStatusEntity.setLastQuestion("amount");
                keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS0,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
            }else {

                keFuMsgUtil.say(openid, URLConstant.QUESTIONS0,userStatusEntity);
            }
            return;
        }


        String amount = qualificationMap.get("amount");
        //查看金额是不存在才会问金额
        if(!ValidUtils.isNumeric(amount) || amount.length() > 8 || Integer.valueOf(amount) < 500 || Integer.valueOf(amount) > 200000){
            qualificationMap.remove("amount");
            userStatusEntity.setStatus(0);

            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                userStatusEntity.setLastQuestion("amount");
                keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS0,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
            }else {
                keFuMsgUtil.say(openid, URLConstant.QUESTIONS0,userStatusEntity);
            }
            return;
        }

        String amountEvaluation = qualificationMap.get("amountEvaluation");
        if(StringUtils.isEmpty(amountEvaluation)){
            qualificationMap.put("amountEvaluation","True");

            String msg ;
            if ( Integer.valueOf(amount) < 10000 ) {
                msg = URLConstant.AI_TIPS20;
            }else if( Integer.valueOf(amount) <= 50000){
                msg = URLConstant.AI_TIPS21;
            }else {
                msg = URLConstant.AI_TIPS22;
            }

            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){

                String amountAnswer;

                if ( Integer.valueOf(amount) <= 1000 ) {
                    amountAnswer = "500-1000 ";
                }else if( Integer.valueOf(amount) <= 5000){
                    amountAnswer = "1001-5000 ";
                }else if( Integer.valueOf(amount) <= 10000){
                    amountAnswer = "5001-1万 ";
                }else if( Integer.valueOf(amount) <= 20000){
                    amountAnswer = "1万-2万 ";
                }else if( Integer.valueOf(amount) <= 50000){
                    amountAnswer = "2万-5万 ";
                }else {
                    amountAnswer = "5万以上 ";
                }

                msg = msg.replace("${amount} 元",amountAnswer);
            }

            keFuMsgUtil.say(openid,msg,userStatusEntity);
        }


        String creditCard = qualificationMap.get("creditCard");
        if(StringUtils.isEmpty(creditCard)){
            userStatusEntity.setStatus(3);
            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                userStatusEntity.setLastQuestion("creditCard");
                keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS3,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
            }else {
                keFuMsgUtil.say(openid, URLConstant.QUESTIONS3,userStatusEntity);
            }
            return;
        }

        String zhimaScore = qualificationMap.get("zhimaScore");
        if(!ValidUtils.isNumeric(zhimaScore)){
            qualificationMap.remove("zhimaScore");
            userStatusEntity.setStatus(4);

            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                userStatusEntity.setLastQuestion("zhimaScore");
                keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS4,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
            }else {

                keFuMsgUtil.say(openid, URLConstant.QUESTIONS4,userStatusEntity);
            }
            return;
        }

        String userPlan = qualificationMap.get("userPlan");
        if(!ValidUtils.isNumeric(userPlan)) {
            qualificationMap.remove("userPlan");
            if ( "True".equals(creditCard) || Integer.valueOf(zhimaScore) >= 600){

                userStatusEntity.setStatus(6);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("userPlan");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS6,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS6,userStatusEntity);
                }
            }else {
                int amountInt = Integer.valueOf(amount);
                String groupId = "16002";
                if ( amountInt <= 50000){
                    groupId= "16001";
                }
                userStatusEntity.setGroupId(groupId);
                userStatusEntity.setMediaNo(0);
                qualificationMap.put("mainIsFinish","True");
                sendProdLinkUtil.sendProductLinkNotQ1st(openid, userStatusEntity, 5);
            }
        }else {

            String prodGroupSize = qualificationMap.get("prodGroupSize");
            if (StringUtils.isEmpty(prodGroupSize)){
                //用户转接
                String name = Thread.currentThread().getName();
                if (  !name.startsWith("webChat") && Integer.valueOf(amount) >= 20000 && "True".equals(creditCard) && Integer.valueOf(zhimaScore) >= 600){
                    LinkedMultiValueMap<String,String> parameter = new LinkedMultiValueMap<>();
                    parameter.add("openid",openid);
                    try {
                        JSONObject result = JSONObject.parseObject(httpUtil.getForObject( DISPATCH_HOST + "/eqzh-admin-common/dialogue/connection?openid="+openid));
                        String code = result.getString("code");
                        if( "000000".equals(code)){
                            dispatchUserDao.setDispatchUser(openid);
                            //转发消息
                            logger.info("转发消息，openid"+openid);
                            return;
                        }
                    }catch (Exception e){
                        logger.error("调用接口dialogue/connection/add 报错",e);
                    }
                }
                //任何资金用途的产品
                ArrayList<String> groupProdList = selectGroupProdList(zhimaScore, creditCard, userPlan, amount, userStatusEntity,openid);
                userStatusEntity.setMediaNo(0);
                setProductGroupQuestion(groupProdList,questionsSet);
                qualificationMap.put("questionNum", "0");
                qualificationMap.put("prodGroupSize",String.valueOf(groupProdList.size()));
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS24,userStatusEntity);
            }

            boolean isFinish = dynamicQuestion(openid,qualificationMap,questionsSet,userStatusEntity);

            if (isFinish){
                qualificationMap.put("mainIsFinish","True");
                sendProdLinkUtil.sendProductLinkWithQ1st(openid,userStatusEntity,5);
            }

        }
    }

    public boolean dynamicQuestion(String openid ,HashMap<String,String> qualificationMap ,HashSet<String> questionsSet,UserStatusEntity userStatusEntity){


        int questionNum = 0;
        if (ValidUtils.isNumeric(qualificationMap.get("questionNum"))) {
             questionNum = Integer.parseInt(qualificationMap.get("questionNum"));
        }

        qualificationMap.put("questionNum",String.valueOf(questionNum+1));
        if (questionNum == 2 ){
            int NowQuestionNum = 0;
            for (String question :questionsSet){
                if (StringUtils.isEmpty(qualificationMap.get(question))) {
                    NowQuestionNum ++;
                }
            }
            if (NowQuestionNum == 1) {
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS72,userStatusEntity);
            }else if(NowQuestionNum > 1){
                keFuMsgUtil.say(openid, String.format(URLConstant.AI_TIPS73,NowQuestionNum),userStatusEntity);
            }
        }


        if( questionsSet.contains("publicFund")){
            String publicFund = qualificationMap.get("publicFund");
            if (StringUtils.isEmpty(publicFund)){
                userStatusEntity.setStatus(10);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("publicFund");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS10,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS10,userStatusEntity);
                }
                return false;
            }
        }

        if( questionsSet.contains("social_insurance")){
            String social_insurance = qualificationMap.get("social_insurance");
            if (StringUtils.isEmpty(social_insurance)){
                String publicFund = qualificationMap.get("publicFund");
                if ("True".equals(publicFund)){
                    qualificationMap.put("social_insurance","True");
                }else {
                    userStatusEntity.setStatus(7);
                    String name = Thread.currentThread().getName();
                    if (name.startsWith("webChat")){
                        userStatusEntity.setLastQuestion("social_insurance");
                        keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS7,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                    }else {
                        keFuMsgUtil.say(openid, URLConstant.QUESTIONS7,userStatusEntity);
                    }
                    return false;
                }
            }
        }

        if( questionsSet.contains("Bank_Credit")){
            String publicFund = qualificationMap.get("Bank_Credit");
            if (StringUtils.isEmpty(publicFund)){
                userStatusEntity.setStatus(11);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("Bank_Credit");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS11,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS11,userStatusEntity);
                }

                return false;
            }
        }

        if( questionsSet.contains("ownCar")){
            String ownCar = qualificationMap.get("ownCar");
            if (StringUtils.isEmpty(ownCar)){
                userStatusEntity.setStatus(12);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("ownCar");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS12,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS12,userStatusEntity);
                }
                return false;
            }
        }

        if( questionsSet.contains("ownHousing")){
            String ownHousing = qualificationMap.get("ownHousing");
            if (StringUtils.isEmpty(ownHousing)){
                userStatusEntity.setStatus(13);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("ownHousing");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS13,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS13,userStatusEntity);
                }
                return false;
            }
        }

        if( questionsSet.contains("insurance")){
            String insurance = qualificationMap.get("insurance");
            if (StringUtils.isEmpty(insurance)){
                userStatusEntity.setStatus(14);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("insurance");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS14,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS14,userStatusEntity);
                }
                return false;
            }
        }

        if( questionsSet.contains("ownTBAccount")){
            String ownTBAccount = qualificationMap.get("ownTBAccount");
            if (StringUtils.isEmpty(ownTBAccount)){
                userStatusEntity.setStatus(15);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("ownTBAccount");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS15,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS15,userStatusEntity);
                }

                return false;
            }
        }

        if( questionsSet.contains("salary")){
            String salary = qualificationMap.get("salary");
            if (StringUtils.isEmpty(salary)){
                userStatusEntity.setStatus(16);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("salary");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS16,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS16,userStatusEntity);
                }
                return false;
            }
        }

        if( questionsSet.contains("Bank_Behalf")){
            String Bank_Behalf = qualificationMap.get("Bank_Behalf");
            if (StringUtils.isEmpty(Bank_Behalf)){
                userStatusEntity.setStatus(17);
                String name = Thread.currentThread().getName();
                if (name.startsWith("webChat")){
                    userStatusEntity.setLastQuestion("Bank_Behalf");
                    keFuMsgUtil.syncJsonMsg(openid,WebChatConstant.QUESTIONS17,keFuMsgUtil.getLabel(userStatusEntity),userStatusEntity);
                }else {
                    keFuMsgUtil.say(openid, URLConstant.QUESTIONS17,userStatusEntity);
                }

                return false;
            }
        }
        return true;
    }

    private void setSingleProductQuestion(String lenderId,HashSet<String> questionsSet){
        List<Map<String, Object>> prodAttrList = iWechatListConfigDao.getProductAttr(lenderId);
        if (!CollectionUtils.isEmpty(prodAttrList)){
            for (int j = 0; j < prodAttrList.size(); j++) {
                Map prodAttr = prodAttrList.get(j);

                String social_insurance = String.valueOf(prodAttr.get("social_insurance"));
                if (!"0".equals(social_insurance)){
                    questionsSet.add("social_insurance");
                }
                String publicFund = String.valueOf(prodAttr.get("publicFund"));
                if (!"0".equals(publicFund)){
                    questionsSet.add("publicFund");

                }
                String Bank_Credit = String.valueOf(prodAttr.get("Bank_Credit"));
                if (!"0".equals(Bank_Credit)){
                    questionsSet.add("Bank_Credit");

                }
                String ownCar = String.valueOf(prodAttr.get("ownCar"));
                if (!"0".equals(ownCar)){
                    questionsSet.add("ownCar");

                }
                String ownHousing = String.valueOf(prodAttr.get("ownHousing"));
                if (!"0".equals(ownHousing)){
                    questionsSet.add("ownHousing");

                }
                String ownTBAccount = String.valueOf(prodAttr.get("ownTBAccount"));
                if (!"0".equals(ownTBAccount)){
                    questionsSet.add("ownTBAccount");

                }
                String insurance = String.valueOf(prodAttr.get("insurance"));
                if (!"0".equals(insurance)){
                    questionsSet.add("insurance");

                }
                String salary = String.valueOf(prodAttr.get("salary"));
                if (!"0".equals(salary)){
                    questionsSet.add("salary");

                }

                String Bank_Behalf = String.valueOf(prodAttr.get("Bank_Behalf"));
                if (!"0".equals(Bank_Behalf)){
                    questionsSet.add("Bank_Behalf");

                }
            }
        }

    }

    public void setProductGroupQuestion(ArrayList<String> selectProdList,HashSet<String> questionsSet){
        for (int i = 0; i < selectProdList.size(); i++) {
            String lenderId = selectProdList.get(i);
            setSingleProductQuestion(lenderId, questionsSet);
        }
    }

    public ArrayList<String> selectGroupProdList(String zmScore, String creditCard, String userPlan, String amount, UserStatusEntity userStatusEntity,String openId){

        ArrayList<String> prodSet = new ArrayList<>();
        int zmScoreInt =0;
        int amountInt =0;
        if (!StringUtils.isEmpty(amount)) {
            amountInt = Integer.valueOf(amount);
        }
        if ( !StringUtils.isEmpty(zmScore)) {
            zmScoreInt = Integer.valueOf(zmScore);
        }

        String groupId ;
        if ("1".equals(userPlan)) {
            if ( amountInt < 10000){
                groupId = "14001";
            }else if ( amountInt <= 50000){
                groupId = "14002";
            }else {
                groupId = "14003";
            }
        }else if ("2".equals(userPlan)){
            if ( amountInt < 10000){
                groupId = "15001";
            }else if ( amountInt <= 50000){
                groupId = "15002";
            }else {
                groupId = "15003";
            }
        }else {
            if ( amountInt < 10000){
                groupId = "13001";
            }else if ( amountInt <= 50000){
                groupId = "13002";
            }else {
                groupId = "13003";
            }
        }
        userStatusEntity.setGroupId(groupId);
        List<Map<String,Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openId);

        for (int i = 0; i < prodList.size(); i++) {
            String lenderId = String.valueOf(prodList.get(i).get("id"));
            List<Map<String, Object>> prodAttrList = iWechatListConfigDao.getProductAttr(lenderId);
            boolean isMeet = true;
            if (!CollectionUtils.isEmpty(prodAttrList)){

                for (Map prodAttr : prodAttrList) {
                    int zhimaScoreAttr = (Integer) prodAttr.get("zhimaScore");
                    if ( 0 != zhimaScoreAttr && zmScoreInt < zhimaScoreAttr) {
                        isMeet = false;
                        continue;
                    }

                    String creditCardAttr = String.valueOf(prodAttr.get("creditCard"));
                    if ( "1".equals(creditCardAttr) && !"True".equals(creditCard)) {
                        isMeet = false;
                    }
                }
            }

            //如果资质匹配就添加
            if (isMeet){
                //有产品推荐
                prodSet.add(lenderId);
            }
        }
        return prodSet;
    }


    private void chooseService(String openid, HashMap<String, String> qualificationMap, UserStatusEntity userStatusEntity){
        String QUESTIONS30 = qualificationMap.get("QUESTIONS30");
        int status = userStatusEntity.getStatus();
        if (StringUtils.isEmpty(QUESTIONS30)){

            if (status == 34 ){
                keFuMsgUtil.sendJsonMsg(openid,URLConstant.QUESTIONS30_MENU,userStatusEntity);
            }else if (status == 42 ){
                keFuMsgUtil.sendJsonMsg(openid,URLConstant.WELCOME_MSG,"欢迎语",userStatusEntity);
            }else {
                userStatusEntity.setStatus(34);
                keFuMsgUtil.sendJsonMsg(openid,URLConstant.QUESTIONS30_MENU ,userStatusEntity);
            }

        }else {
            if ("1".equals(QUESTIONS30)){
                chooseQuestion(openid,qualificationMap,userStatusEntity,"");
            }else if ("2".equals(QUESTIONS30)){

                String groupId = "13005";
                userStatusEntity.setMediaNo(0);
                if (status == 34 ){
                    userStatusEntity.setMediaNo(4);
                    groupId = "13004";
                }else if (status == 42 ){
                    userStatusEntity.setMediaNo(0);
                    groupId = "13005";
                }

                userStatusEntity.setGroupId(groupId);
                sendProdLinkUtil.sendProductLinkNotQ(openid,userStatusEntity,5,URLConstant.AI_TIPS16);
            }else {
                userStatusEntity.setStatus(999);
                keFuMsgUtil.say(openid,URLConstant.AI_TIPS12,userStatusEntity);
            }
        }
    }

    /**
     * 插入获取数据和绑定表和顾客表
     */
    private void updateUserQualification(String openid, String key, String value, HashMap<String, String> qualificationMap){
        //更新绑定表
        weiXinUserInfoUtil.insertOrUpdateQloanBind(openid,key,value);

        //更新个人中心资质
        weiXinUserInfoUtil.insertOrUpdateAptitudeAI(openid,key,value);

        //更新顾客表(包含AI的)
        weiXinUserInfoUtil.insertOrUpdateCustomer(key,value,qualificationMap,openid);

        //更新用户行为表
        weiXinUserInfoUtil.insertUserAction(openid,key,value,qualificationMap);

    }

    private void precessQualification(JSONObject Have_information ,HashMap<String,String> qualificationMap,String openid,String qualificationKey)
    {
        for (String key : keyMap.keySet()) {
            String informationKey = keyMap.get(key);
            String value = Have_information.getString(informationKey);
            if (!StringUtils.isEmpty(value)) {
                if ( key.equals(qualificationKey)) {
                    qualificationMap.put(key,value);
                    //更新资质到各种表
                    updateUserQualification(openid,key,value,qualificationMap);
                }else if (keyList.contains(key)){
                    qualificationMap.put(key,value);
                    //更新资质到各种表
                    updateUserQualification(openid,key,value,qualificationMap);
                }
            }
        }
    }


    public boolean outLibOffline(String lenderId, HashMap<String, String> qualification, String cityId, String applyId, String mobile_des,String openid){

        boolean isSuccess ;
        ArrayList<String[]> outLibDataArray = new ArrayList<>();
        String mobile = qualification.get("mobile");
        String ownCar = qualification.get("ownCar");
        String ownHousing = qualification.get("ownHousing");
        String insurance = qualification.get("insurance");

        if ("109601".equals(lenderId)){
            String[] outLibData = {"10059", "", "13", "883"};
            //【宜信普惠】
            if (qloanBindWXDAO.selectCityIdsByGroupID(Integer.valueOf(outLibData[2])).contains(cityId) && sendProdLinkUtil.isMeet("109601",qualification,openid)){
                outLibDataArray.add(outLibData);
            }
        }

        if ("109701".equals(lenderId)){
            String[] outLibData = {"10003", "", "4", ""};
            //【平安普惠】
            if (qloanBindWXDAO.selectCityIdsByGroupID(Integer.valueOf(outLibData[2])).contains(cityId) && sendProdLinkUtil.isMeet("109701",qualification,openid)) {

                if ("True".equals(ownHousing) && "True".equals(insurance)) {
                    outLibData[1] = "cxx-mktianshen-eqz05";
                    outLibData[3] = "886";
                } else if ( "True".equals(insurance)) {
                    outLibData[1] = "cxx-mktianshen-eqz04";
                    outLibData[3] = "885";
                } else  if ("True".equals(ownHousing)) {
                    outLibData[1] = "cxx-mktianshen-eqz02";
                    outLibData[3] = "884";
                }
                if (!StringUtils.isEmpty(outLibData[3])){
                    outLibDataArray.add(outLibData);
                }
            }
        }

        if ("100101".equals(lenderId)){
            String[] outLibData = {"10108", "XYD1-os0003142", "20", ""};
            //【平安银行】
            if (qloanBindWXDAO.selectCityIdsByGroupID(Integer.valueOf(outLibData[2])).contains(cityId) && sendProdLinkUtil.isMeet("100101",qualification,openid) ) {
                if ("True".equals(ownCar)) {
                    outLibData[3] = "765";
                } else if ("True".equals(ownHousing)) {
                    outLibData[3] = "764";
                } else if ("True".equals(insurance)) {
                    outLibData[3] = "766";
                }
                if (!StringUtils.isEmpty(outLibData[3])){
                    outLibDataArray.add(outLibData);
                }
            }
        }

        if ("105801".equals(lenderId)){
            String[] outLibData = {"10005", "", "5", "111", ""};
            //【你我贷】
            if (qloanBindWXDAO.selectCityIdsByGroupID(Integer.valueOf(outLibData[2])).contains(cityId) && sendProdLinkUtil.isMeet("105801",qualification,openid) ) {
                outLibDataArray.add(outLibData);
            }
        }

        if ("102201".equals(lenderId)){
            String[] outLibData = new String[]{"10006", "", "7", ""};
            //【厚本金融】
            if (qloanBindWXDAO.selectCityIdsByGroupID(Integer.valueOf(outLibData[2])).contains(cityId) && sendProdLinkUtil.isMeet("102201",qualification,openid)){
                if ("True".equals(ownCar)) {
                    outLibData[3] = "92";
                }else if ("True".equals(ownHousing)) {
                    outLibData[3] = "91";
                } else if ("True".equals(insurance)) {
                    outLibData[3] = "93";
                }

                if (!StringUtils.isEmpty(outLibData[3])){
                    outLibDataArray.add(outLibData);
                }
            }
        }

        if (CollectionUtils.isEmpty(outLibDataArray)){
            isSuccess = false;
        }else{

            isSuccess = true;
            //插入数据到v3_distribute_wait
            for (String [] date : outLibDataArray) {
                insertDistributeWait(date ,mobile,applyId ,mobile_des,openid);
            }
        }

        return isSuccess;
    }

    private synchronized void insertDistributeWait(String[] date , String mobile ,String applyId,String mobile_des,String openid){
        int compId = Integer.parseInt(date[0]);
        if ( qloanBindWXDAO.selectDistributWait(compId,mobile) == 0){
            String outChannel = date[1];
            String distributBGroupId = date[2];
            String ruleId = date[3];
            qloanBindWXDAO.insertDistributWait(compId,applyId,mobile,ruleId,outChannel,distributBGroupId,mobile_des,openid);
        }
    }

    public void nextStepService(String openid,UserStatusEntity userStatusEntity){

        HashSet<String> productSet = userStatusEntity.getProductSet();
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        ArrayList<String> lenderIds = new ArrayList<>();
        List<String> prodRes = v3CpaApplyRec.selectApplyRec(openid,new Date(userStatusEntity.getFirstSessionDate()));
        if (!CollectionUtils.isEmpty(prodRes)){
            for (String lenderId : prodRes) {
                if (!lenderIds.contains(lenderId)){
                    lenderIds.add(lenderId);
                }
            }
        }

        if ( lenderIds.size() > 1 ){
            if(StringUtils.isEmpty(qualificationMap.get("status41Finish")))
            {
                qualificationMap.put("status41Finish","True");
                userStatusEntity.setStatus(41);
                String name0 = iWechatListConfigDao.getProdNameByLenderId(lenderIds.get(0));
                String name1 = iWechatListConfigDao.getProdNameByLenderId(lenderIds.get(1));
                keFuMsgUtil.say(openid, String.format(URLConstant.AI_TIPS57,name0,name1),userStatusEntity);
            }else {
                if (userStatusEntity.isNotifyOf12Hour()&&StringUtils.isEmpty(qualificationMap.get("isRefused"))) {
                    List<String> prods = v3CpaApplyRec.selectProdApplyRec( openid,new Date(userStatusEntity.getFirstSessionDate()));
                    String groupId = "25059";
                    userStatusEntity.setGroupId(groupId);
                    sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS60_START,String.format(URLConstant.AI_TIPS60_END,prods.size()),"被拒推荐产品");
                }
            }
        }else {
            String groupId = "25058";
            userStatusEntity.setGroupId(groupId);
            if (CollectionUtils.isEmpty(productSet)){
                sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS58_START,URLConstant.AI_TIPS58_END,"推荐产品");
            }else {
                if (userStatusEntity.isNotifyOf12Hour()) {
                    sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS78,URLConstant.AI_TIPS58_END,"推荐产品");
                }else {
                    sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS76,URLConstant.AI_TIPS58_END,"推荐产品");
                }
                userStatusEntity.setStatus(43);
            }
        }

    }

    private void sendProdStatus41(String openid,UserStatusEntity userStatusEntity){

        HashMap<String, String> qualificationMap = userStatusEntity.getQualificationMap();
        String isRefused = qualificationMap.get("isRefused");
        //未被拒申请
        if ( "True".equals(isRefused)){

            String groupId = "25059";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS59_START,URLConstant.AI_TIPS59_END,"未被拒推荐产品");
        }else {

            List<String> prods = v3CpaApplyRec.selectProdApplyRec( openid,new Date(userStatusEntity.getFirstSessionDate()));
            String groupId = "25059";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS60_START,String.format(URLConstant.AI_TIPS60_END,prods.size()),"被拒推荐产品");

        }
    }

    private void serviceStatus43(String openid,UserStatusEntity userStatusEntity){

        HashSet<String> productSet = userStatusEntity.getProductSet();
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        ArrayList<String> lenderIds = new ArrayList<>();
        if (!CollectionUtils.isEmpty(productSet)){
            List<String> prods = v3CpaApplyRec.selectApplyRec( openid,new Date(userStatusEntity.getFirstSessionDate()));
            if (!CollectionUtils.isEmpty(prods)){
                for (String lenderId : prods) {
                    if ( productSet.contains(lenderId) && !lenderIds.contains(lenderId)){
                        lenderIds.add(lenderId);
                    }
                }
            }
        }
        if ( lenderIds.size() > 1 ){
            if(StringUtils.isEmpty(qualificationMap.get("status41Finish")))
            {
                qualificationMap.put("status41Finish","True");
                userStatusEntity.setStatus(41);
                String name0 = iWechatListConfigDao.getProdNameByLenderId(lenderIds.get(0));
                String name1 = iWechatListConfigDao.getProdNameByLenderId(lenderIds.get(1));
                keFuMsgUtil.say(openid, String.format(URLConstant.AI_TIPS57,name0,name1),userStatusEntity);
            }else {
                if (userStatusEntity.isNotifyOf12Hour()&&StringUtils.isEmpty(qualificationMap.get("isRefused"))) {
                    List<String> prods = v3CpaApplyRec.selectProdApplyRec( openid,new Date(userStatusEntity.getFirstSessionDate()));
                    String groupId = "25059";
                    userStatusEntity.setGroupId(groupId);
                    sendProdLinkUtil.sendLink(openid,userStatusEntity,5,URLConstant.AI_TIPS60_START,String.format(URLConstant.AI_TIPS60_END,prods.size()),"被拒推荐产品");
                }
            }
        }else {
            keFuMsgUtil.say(openid,URLConstant.AI_TIPS77,userStatusEntity);
        }

    }

    /**
     *@Description: 记录微信公众号操作埋点记录
     * @param openId 微信OPENID
     * @param mark 操作标识
     * @return Integer 0：成功，1：失败
     */
    public void addOps(String openId, Integer mark, String remarks){
        try{
            // 验证openId是否为空
            if (StringUtils.isEmpty(openId)){
                return;
            }
            String wxType = weChatConfig.getWXType(openId);
            iWechatListConfigDao.addWxOps(openId,wxType,String.valueOf(mark),"",remarks,"","");
        }catch(Exception e){
            logger.error(String.format("记录公众号埋点记录异常：%s   %s   %s",openId,mark,remarks),e);
        }
    }


    /**
     *
     * 功能描述: 处理机构反馈“未出额度”的流程
     *
     * @param: [key, question, qualificationKey, openid, answer, userStatusEntity]
     * @return: void
     * @auther: junjin Lin
     * @date: 2019/2/26 14:04
     */
    public void ProcessFeedbackStatus2(String key, String question, String qualificationKey, String openid, String answer,
                                      UserStatusEntity userStatusEntity) {
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualificationMap,"");
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            if (!CollectionUtils.isEmpty(Have_information)){
                String qualification = Have_information.getString(key);
                if (!StringUtils.isEmpty(qualification)) {
                    try {
                        String msg = "";
                        if ("1".equals(qualification)){
                            StringBuilder easyPassString = new StringBuilder(URLConstant.AI_FEEDBACK2_EASY_PASS_MSG);
                            String link = sendProdLinkUtil.getLink(openid, String.format(URLConstant.AI_FEEDBACK2_EASY_PASS_URL,
                                weChatConfig.getDomain(openid), openid, chn), URLConstant.AI_FEEDBACK2_EASY_PASS);
                            msg = easyPassString.append(link).toString();

                        }else if ("2".equals(qualification)){
                            StringBuilder easyPassString = new StringBuilder(URLConstant.AI_FEEDBACK2_EASY_OPS_MSG);
                            String link = sendProdLinkUtil.getLink(openid, String.format(URLConstant.AI_FEEDBACK2_EASY_OPS_URL,
                                weChatConfig.getDomain(openid), openid, chn), URLConstant.AI_FEEDBACK2_EASY_OPS);
                            msg = easyPassString.append(link).toString();

                        }else if ("3".equals(qualification)){
                            msg = "具体是什么问题呢?";
                            // 给status新增一个值，用于在记录用户回复时打上标签
                            userStatusEntity.setStatus(1000);

                        }

                        keFuMsgUtil.say(openid, msg, FeedbackStatusEnum.getMessageByStatus(userStatusEntity.getFeedbackStatus()), userStatusEntity);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        }

        userStatusEntity.setFeedbackStatus(0);
    }

    /**
     * 
     * 功能描述: 处理机构反馈“未验证运营商”的流程
     * 
     * @param: [key, question, qualificationKey, openid, answer, userStatusEntity]
     * @return: void
     * @auther: junjin Lin
     * @date: 2019/2/26 16:08
     */
    public void ProcessFeedbackStatus3(String key, String question, String qualificationKey, String openid, String answer,
                                       UserStatusEntity userStatusEntity) {
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualificationMap,"");
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            if (!CollectionUtils.isEmpty(Have_information)){
                String qualification = Have_information.getString(key);
                if (!StringUtils.isEmpty(qualification)) {
                    try {
                        String msg = "";
                        if ("1".equals(qualification)){
                            msg = "目前市面上的贷款产品都需要验证运营商的，不验证是无法申请贷款的哦";
                            keFuMsgUtil.say(openid, msg, FeedbackStatusEnum.getMessageByStatus(userStatusEntity.getFeedbackStatus()), userStatusEntity);
                        }else if ("2".equals(qualification)){

                        }else if ("3".equals(qualification)){

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        }

        userStatusEntity.setFeedbackStatus(0);
    }

    /**
     *
     * 功能描述: 处理机构反馈“未提交订单”的流程
     *
     * @param: [key, question, qualificationKey, openid, answer, userStatusEntity]
     * @return: void
     * @auther: junjin Lin
     * @date: 2019/2/26 16:08
     */
    public void ProcessFeedbackStatus4(String key, String question, String qualificationKey, String openid, String answer,
                                       UserStatusEntity userStatusEntity) {
        HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();
        JSONObject result = invokingAIService(openid,key,answer,question,new JSONObject(),qualificationMap,"");
        String type = result.getString("Type");
        if ("3456".contains(type)){
            JSONObject Have_information = result.getJSONObject("Have_information");
            if (!CollectionUtils.isEmpty(Have_information)){
                String qualification = Have_information.getString(key);
                if (!StringUtils.isEmpty(qualification)) {
                    try {
                        String msg = "";
                        if ("1".equals(qualification)){

                        }else if ("2".equals(qualification)){

                        }else if ("3".equals(qualification)){
                            msg = "51人品贷已经是利息非常低的产品了，其他低息产品批款率不能保障哦";
                            keFuMsgUtil.say(openid, msg, FeedbackStatusEnum.getMessageByStatus(userStatusEntity.getFeedbackStatus()), userStatusEntity);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        }

        userStatusEntity.setFeedbackStatus(0);
    }

}
