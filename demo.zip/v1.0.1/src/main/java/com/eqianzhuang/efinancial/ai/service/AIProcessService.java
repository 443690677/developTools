package com.eqianzhuang.efinancial.ai.service;

import com.eqianzhuang.efinancial.entity.UserStatusEntity;

public interface AIProcessService {

    void wxChatProcess(String openid, String answer, UserStatusEntity userStatusEntity);

    void webChatProcess(String openid, String answer, UserStatusEntity userStatusEntity);

    void webChatPrevious(String openId ,UserStatusEntity userStatusEntity);

    void webChatGuide(String openId);
}
