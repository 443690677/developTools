package com.eqianzhuang.efinancial.ai;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.HttpUtil;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.dao.IV3CpaApplyRecDao;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.QLoanBindWXDAO;
import com.eqianzhuang.efinancial.dao.V3CusAptitudeAiDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

@Component
public class WeiXinUserInfoUtil{
    /**
     * 调测日志记录器。
     */
    protected Log logger = LogFactory.getLog(this.getClass());


    @Value("${WX_CENTER}")
    private String WX_CENTER;

    @Autowired
    private QLoanBindWXDAO QLoanBindWXDAO;

    @Autowired
    private IV3CpaApplyRecDao iV3CpaApplyRecDao;

    @Autowired
    private V3CusAptitudeAiDao v3CusAptitudeAiDao;

    @Autowired
    private IWechatListConfigDao iWechatListConfigDao;

    @Autowired
    private SendProdLinkUtil sendProdLinkUtil;

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    HttpUtil httpUtil;

    //更新个人中心表v3_cus_aptitude_ai
    public void insertOrUpdateAptitudeAI(String openid, String key, String value){

        switch (key) {

            //提问贷款多少金额,每次都重新获取
            case "amount":
                if (ValidUtils.isNumeric(value) && value.length() < 8 && Integer.valueOf(value) >= 500 && Integer.valueOf(value) <= 200000 ) {
                    v3CusAptitudeAiDao.insertUpdateOr(openid,"amount",value);
                }
                break;
            //提问姓名
            case "name":
                updateOrInsertCusAptitudeAi(openid,"full_name",value);
                break;
            //提问手机号
            case "mobile":
                updateOrInsertCusAptitudeAi(openid,"mobile",value);
                //根据手机号查询
                if (value.length() != 11) {
                    logger.info("手机号长度不对"+value);
                    return;
                }
                Map mobileDM = QLoanBindWXDAO.queryDMByMobileNumber(value);
                String cityId = "0";
                String mobileArea="未知";
                if (!CollectionUtils.isEmpty(mobileDM)){
                    mobileArea = (String) mobileDM.get("MobileArea");
                    if (mobileArea.contains(" ")){
                        mobileArea = mobileArea.split(" ")[1];
                    }
                }
                //根据手机号查询
                Map city = QLoanBindWXDAO.selectCity(mobileArea);
                if ( !CollectionUtils.isEmpty(city)){
                    cityId = (String) city.get("id");
                    mobileArea = (String) city.get("name");
                }
                updateOrInsertCusAptitudeAi(openid,"city_name",mobileArea);
                updateOrInsertCusAptitudeAi(openid,"city_id",cityId);
                break;
            //提问信用卡
            case "creditCard":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"credit_card","1");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"credit_card","2");
                }
                break;
            //提问芝麻分
            case "zhimaScore":
                updateOrInsertCusAptitudeAi(openid,"zhima_score",value);
                break;


            //提问芝麻分
            case "userPlan":
                v3CusAptitudeAiDao.insertUpdateOr(openid,"userPlan",value);
                updateOrInsertCusAptitudeAi(openid,"preference",value);
                break;

            //社保
            case "social_insurance":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"social_insurance","2");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"social_insurance","1");
                }
                break;
            //提问公积金缴纳时间
            case "publicFund":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"public_fund","1");
                    updateOrInsertCusAptitudeAi(openid,"social_insurance","2");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"public_fund","2");
                }
                break;
            //是否有车
            case "ownCar":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"own_car","3");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"own_car","1");
                }
                break;
            //是否有房
            case "ownHousing":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"own_housing","3");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"own_housing","1");
                }
                break;
            //是否有保单
            case "insurance":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"insurance","2");
                    updateOrInsertCusAptitudeAi(openid,"insurance_fee","3");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"insurance","1");
                    updateOrInsertCusAptitudeAi(openid,"insurance_fee","1");
                }
                break;
            //工作是否大于三千
            case "salary":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"salary","2");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"salary","1");
                }
                break;
            //是否有淘宝账号
            case "ownTBAccount":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"ownTBAccount","3");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"ownTBAccount","1");
                }
                break;

            //是否代发
            case "Bank_Behalf":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"Bank_Behalf","3");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"Bank_Behalf","1");
                }
                break;

            case "Bank_Credit":
                if ("True".equals(value)){
                    updateOrInsertCusAptitudeAi(openid,"is_overdue","0");
                }else {
                    updateOrInsertCusAptitudeAi(openid,"is_overdue","1");
                }
                break;

        }
    }

    public void updateOrInsertCusAptitudeAi(String open_id, String field_name, String field_value)
    {
        Map cusAptitudeAi = v3CusAptitudeAiDao.getCusAptitudeAi(open_id);
        String wx_type = weChatConfig.getWXType(open_id);

        String unionId;
        if (StringUtils.isEmpty(cusAptitudeAi.get("unionid"))){
            unionId = getUnionId(open_id);
        }else {
            unionId = String.valueOf(cusAptitudeAi.get("unionid"));
        }

        if (CollectionUtils.isEmpty(cusAptitudeAi) ) {
            v3CusAptitudeAiDao.insertCusAptitudeAi(open_id,field_name,field_value,unionId,wx_type);
        } else {
            v3CusAptitudeAiDao.updateCusAptitudeAi(open_id,field_name,field_value,unionId,wx_type);
        }
        v3CusAptitudeAiDao.insertUpdateOr(open_id,field_name,field_value);
    }

    private String getUnionId(String openid){
        try {
            // 获取用户基本信息
            JSONObject userInfo = getWeChatUserInfo(openid);
            return userInfo.getString("unionid");
        }catch(Exception e){
            this.logger.error("获取用户基本信息失败：",e);
        }
        return "";
    }

    @Async("asyncWorker")
    public void insertOrUpdateCustomer(String key, String value, HashMap<String, String> qualificationMap,String openid){

        if ("mobile".equals(key)){
            String name = qualificationMap.get("name");
            String amount = qualificationMap.get("amount");
            String mobile = qualificationMap.get("mobile");

            if ( ValidUtils.isNumeric(amount) ||ValidUtils.isNumeric(mobile)|| amount.length() > 9 || value.length() != 11) {
                logger.info("资质不合规 name:"+name+" amount:"+amount+" mobile:"+mobile);
                return;
            }

            //根据手机号查询
            Map mobileDM = QLoanBindWXDAO.queryDMByMobileNumber(value);
            String mobileArea = "未知";
            String cityId = "0000";

            if (!CollectionUtils.isEmpty(mobileDM)){
                mobileArea = (String) mobileDM.get("MobileArea");
                if (mobileArea.contains(" ")){
                    mobileArea = mobileArea.split(" ")[1];
                }
            }

            Map city = QLoanBindWXDAO.selectCity(mobileArea);
            if ( !CollectionUtils.isEmpty(city)){
                cityId = (String) city.get("id");
            }

            if ( v3CusAptitudeAiDao.selectV3CustomerAI(mobile) > 0 )  {
                v3CusAptitudeAiDao.updateCustomerAI(name,amount,mobile,cityId,openid);
            } else {
                v3CusAptitudeAiDao.insertCustomerAI(name,amount,mobile,cityId,openid);
            }
        }
    }

    public void insertUserQualification(String openid , HashMap<String,String> qualification){

        if (CollectionUtils.isEmpty(qualification)){
            logger.info("qualification为空，无法获客，openid:" + openid);
            return;
        }

        String amount = qualification.get("amount");
        String name = qualification.get("name");
        String mobile = qualification.get("mobile");
        if ( StringUtils.isEmpty(amount) || StringUtils.isEmpty(name) || StringUtils.isEmpty(mobile)|| mobile.length() !=11){
            logger.info("qualification :" +qualification+"基本信息不足，无法获客，openid:" + openid+ "");
            return;
        }
        String mobile_des = String.valueOf(mobileEncryptToLong(mobile));
        //根据手机号查询
        Map mobileDM = QLoanBindWXDAO.queryDMByMobileNumber(mobile);
        String cityName="未知";
        String cityId = "0";
        if (!CollectionUtils.isEmpty(mobileDM)){
            cityName = (String) mobileDM.get("MobileArea");
            if (cityName.contains(" ")){
                cityName = cityName.split(" ")[1];
            }
        }
        //根据手机号查询
        Map city = QLoanBindWXDAO.selectCity(cityName);
        if ( !CollectionUtils.isEmpty(city)){
            cityId = (String) city.get("id");
            cityName = (String) city.get("name");
        }

        String creditCard =  qualification.get("creditCard");

        if(StringUtils.isEmpty(creditCard)){
            creditCard = "3";
        }else {
            if ("True".equals(creditCard)){
                creditCard = "1";
            }else {
                creditCard = "2";
            }
        }


        String zhimaScore =  qualification.get("zhimaScore");
        if(StringUtils.isEmpty(zhimaScore)){
            zhimaScore = "4";
        }else {
            int zhimaScoreInt = Integer.valueOf(zhimaScore);
            if (zhimaScoreInt > 650){
                zhimaScore = "3";
            }else if (zhimaScoreInt > 600){
                zhimaScore = "2";
            }else {
                zhimaScore = "1";
            }
        }

        String social_insurance =  qualification.get("social_insurance");
        if(StringUtils.isEmpty(social_insurance)){
            social_insurance = "4";
        }else {
            if ("True".equals(social_insurance)){
                social_insurance = "2";
            }else {
                social_insurance = "1";

            }
        }

        String publicFund =  qualification.get("publicFund");
        if(StringUtils.isEmpty(publicFund)){
            publicFund ="3";
        }else {
            if ("True".equals(publicFund)){
                publicFund ="1";
            }else {
                publicFund ="2";
            }
        }


        String ownCar =  qualification.get("ownCar");
        if(StringUtils.isEmpty(ownCar)){
            ownCar ="4";
        }else {
            if ("True".equals(ownCar)){
                ownCar ="3";
            }else {
                ownCar ="1";
            }
        }

        String ownHousing =  qualification.get("ownHousing");
        if(StringUtils.isEmpty(ownHousing)){
            ownHousing = "4";
        }else {
            if ("True".equals(ownHousing)){
                ownHousing = "3";
            }else {
                ownHousing = "1";
            }
        }

        String insurance =  qualification.get("insurance");

        String insuranceFee = "4";

        if (StringUtils.isEmpty(insurance)){
            ownHousing = "4";
        }else {
            if ("True".equals(insurance)){
                insurance = "2";
                insuranceFee = "3";
            }else {
                insurance = "1";
                insuranceFee = "4";
            }
        }

        String salary =  qualification.get("salary");

        if(StringUtils.isEmpty(salary)){
            salary = "4";
        }else {
            if ("True".equals(salary)){
                salary = "2";
            }else {
                salary = "1";
            }
        }

        iV3CpaApplyRecDao.insertUserQualification(amount,name,mobile,mobile_des,cityName,cityId,creditCard,zhimaScore,social_insurance,publicFund,ownCar,ownHousing,insurance,insuranceFee,salary,openid);

    }


    //更新绑定表
    @Async("asyncWorker")
    public void insertOrUpdateQloanBind(String openid, String key, String value){
        switch (key) {
            //提问姓名
            case "name":
                QLoanBindWXDAO.updateQloanBindWX(openid ,value);
                break;
            //提问手机号
            case "mobile":
                String mobile_des = String.valueOf(mobileEncryptToLong(value));
                QLoanBindWXDAO.updateQloanBindWX(openid ,value,mobile_des);
                break;
        }
    }



    //更新用户行为表
    @Async("asyncWorker")
    public void insertUserAction(String openid, String key, String value, HashMap<String, String> qualificationMap) {


        switch (key) {
            case "amount":
                //添加历史记录
                if (ValidUtils.isNumeric(value) && value.length() < 8 && Integer.valueOf(value) >= 500 && Integer.valueOf(value) <= 200000 ) {
                    v3CusAptitudeAiDao.insertUserAction(openid,"amount",value);
                }
                break;
            //提问手机号
            case "zhimaScore":

                //添加首次推荐产品
                ArrayList<String> productId =insertFirstProd(openid,qualificationMap);
                if (!CollectionUtils.isEmpty(productId)){
                    v3CusAptitudeAiDao.insertUserAction(openid,"first_prod",productId.toString());
                }
                break;
        }
    }


    private ArrayList<String> insertFirstProd( String openid, HashMap<String, String> qualificationMap){

        String amount = qualificationMap.get("amount");
        ArrayList<String> prodSet = new ArrayList<>();
        HashSet<String> companySet = new HashSet<>();

        int amountInt = 0;

        if (!StringUtils.isEmpty(amount)) {
            amountInt = Integer.valueOf(amount);
        }

        String groupId = "14003";
        if ( amountInt < 10000){
            groupId = "14001";
        }else if ( amountInt <= 50000){
            groupId = "14002";
        }
        UserStatusEntity userStatusEntity = new UserStatusEntity();
        userStatusEntity.setQualificationMap(qualificationMap);
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);
        for (int i = 0; i < prodList.size(); i++) {
            Map productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            String companyId = String.valueOf(productInfo.get("companyId"));
            //根据公司去重
            if (companySet.contains(companyId))
            {
                continue;
            }
            //如果资质匹配就添加
            if (sendProdLinkUtil.isMeet(lenderId,qualificationMap,openid)){
                //有产品推荐
                prodSet.add(lenderId);
                companySet.add(companyId);
                if (prodSet.size() == 3){
                    break;
                }
            }
        }
        return prodSet;
    }


    private static Long mobileEncryptToLong(String mobile){

        if (!StringUtils.isEmpty(mobile)){
            // （手机号码 * 2） + （（手机号码 /2017）*10000）
            Long mobile_l = Long.parseLong(mobile);
            Long suffix = (mobile_l%2017) * 10000;
            Long prefix = mobile_l * 2;
            return prefix + suffix;
        }
        return 0L;
    }

    public JSONObject getWeChatUserInfo(String openid){
        return  JSONObject.parseObject( httpUtil.getForObject( String.format(WX_CENTER+"/wechat/wxcenter/userinfo/get?openId=%s", openid)));
    }
    
    public JSONObject htmlLogin(String code,String domain2) {
   	    return JSONObject.parseObject( httpUtil.getForObject(WX_CENTER+"/wechat/wxcenter/code/htmlLogin?domain2="+domain2+"&code="+code));
	}
}
