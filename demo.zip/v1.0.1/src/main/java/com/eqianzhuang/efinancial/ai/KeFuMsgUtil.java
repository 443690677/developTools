
package com.eqianzhuang.efinancial.ai;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.HttpUtil;
import com.eqianzhuang.efinancial.dao.ChatDAO;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.MsgProcessDAO;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class KeFuMsgUtil{

    @Value("${WX_CENTER}")
    private String WX_CENTER;

    /**
	 * 调测日志记录器。
	 */
    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private  ChatDAO chatDAO;

    @Autowired
    private  MsgProcessDAO  msgProcessDAO;

    @Autowired
    private Configuration configuration;

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    SimpMessagingTemplate simpMessagingTemplate;


    @Autowired
    private IWechatListConfigDao iWechatListConfigDao;

    private static HashMap<Integer,String> STATE_MAP = new HashMap<>() ;

    @PostConstruct
    private void init(){
        STATE_MAP.put(0,"金额");
        STATE_MAP.put(1,"姓名");
        STATE_MAP.put(2,"手机号");
        STATE_MAP.put(3,"卡");
        STATE_MAP.put(4,"芝麻");
        STATE_MAP.put(5,"资金用途");
        STATE_MAP.put(6,"偏好");
        STATE_MAP.put(7,"社保");
        STATE_MAP.put(8,"是否借现金");
        STATE_MAP.put(9,"选择产品");
        STATE_MAP.put(10,"公积金");
        STATE_MAP.put(11,"逾期");
        STATE_MAP.put(12,"车");
        STATE_MAP.put(13,"房");
        STATE_MAP.put(14,"保单");
        STATE_MAP.put(15,"淘宝账号");
        STATE_MAP.put(16,"收入");
        STATE_MAP.put(17,"代发");
        STATE_MAP.put(18,"逾期");
        STATE_MAP.put(19,"房");
        STATE_MAP.put(20,"车");
        STATE_MAP.put(21,"保单");
        STATE_MAP.put(22,"淘宝");
        STATE_MAP.put(23,"是否完成申请");
        STATE_MAP.put(24,"是否批款");
        STATE_MAP.put(25,"是否满足需求");
        STATE_MAP.put(26,"是否满意");
        STATE_MAP.put(27,"没完成申请");
        STATE_MAP.put(28,"公积金");
        STATE_MAP.put(29,"卡");
        STATE_MAP.put(30,"选择服务_半小时");
        STATE_MAP.put(31,"代发");
        STATE_MAP.put(32,"是否批款");
        STATE_MAP.put(33,"选择服务_六小时");
        STATE_MAP.put(34,"选择服务_菜单");
        STATE_MAP.put(35,"收入_半小时");
        STATE_MAP.put(36,"社保_半小时");
        STATE_MAP.put(37,"芝麻分_半小时");
        STATE_MAP.put(38,"选择服务_模板消息");
        STATE_MAP.put(39,"模板消息_未申请原因");
        STATE_MAP.put(44,"用户关注");

        // 该标签用户机构反馈状态为未出额度，用户回复了第三选项，记录用户进行不下去的具体原因
        STATE_MAP.put(1000,"未出额度_具体原因");




    }




    private void send(String openId,String text,String label,UserStatusEntity userStatusEntity) {
            JSONObject msgJson = new JSONObject();
            //空字符串则不发送内容
            if(StringUtils.isEmpty(text)){
                logger.warn("notify to openid:" + openId + " notify nothing");
                return;
            }else {

                msgJson.put("msgtype","text");
                JSONObject textJson = new JSONObject();
                textJson.put("content",text);
                msgJson.put("text",textJson);
            }
        syncJsonMsg(openId,msgJson,label,userStatusEntity);
	}


    public String syncJsonMsg( String openId,JSONObject msgJson ,String label ,UserStatusEntity userStatusEntity) {
        //创建一个全新的jsonMsg
        JSONObject object = new JSONObject();
        object.putAll(msgJson);
        String ghId = weChatConfig.getGhid(openId);
        //发送客服消息
        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            if ("text".equals(object.getString("msgtype"))) {
                JSONObject jsonObject = new JSONObject();
                String  message = object.getJSONObject("text").getString("content");
                jsonObject.put("message",replaceAll(message,userStatusEntity));
                jsonObject.put("msgtype","text");
                simpMessagingTemplate.convertAndSendToUser(openId,  "/web-message"  ,jsonObject);
                object = jsonObject;
                logger.info("webChat消息,openId=" + openId + ",message="+jsonObject.toJSONString());
            }else if ("prod".equals(object.getString("msgtype")))
            {

                JSONObject jsonObject = new JSONObject();
                List<Map<String,Object>> prodInfoList = new ArrayList<>();
                JSONArray prodList = object.getJSONArray("prodList");
                for (int i = 0; i < prodList.size(); i++) {
                    Map<String,Object> prodInfo = iWechatListConfigDao.getProdInfoByLenderId(prodList.getInteger(i));
                    if (!CollectionUtils.isEmpty(prodInfo)) {
                        prodInfoList.add(prodInfo);
                    }
                }
                jsonObject.put("msgtype","prod");
                jsonObject.put("prodList",prodInfoList);
                jsonObject.put("groupId",object.getString("groupId"));
                jsonObject.put("hasMore",object.getBooleanValue("hasMore"));
                if (!StringUtils.isEmpty(object.getString("tip"))) {
                    jsonObject.put("tip",object.getString("tip"));
                }
                simpMessagingTemplate.convertAndSendToUser(openId,  "/web-message"  ,jsonObject);
                logger.info(" webChat消息,openId=" + openId + ",message="+jsonObject.toJSONString());
            }else if ("radio".equals(object.getString("msgtype")) || "number".equals(object.getString("msgtype")))
            {

                JSONObject jsonObject = new JSONObject();
                String  message = replaceAll(object.getString("text"),userStatusEntity);
                jsonObject.put("message",message);
                jsonObject.put("msgtype","text");

                object.put("text",message);
                simpMessagingTemplate.convertAndSendToUser(openId,  "/web-message"  ,object);
                object = jsonObject;
                logger.info("webChat消息,openId=" + openId + ",message="+object.toJSONString());
            } else {
                logger.info("webChat消息类型不支持,openId=" + openId + ",message="+object.toJSONString());
                return "";
            }

            //添加对话到mongodb
            try{
                chatDAO.insertWebChats(openId, "WebY",object.toJSONString());
                //记录对话到mysql
                msgProcessDAO.insertMsg(ghId,openId,null,3,object.toJSONString().replaceAll("[^\\u0000-\\uFFFF]", ""),"webChat",label);
            }catch(Exception e){
                logger.error("记录AI对话失败:",e);
            }

        }else {
            if ("text".equals(object.getString("msgtype"))){
                JSONObject textJson = new JSONObject();
                textJson.put("content",replaceAll(object.getJSONObject("text").getString("content"),userStatusEntity));
                object.put("text",textJson);
            }
            object.put("touser",openId);
            String JsonString = object.toJSONString();

            if ("news".equals(object.getString("msgtype"))) {
                JsonString = replaceAll(JsonString,userStatusEntity);
            }

            //添加对话到mongodb
            try{
                chatDAO.chat(openId, "Y",JsonString);
                //记录对话到mysql
                msgProcessDAO.insertMsg(ghId,openId,null,3,JsonString.replaceAll("[^\\u0000-\\uFFFF]", ""),"",label);
            }catch(Exception e){
                logger.error("记录AI对话失败:",e);
            }

            return httpUtil.postForObject(WX_CENTER+"/wechat/wxcenter/sendCustMsg",JsonString);
        }

        return "";
    }


    public void say(String openId, String text,String label,UserStatusEntity userStatusEntity) {
        send(openId,text,label, userStatusEntity);
    }

    public void say(String openId, String text,UserStatusEntity userStatusEntity) {
        send(openId,text,getLabel(userStatusEntity), userStatusEntity);
    }

    public void sendJsonMsg(String openId,JSONObject msgJson,UserStatusEntity userStatusEntity) {
        sendJsonMsg(openId,msgJson ,getLabel(userStatusEntity),userStatusEntity);
    }

	public void sendJsonMsg(String openId, JSONArray messages,String label,UserStatusEntity userStatusEntity) {
        for (int i = 0; i < messages.size(); i++) {
            sendJsonMsg(openId,messages.getJSONObject(i),label,userStatusEntity);
        }
    }

    public void sendJsonMsg(String openId,JSONObject msgJson,String label,UserStatusEntity userStatusEntity) {
        if (openId.length() < 6) {
            return;
        }
        JSONObject msg = msgJson.getJSONObject(openId.substring(0,6));
        if (CollectionUtils.isEmpty(msg)) {
            msg = msgJson.getJSONObject("default");
        }
        if (CollectionUtils.isEmpty(msg)) {
            logger.error("消息配置错误,openid=" +openId );
            return;
        }
        syncJsonMsg(openId,msg,label,userStatusEntity);
    }


    public String replaceAll(String str, UserStatusEntity userStatusEntity){
        HashMap<String,String> qualification ;
        if (userStatusEntity != null ){
            qualification = userStatusEntity.getQualificationMap();
        }else {
            qualification = new HashMap<>();
        }

        configuration.setTemplateLoader( new StringTemplateLoader());
        Template t;
        try {
            t = new Template("template", new StringReader(str),configuration);
            StringWriter sw  = new StringWriter();
            t.process(qualification,sw);
            return sw.toString();
        } catch (IOException | TemplateException e) {
            e.printStackTrace();
        }
        return str;
    }

    public String getLabel(UserStatusEntity userStatusEntity){
        if (userStatusEntity == null){
            return "";
        }
        String label = STATE_MAP.get(userStatusEntity.getStatus());
        if (StringUtils.isEmpty(label)){
            return "";
        }
        return label;
    }
}
