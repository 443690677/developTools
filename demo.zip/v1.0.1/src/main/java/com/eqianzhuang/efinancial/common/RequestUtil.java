package com.eqianzhuang.efinancial.common;

import com.eqianzhuang.efinancial.common.userAgent.UserAgent;
import com.eqianzhuang.efinancial.common.userAgent.UserAgentParser;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RequestUtil {
    public static String getClientIP(HttpServletRequest request){
        String realIP = request.getHeader("X-Forwarded-For");
        if (StringUtils.isEmpty(realIP)){
            realIP = request.getHeader("X-Real-IP");

            if (StringUtils.isEmpty(realIP)){
                realIP = request.getHeader("Host");
            }
        }else {
            realIP = realIP.split("[,]")[0];
        }
        return realIP;

    }

    public static UserAgent getUserAgent(HttpServletRequest request) throws Exception{
        UserAgentParser userAgentParser  = new UserAgentParser();
        try {
            return userAgentParser.parse(request.getHeader("User-Agent"));
        }catch(Exception e){
            throw e;
        }
    }
    public static UserAgent getUserAgent(String useragent) throws Exception{
        UserAgentParser userAgentParser  = new UserAgentParser();
        try {
            return userAgentParser.parse(useragent);
        }catch(Exception e){
            throw e;
        }
    }

    public static void main(String [] args)throws  Exception{
        String agent = "Mozilla/5.0 (Linux; Android 6.0; V21(X21S) Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044407 Mobile Safari/537.36 MMWEBID/2314 MicroMessenger/6.7.3.1360(0x2607033C) NetType/WIFI Language/zh_CN Process/tools";
//        String agent = "Mozilla/5.0 (Linux; Android 6.0.1; Le X820 Build/FEXCNFN5902605092S; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/044428 Mobile Safari/537.36 MMWEBID/3693 MicroMessenger/6.7.3.1360(0x2607033C) NetType/WIFI Language/zh_CN Process/tools";
        UserAgent userAgent= getUserAgent(agent);
        System.out.print(userAgent);
    }
}
