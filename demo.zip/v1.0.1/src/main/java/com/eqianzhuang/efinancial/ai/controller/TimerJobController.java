package com.eqianzhuang.efinancial.ai.controller;


import com.eqianzhuang.efinancial.ai.timerJob.SatisfactionSurveyJob;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;


/**
 * 微信公众号平台功能相关控制器
 * @author chenbing
 *
 */
@RequestMapping(value = "/efinancial/ai")
@RestController
public class TimerJobController {

    private static Log logger = LogFactory.getLog(TimerJobController.class);

    @Autowired
    UserStatusDao userStatusDao;

    @Autowired
    SatisfactionSurveyJob satisfactionSurveyJob;

    //通过产品组ID获取产品
    @RequestMapping(value="/timer-job", method = RequestMethod.GET,produces ={MediaType.APPLICATION_JSON_UTF8_VALUE})
    public void timerJob( @NotNull @RequestParam("openidPrefix") String openidPrefix)
    {
        satisfactionSurveyJob.satisfactionSurvey(openidPrefix.substring(0,6));
    }

    //通过产品组ID获取产品
    @RequestMapping(value="/test/timer-job", method = RequestMethod.GET,produces ={MediaType.APPLICATION_JSON_UTF8_VALUE})
    public void testTimerJob( @NotNull @RequestParam("openid") String openid)
    {
        String[] openIds = openid.split(",");
        satisfactionSurveyJob.testJob(openIds);
    }
}
