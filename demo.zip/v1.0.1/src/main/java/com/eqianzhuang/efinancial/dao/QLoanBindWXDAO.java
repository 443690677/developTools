/*
 * 融信信息公司源代码，版权归融信信息公司所有。 项目名称 : CreditAgency2015 创建日期 : 2016-10-24 修改历史 : 1.
 * [2016-10-24]创建文件 by luduntao
 */
package com.eqianzhuang.efinancial.dao;

import java.util.Map;

/**
 * //TODO 添加类/接口功能描述
 * @author luduntao
 */
public interface QLoanBindWXDAO
{

    Map<String, Object> getByOpenId(String openId);

    void insertQLoanBindWX(String openid, int media);

    void updateQloanBindWX(String openid, String name);

    void updateQloanBindWX(String openid, String mobile, String mobile_des);

    void updateQloanBindWX(String openid,String wxType,int state);

	Map queryDMByMobileNumber(String mobileNumber);

    Map selectCity(String cityName);

    String selectCityIdsByGroupID(Integer id);

    Integer selectDistributWait(int compId, String mobile);

    void insertDistributWait(int compId, String applyId, String mobile ,String ruleId, String outChannel, String distributBGroupId, String mobile_des,String openid);
}
