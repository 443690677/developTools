package com.eqianzhuang.efinancial.ai.service.feedback.impl;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.SendProdLinkUtil;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.ai.constant.FeedbackStatusEnum;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.service.feedback.FeedbackService;
import com.eqianzhuang.efinancial.common.response.R;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * @Description: 机构反馈相关接口
 * @Author : Junjin Lin
 * @Creation Date : 2019/02/26 10:32
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {
    /**
     * 调测日志记录器。
     */
    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private UserStatusDao userStatusDao;
    @Autowired
    private KeFuMsgUtil keFuMsgUtil;
    @Autowired
    private WeiXinUserInfoUtil weiXinUserInfoUtil;
    @Autowired
    private SendProdLinkUtil sendProdLinkUtil;
    @Autowired
    private WeChatConfig weChatConfig;

    private static final int OPENID_LENGTH = 28;


    @Override
    public R handleOrgFeedbackStatus(String openId, Integer status) {
        logger.info("机构反馈接口接收到的参数: openId=" + openId + ", status=" + status);
        // 校验参数
        if (!validateParam(openId, status)) {
            logger.error("参数不合法");
            return R.error(400, "参数不合法");
        }

        // 根据openid获取用户信息
        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if (userStatusEntity == null) {
            logger.error("该openId获取不到用户信息");
            return R.error(400, "该openId获取不到用户信息");
        }

        // 发送ai消息
        sendAIMsgByStatus(openId, status, userStatusEntity);

        // 设置用户状态
        userStatusEntity.setFeedbackStatus(status);
        userStatusDao.setUserStatusEntity(openId, userStatusEntity);

        return R.ok();
    }

    /**
     * 功能描述: 验证参数是否合法
     *
     * @param: [openId, status]
     * @return: boolean
     * @auther: junjin Lin
     * @date: 2019/2/26 10:40
     */
    private boolean validateParam(String openId, Integer status) {

        // 验证openId
        if (StringUtils.isEmpty(openId) || openId.length() != OPENID_LENGTH) {
            return false;
        }

        // 验证反馈状态
        return FeedbackStatusEnum.checkStatus(status);

    }

    /**
     * 通过状态发送不同消息
     *
     * @param openId
     * @param status
     * @param userStatusEntity
     */
    private void sendAIMsgByStatus(String openId, Integer status, UserStatusEntity userStatusEntity) {
        // 获取用户昵称
        String nickName = getNicknameByOpenId(openId);

        switch (status) {
            // 未出额
            case 2:
                keFuMsgUtil.say(openId, String.format(URLConstant.AI_Q_FEEDBACK2, nickName),
                    FeedbackStatusEnum.getMessageByStatus(status), userStatusEntity);
                break;

            // 未验证
            case 3:
                sendMsgWithLink(openId, status, userStatusEntity, nickName, URLConstant.AI_Q_FEEDBACK3,
                    URLConstant.AI_FEEDBACK3_URL, URLConstant.AI_FEEDBACK3_TIPS);

                keFuMsgUtil.sendJsonMsg(openId,URLConstant.AI_FEEDBACK3_VOICE,"未验证运营商_回复语音",userStatusEntity);
                break;

            // 未提交
            case 4:
                sendMsgWithLink(openId, status, userStatusEntity, nickName, URLConstant.AI_Q_FEEDBACK4,
                    URLConstant.AI_FEEDBACK4_URL, URLConstant.AI_FEEDBACK4_TIPS);

                break;
            default:
                break;
        }
    }

    /**
     * 发送带有链接的消息
     *
     * @param openId           openId
     * @param status           反馈状态
     * @param userStatusEntity 用户session
     * @param nickName         昵称
     * @param question         ai问题
     * @param url              链接
     * @param tips             链接的提示
     */
    private void sendMsgWithLink(String openId, Integer status, UserStatusEntity userStatusEntity, String nickName,
                                 String question, String url, String tips) {

        StringBuilder msg = new StringBuilder(String.format(question, nickName));
        String link = sendProdLinkUtil.getLink(openId, String.format(url, weChatConfig.getDomain(openId)), tips);
        msg.append(link);
        keFuMsgUtil.say(openId, msg.toString(), FeedbackStatusEnum.getMessageByStatus(status), userStatusEntity);
    }

    private String getNicknameByOpenId(String openId) {
        String nickName = "用户";
        JSONObject userInfo = weiXinUserInfoUtil.getWeChatUserInfo(openId);
        if (userInfo != null) {
            nickName = userInfo.getString("nickname");
        }
        return nickName;
    }
}
