package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.common.dbutils.MongoDbUtils;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class ChatDAOImpl implements ChatDAO {

	private Log logger= LogFactory.getLog(this.getClass());
	
	private static final String COLLECTIONS_NAME = "chats";

    private static final String COLLECTIONS_WEBCHATS = "webChats";

	@Autowired
	private MongoDbUtils mongoDbUtils;

	private static MongoCollection<Document> collection ;

    private static MongoCollection<Document> collection_webChats ;


	@PostConstruct
    public void init() {
        collection = mongoDbUtils.mongoInstance().getCollection(COLLECTIONS_NAME);
        collection_webChats =  mongoDbUtils.mongoInstance().getCollection(COLLECTIONS_WEBCHATS);
    }
	/**
	 * 保存对话记录，格式如下：
	 * {'openid':'asdfweoAde','comments':[{'m':'你好','d':12341234234},{'y':'你好','d':1234435234}]}
	 * @param openid  用户的openid
	 * @param whoSay  Y:公众号     I:用户
	 * @param sayContent
	 */
	@Override
	public void chat(String openid,String whoSay,String sayContent){
		Document chat = mongoDbUtils.findOne(collection, "openid", openid);

		//添加对话
		Document sentence = new Document();
		sentence.put(whoSay, sayContent);
		sentence.put("d", new Date());

		if(chat == null){
			Document obj = new Document();
			List<Document> sens = new ArrayList<>();
			sens.add(sentence);
			obj.put("comments", sens);
			obj.put("openid", openid);

			logger.debug("[save]"+obj.toJson());
			mongoDbUtils.save(collection, obj);
		}else{
			logger.debug("[update]" + chat.toJson() + " push element:"+sentence);
			mongoDbUtils.pushById(collection,chat.getObjectId("_id").toHexString(), "comments", sentence);
		}

	}


    @Override
    public void insertWebChats(String openid, String whoSay, String sayContent){

        chat(openid,whoSay,sayContent);

        Document chat = mongoDbUtils.findOne(collection_webChats, "openid", openid);

        //添加对话
        Document sentence = new Document();
        sentence.put("from", whoSay);
        sentence.put("msg", sayContent);
        sentence.put("date", new Date());

        if(chat == null){
            Document obj = new Document();
            List<Document> sens = new ArrayList<>();
            sens.add(sentence);
            obj.put("comments", sens);
            obj.put("openid", openid);
            logger.debug("[save]"+obj.toJson());
            mongoDbUtils.save(collection_webChats, obj);
        }else{
            logger.debug("[update]" + chat.toJson() + " push element:"+sentence);
            mongoDbUtils.pushById(collection_webChats,chat.getObjectId("_id").toHexString(), "comments", sentence);
        }

    }

    @Override
    public Document getWebChats(String openid){

        Document where = new Document();
        where.put("openid",openid);
        FindIterable<Document> findIt = collection_webChats.find(where);
        if (findIt == null){
            return null;
        }
        return findIt.first();
    }

}
