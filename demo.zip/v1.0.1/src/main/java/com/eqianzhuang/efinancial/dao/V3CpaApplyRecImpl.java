/*
 * 文件名：IWechatListConfigDaoImpl.java 版权：深圳融信信息咨询有限公司 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年7月31日 下午5:05:31 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chenbing
 * @since 2.2.4
 */
@Repository
public class V3CpaApplyRecImpl implements V3CpaApplyRec
{

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<String> selectProdApplyRec(String openid, Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<String> prodId = jdbcTemplate.queryForList("SELECT DISTINCT t.prodId from credit_cpa.v3_cpa_apply_rec t WHERE t.businessId = ? AND t.createdDate > ? ",String.class,openid ,sdf.format(date));
        if (CollectionUtils.isEmpty(prodId)){
            return new ArrayList<>();
        }else {
            return prodId;
        }

    }

    @Override
    public List<String> selectApplyRec(String openid, Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<String> prodId = jdbcTemplate.queryForList("SELECT t.prodId from credit_cpa.v3_cpa_apply_rec t WHERE t.businessId = ? AND t.createdDate > ? ORDER BY createdDate DESC;",String.class,openid ,sdf.format(date));
        if (CollectionUtils.isEmpty(prodId)){
            return new ArrayList<>();
        }else {
            return prodId;
        }
    }


}
