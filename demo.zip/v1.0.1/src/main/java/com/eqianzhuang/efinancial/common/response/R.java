package com.eqianzhuang.efinancial.common.response;

import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 通用响应类
 * @Author : Junjin Lin
 * @Creation Date : 2019/01/24 9:27
 */
public class R extends HashMap<String, Object> {
    private static final long serialVersionUID = 1L;

    private static final String CODE = "code";
    private static final String MESSAGE = "msg";
    private static final String DATA = "data";

    public R() {
        put(CODE, 0);
        put(MESSAGE, "success");
    }

    public static R error(Integer code, String msg) {
        R r = new R();
        r.put(CODE, code);
        r.put(MESSAGE, msg);
        return r;
    }

    public static R ok(String msg) {
        R r = new R();
        r.put(MESSAGE, msg);
        return r;
    }

    public static R ok(Map<String, Object> map) {
        R r = new R();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(DATA, map);
        r.putAll(dataMap);
        return r;
    }

    public static R ok(Object object) {
        R r = new R();
        r.put(DATA, object);
        return r;
    }

    public static R ok() {
        return new R();
    }

    public R put(String key, Object value) {
        super.put(key, value);
        return this;
    }
}
