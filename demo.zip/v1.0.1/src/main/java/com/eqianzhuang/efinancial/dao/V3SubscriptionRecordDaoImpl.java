package com.eqianzhuang.efinancial.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class V3SubscriptionRecordDaoImpl implements V3SubscriptionRecordDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public void delete(String openid) {
        jdbcTemplate.update("DELETE FROM credit_cpa.v3_subscription_record where openid = ?;",openid);
    }
}
