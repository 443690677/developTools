package com.eqianzhuang.efinancial.ai;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.constant.WebChatConstant;
import com.eqianzhuang.efinancial.common.MediaUtil;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.V3CpaApplyRec;
import com.eqianzhuang.efinancial.dao.V3CusAptitudeAiDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

@Component
public class SendProdLinkUtil {

    private Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private KeFuMsgUtil keFuMsgUtil;

    @Autowired
    private IWechatListConfigDao iWechatListConfigDao;

    @Autowired
    private V3CusAptitudeAiDao v3CusAptitudeAiDao;

    @Autowired
    private V3CpaApplyRec v3CpaApplyRec;

    @Autowired
    private WeChatConfig weChatConfig;

    private static HashSet<String> attrSet =  new HashSet<>();
    @PostConstruct
    void init()
    {
        attrSet.add("zhimaScore");
        attrSet.add("social_insurance");
        attrSet.add("publicFund");
        attrSet.add("Bank_Credit");
        attrSet.add("ownCar");
        attrSet.add("ownHousing");
        attrSet.add("ownTBAccount");
        attrSet.add("insurance");
        attrSet.add("salary");
        attrSet.add("Bank_Behalf");
        attrSet.add("creditCard");
    }

    //需要过滤资质
    public void sendProductLinkWithQ(String openid,UserStatusEntity userStatusEntity, int sendSize ){

        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid),userStatusEntity.getMediaNo());
        String groupId = userStatusEntity.getGroupId();
        userStatusEntity.setStatus(996);

        HashMap<String, String> qualificationMap = userStatusEntity.getQualificationMap();

        //已经推荐给用户
        HashSet<String> productSet = userStatusEntity.getProductSet();

        //已经推荐给用户
        HashSet<String> companySet = userStatusEntity.getCompanySet();


        ArrayList<String> prodSet = new ArrayList<>();

        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + "> openid:" + openid);

        int size = productSet.size() ;
        boolean hasMore = false;
        StringBuilder msg =  new StringBuilder(URLConstant.AI_TIPS79);
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);
        for (int i = 0; i < prodList.size() ; i++) {
           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if ( productSet.contains(lenderId)){
                logger.info("不推荐：已经推荐过链接 openid:" + openid +" lenderId:" + lenderId );
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));

            //根据公司去重
            if (companySet.contains(companyId))
            {
                continue;
            }

            //符合资质就推荐
            if ( isMeet(lenderId,qualificationMap,openid) ) {

                if ( productSet.size()  >= size + sendSize ){
                    hasMore = true;
                    logger.info("单次推荐上限  sendSize=" +  (productSet.size() - size)  +" lenderId:" + lenderId );
                    break;
                }

                String name = String.valueOf(productInfo.get("name"));
                String urlId = String.valueOf(productInfo.get("urlId"));
                prodSet.add(lenderId);
                productSet.add(lenderId);
                companySet.add(companyId);
                msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid), openid, chn, lenderId,groupId,urlId, name));
            }
        }

        int sizeNew =  productSet.size();
        if (size < sizeNew && size == 0 ){
            String chatCount = qualificationMap.get("chatCount");
            if ("2".equals(chatCount)){
                int ApplyCount = new HashSet<>(v3CpaApplyRec.selectProdApplyRec( openid,new Date(0L))).size();
                int percent;
                if ( ApplyCount > 5){
                    percent = 80;
                }else {
                    percent = ApplyCount * 100 / 7;
                }
                keFuMsgUtil.say(openid, String.format(URLConstant.AI_TIPS45,ApplyCount,percent), "二次对话首次推荐产品", userStatusEntity);
            }

        }

        if ( size < sizeNew ){


            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                sendWebProd(openid, prodSet,userStatusEntity,groupId,size == 0,hasMore);

            }else {
                //符合资质就推荐
                keFuMsgUtil.say(openid, msg.toString(), "推荐产品",userStatusEntity);
            }

        }else {

            keFuMsgUtil.say(openid, URLConstant.TO_MENU_REPLY,userStatusEntity);

        }

        if ( size == 0 && MediaUtil.getMedia(weChatConfig.getMediaName(openid),0).equals(chn)) {
            keFuMsgUtil.sendJsonMsg(openid ,URLConstant.AI_TIPS41,"主流程推荐产品",userStatusEntity);
        }

    }

    //不需要过滤资质
    public void sendProductLinkNotQ(String openid, UserStatusEntity userStatusEntity, int sendSize ,String startMsg) {
        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid:" + openid);
        userStatusEntity.setStatus(997);
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());
        String groupId = userStatusEntity.getGroupId();

        //已经推荐给用户
        HashSet<String> productSet = userStatusEntity.getProductSet();

        //已经推荐给用户
        HashSet<String> companySet = userStatusEntity.getCompanySet();

        ArrayList<String> prodSet = new ArrayList<>();

        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);


        int size = productSet.size();
        boolean hasMore = false;
        StringBuilder msg = new StringBuilder(startMsg);
        for (int i = 0; i < prodList.size(); i++) {
           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if (productSet.contains(lenderId)) {
                logger.info("不推荐：已经推荐过链接 openid:" + openid + " lenderid:" + lenderId);
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));
            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }
            if ( productSet.size() >= size + sendSize) {
                hasMore = true;
                break;
            }
            String name = String.valueOf(productInfo.get("name"));
            String urlId = String.valueOf(productInfo.get("urlId"));
            prodSet.add(lenderId);
            productSet.add(lenderId);
            companySet.add(companyId);
            msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid), openid, chn, lenderId,groupId,urlId, name));

        }

        int sizeNew = productSet.size();
        if (size < sizeNew) {
            if ( size == 0){
                HashMap<String, String> qualification =  userStatusEntity.getQualificationMap();
                String chatCount = qualification.get("chatCount");
                if ("2".equals(chatCount)){
                    int ApplyCount = v3CpaApplyRec.selectProdApplyRec( openid,new Date(0L)).size();
                    int percent;
                    if ( ApplyCount > 5){
                        percent = 80;
                    }else {
                        percent = ApplyCount * 100 / 7;
                    }
                    keFuMsgUtil.say(openid, String.format(URLConstant.AI_TIPS45,ApplyCount,percent), "二次对话首次推荐产品", userStatusEntity);
                }
            }

            String name = Thread.currentThread().getName();
            if (name.startsWith("webChat")){
                sendWebProd(openid, prodSet,userStatusEntity,groupId,size == 0,hasMore);
            }else {
                //符合资质就推荐
                keFuMsgUtil.say(openid, msg.toString(), "推荐产品",userStatusEntity);
            }

            if ( size == 0 && MediaUtil.getMedia(weChatConfig.getMediaName(openid),0).equals(chn)) {
                keFuMsgUtil.sendJsonMsg(openid ,URLConstant.AI_TIPS41,"主流程推荐产品",userStatusEntity);
            }

        } else {
            keFuMsgUtil.say(openid, URLConstant.AI_TIPS7,userStatusEntity);
        }

    }


    //用户回复“方案”，需要匹配资质；
    public void sendProdByReplyFA(String openid,UserStatusEntity userStatusEntity,String startMsg) {
        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid:" + openid);
        userStatusEntity.setStatus(999);
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), 1);
        String groupId = userStatusEntity.getGroupId();
        HashMap<String,String> qualification= userStatusEntity.getQualificationMap();

        HashSet<String> productSet = new HashSet<>();

        HashSet<String> companySet = new HashSet<>();

        ArrayList<String> prodSet = new ArrayList<>();
        StringBuilder msg = new StringBuilder(startMsg);
        int size = productSet.size() ;
        boolean hasMore = false;
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);
        for (int i = 0; i < prodList.size() ; i++) {
           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if (productSet.contains(lenderId)) {
                logger.info("已经推荐过openid:" + openid + " lenderId:" + lenderId);
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));
            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }

            //符合资质就推荐
            if ( isMeet(lenderId,qualification,openid) ) {
                if ( productSet.size() >= size + 5 ){
                    hasMore =true;
                    break;
                }
                String name = String.valueOf(productInfo.get("name"));
                String urlId = String.valueOf(productInfo.get("urlId"));
                prodSet.add(lenderId);
                productSet.add(lenderId);
                companySet.add(companyId);
                msg.append(String.format(URLConstant.AI_TO_URL, weChatConfig.getDomain(openid),openid, chn, lenderId,groupId,urlId, name));
            }
        }

        String link = getLink(openid ,String.format(URLConstant.AI_TIPS53_URL,weChatConfig.getDomain(openid),openid,chn),URLConstant.AI_TIPS53);
        msg.append(link);

        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            sendWebProd(openid, prodSet,userStatusEntity,groupId,true,hasMore);
        }else {
            //符合资质就推荐
            keFuMsgUtil.say(openid, msg.toString(), "回复方案推荐产品",userStatusEntity);
        }
    }


    //用户回复“最新”，不需要匹配资质；
    public void sendProdByReplyXP(String openid, UserStatusEntity userStatusEntity,String startMsg) {
        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid:" + openid);
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());

        String groupId = userStatusEntity.getGroupId();

        HashSet<String> productSet = new HashSet<>();

        HashSet<String> companySet = new HashSet<>();

        ArrayList<String> prodSet = new ArrayList<>();

        StringBuilder msg = new StringBuilder(startMsg);
        int size = productSet.size();
        boolean hasMore = false;
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);
        for (int i = 0; i < prodList.size() ; i++) {

            Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if (productSet.contains(lenderId)) {
                logger.info("已经推荐过openid:" + openid + " lenderId:" + lenderId);
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));

            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }

            if ( productSet.size() >= size + 5 ){
                hasMore = true;
                break;
            }
            prodSet.add(lenderId);
            productSet.add(lenderId);
            companySet.add(companyId);
            String name = String.valueOf(productInfo.get("name"));
            String urlId = String.valueOf(productInfo.get("urlId"));
            msg.append(String.format(URLConstant.AI_TO_URL, weChatConfig.getDomain(openid),openid, chn, lenderId,groupId,urlId, name));



        }
        String link = getLink(openid ,String.format(URLConstant.AI_TIPS54_URL,weChatConfig.getDomain(openid),openid,chn),URLConstant.AI_TIPS54);
        msg.append(link);

        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            sendWebProd(openid, prodSet,userStatusEntity,groupId,true,hasMore);
        }else {
            //符合资质就推荐
            keFuMsgUtil.say(openid, msg.toString(), "回复新品推荐产品",userStatusEntity);
        }

        keFuMsgUtil.sendJsonMsg(openid,URLConstant.AI_TIPS54_VOICE,"回复新品_语音",userStatusEntity);
    }



    public boolean isMeet(String lenderId,HashMap<String, String> qualification,String openid){
        List<Map<String, Object>> prodAttrList = iWechatListConfigDao.getProductAttr(lenderId);
        if (!CollectionUtils.isEmpty(prodAttrList)){
            for (int j = 0; j < prodAttrList.size(); j++) {
                boolean isMeet = true;
                Map prodAttrMap = prodAttrList.get(j);
                for (Object key : prodAttrMap.keySet()) {
                    String sKey = String.valueOf(key);
                    if (attrSet.contains(sKey)){
                        if ("zhimaScore".equals(sKey)){
                            String zhimaScoreStr = qualification.get(sKey);
                            String attrZhimaScoreStr = String.valueOf(prodAttrMap.get(sKey));
                            if (!"0".equals(attrZhimaScoreStr)){
                                if ( ValidUtils.isNumeric(zhimaScoreStr) && ValidUtils.isNumeric(attrZhimaScoreStr))
                                {
                                    int zhimaScore = Integer.parseInt(zhimaScoreStr);
                                    int attrZhimaScore = Integer.parseInt(attrZhimaScoreStr);
                                    if ( zhimaScore < attrZhimaScore)
                                    {
                                        logger.info("芝麻分不符合 attrZhimaScore=" + attrZhimaScore + " zhimaScore=" + zhimaScore + " openid=" + openid +" lenderid:" + lenderId );
                                        isMeet = false;
                                        break;
                                    }
                                }else {

                                    logger.info("不符合数字 attrZhimaScore=" + attrZhimaScoreStr  + " zhimaScore=" + zhimaScoreStr + " openid=" + openid +" lenderid:" + lenderId );
                                    isMeet = false;
                                    break;
                                }
                            }
                        }else if( "1".equals(String.valueOf(prodAttrMap.get(sKey))) && !"True".equals(qualification.get(sKey))) {
                            logger.info("不符合条件：key=" + key + " value=" + qualification.get(sKey) + " openid=" + openid +" lenderid:" + lenderId );
                            isMeet = false;
                            break;
                        }
                    }
                }

                if (isMeet){
                    return true;
                }
            }
            return false;
        }else {
            logger.info("没有配置资质：lenderid：" + lenderId + " openid=" + openid );
            return false;
        }
    }

    //放水、不查征信关键字回复
    public void sendProductLinkKeyWords(String openid, UserStatusEntity userStatusEntity, int sendSize ,String startMsg,String endMsg,String moreMsg,String moreUrl,String keyWords) {

        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());

        String groupId = userStatusEntity.getGroupId();

        //已经推荐给用户
        HashSet<String> productSet = new HashSet<>();

        //已经推荐给用户
        HashSet<String> companySet = new HashSet<>();

        ArrayList<String> prodSet = new ArrayList<>();

        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openId:" + openid);

        int size = productSet.size();

        boolean hasMore = false;

        StringBuilder msg = new StringBuilder(startMsg);

        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);

        for (int i = 0; i < prodList.size() ; i++) {

           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));


            if (productSet.contains(lenderId)) {
                logger.info("不推荐：已经推荐过链接 openid:" + openid + " lenderid:" + lenderId);
                continue;
            }
            String companyId = String.valueOf(productInfo.get("companyId"));
            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }

            if (productSet.size() >=size + sendSize) {

                hasMore = true;
                logger.info("不推荐：sendSize=" + productSet.size() + " lenderid:" + lenderId);
                break;
            }
            String name = String.valueOf(productInfo.get("name"));
            String urlId = String.valueOf(productInfo.get("urlId"));
            prodSet.add(lenderId);
            productSet.add(lenderId);
            companySet.add(companyId);
            msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid) ,openid, chn, lenderId,groupId,urlId, name));
        }
        msg.append(endMsg);
        String link = getLink(openid ,String.format(moreUrl,weChatConfig.getDomain(openid),openid,chn),moreMsg);
        msg.append(link);

        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            sendWebProd(openid, prodSet,userStatusEntity,groupId,true,hasMore);
        }else {
            //符合资质就推荐
            keFuMsgUtil.say(openid, msg.toString(), keyWords+"_推荐产品",userStatusEntity);
        }

    }


    //不需要过滤资质
    public void sendProductLinkNotQ1st(String openid, UserStatusEntity userStatusEntity, int sendSize) {
        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid:" + openid);
        userStatusEntity.setStatus(997);
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());
        String groupId = userStatusEntity.getGroupId();

        //已经推荐给用户
        HashSet<String> productSet = userStatusEntity.getProductSet();

        ArrayList<String> prodSet = new ArrayList<>();


        //已经推荐给用户
        HashSet<String> companySet = userStatusEntity.getCompanySet();
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);

        int size = productSet.size();
        boolean hasMore = false;
        StringBuilder msg = new StringBuilder(URLConstant.AI_TIPS70);
        for (int i = 0; i < prodList.size(); i++) {
           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if (productSet.contains(lenderId)) {
                logger.info("不推荐：已经推荐过链接 openid:" + openid + " lenderid:" + lenderId);
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));
            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }

            if (productSet.size() >=size + sendSize) {

                hasMore = true;
                break;
            }

            String name = String.valueOf(productInfo.get("name"));
            String urlId = String.valueOf(productInfo.get("urlId"));
            prodSet.add(lenderId);
            productSet.add(lenderId);
            companySet.add(companyId);

            int percent;
            if (productSet.size() - size == 1) {
                percent = generateRandom(96,100);
            }else if (productSet.size() - size == 2) {
                percent = generateRandom(92,96);
            }else if (productSet.size() - size == 3){
                percent = generateRandom(88,92);
            }else if (productSet.size() - size == 4){
                percent = generateRandom(84,88);
            }else{
                percent = generateRandom(80,84);
            }

            msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid), openid, chn, lenderId,groupId,urlId, name + " 匹配度" + percent + "%"));
        }
        String name = Thread.currentThread().getName();
        if (size < productSet.size()) {
            msg.append(URLConstant.AI_TIPS71);
            if ( MediaUtil.getMedia(weChatConfig.getMediaName(openid),0).equals(chn)){
                v3CusAptitudeAiDao.insertUserAction(openid,"final_prod" , prodSet.toString());
            }

            if (name.startsWith("webChat")){

                sendWebProd(openid, prodSet,userStatusEntity,groupId,true,hasMore);
            }else {
                //符合资质就推荐
                keFuMsgUtil.say(openid, msg.toString(),"推荐产品",userStatusEntity);
            }
        } else {
            if (name.startsWith("webChat")){
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS82,"webChat引导语",userStatusEntity);
            }else {
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS7,userStatusEntity);
            }
        }

    }


    //需要过滤资质
    public void sendProductLinkWithQ1st(String openid,UserStatusEntity userStatusEntity, int sendSize ){

        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid),userStatusEntity.getMediaNo());
        String groupId = userStatusEntity.getGroupId();
        userStatusEntity.setStatus(996);

        HashMap<String, String> qualificationMap = userStatusEntity.getQualificationMap();

        //已经推荐给用户
        HashSet<String> productSet = userStatusEntity.getProductSet();


        ArrayList<String> prodSet = new ArrayList<>();

        //已经推荐给用户
        HashSet<String> companySet = userStatusEntity.getCompanySet();


        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + "> openid:" + openid);

        int size = productSet.size() ;
        boolean hasMore = false;
        StringBuilder msg =  new StringBuilder(URLConstant.AI_TIPS74);
        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);
        for (int i = 0; i < prodList.size() ; i++) {
           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if ( productSet.contains(lenderId)){
                logger.info("不推荐：已经推荐过链接 openid:" + openid +" lenderId:" + lenderId );
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));

            //根据公司去重
            if (companySet.contains(companyId))
            {
                continue;
            }
            //符合资质就推荐
            if ( isMeet(lenderId,qualificationMap,openid) ) {

                if ( productSet.size()  >= size + sendSize ){
                    hasMore = true;
                    logger.info("单次推荐上限  sendSize=" +  (productSet.size() - size)  +" lenderId:" + lenderId );
                    break;
                }

                String name = String.valueOf(productInfo.get("name"));
                String urlId = String.valueOf(productInfo.get("urlId"));
                prodSet.add(lenderId);
                productSet.add(lenderId);
                companySet.add(companyId);
                int percent;
                if (productSet.size() - size == 1) {
                    percent = generateRandom(96,100);
                }else if (productSet.size() - size == 2) {
                    percent = generateRandom(92,96);
                }else if (productSet.size() - size == 3){
                    percent = generateRandom(88,92);
                }else if (productSet.size() - size == 4){
                    percent = generateRandom(84,88);
                }else{
                    percent = generateRandom(80,84);
                }

                msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid), openid, chn, lenderId,groupId,urlId, name + " 匹配度" + percent + "%"));
            }

        }

        int sizeNew =  productSet.size();
        if (size < sizeNew ){
            if ( MediaUtil.getMedia(weChatConfig.getMediaName(openid),0).equals(chn)){
                v3CusAptitudeAiDao.insertUserAction(openid,"final_prod" , prodSet.toString());
            }
        }

        msg.append(URLConstant.AI_TIPS75);
        String name = Thread.currentThread().getName();
        if ( size < sizeNew){
            if (name.startsWith("webChat")){
                sendWebProd(openid, prodSet,userStatusEntity,groupId,true,hasMore);
            }else {
                keFuMsgUtil.say(openid, msg.toString(),"推荐产品",userStatusEntity);
            }
        }else {
            if (name.startsWith("webChat")){
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS82,"webChat引导语",userStatusEntity);
            }else {
                keFuMsgUtil.say(openid, URLConstant.TO_MENU_REPLY,userStatusEntity);
            }
        }

        if ( size == 0 && MediaUtil.getMedia(weChatConfig.getMediaName(openid),0).equals(chn)) {
            keFuMsgUtil.sendJsonMsg(openid ,URLConstant.AI_TIPS41,"主流程推荐产品",userStatusEntity);
        }

    }

    //需要过滤资质
    public void sendLink(String openid, UserStatusEntity userStatusEntity, int sendSize ,String startMsg,String endMsg,String label) {
        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid：" + openid);

        userStatusEntity.setStatus(996);
        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());
        String groupId = userStatusEntity.getGroupId();

        //已经推荐给用户
        HashSet<String> productSet = userStatusEntity.getProductSet();

        //已经推荐给用户
        HashSet<String> companySet = userStatusEntity.getCompanySet();

        int size = productSet.size();

        boolean hasMore = false;

        ArrayList<String> prodSet = new ArrayList<>();

        StringBuilder msg = new StringBuilder(startMsg);

        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openid);

        for (int i = 0; i < prodList.size() ; i++) {

           Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));

            if (productSet.contains(lenderId)) {
                logger.info("不推荐：已经推荐过链接 openid:" + openid + " lenderId:" + lenderId);
                continue;
            }

            String companyId = String.valueOf(productInfo.get("companyId"));

            //根据公司去重
            if (companySet.contains(companyId)) {
                continue;
            }

            if (isMeet(lenderId, userStatusEntity.getQualificationMap(), openid)) {

                if (productSet.size() >= size + sendSize) {
                    hasMore = true;
                    break;
                }
                String name = String.valueOf(productInfo.get("name"));
                String urlId = String.valueOf(productInfo.get("urlId"));
                prodSet.add(lenderId);
                productSet.add(lenderId);
                companySet.add(companyId);
                msg.append(String.format(URLConstant.AI_TO_URL, weChatConfig.getDomain(openid), openid, chn, lenderId, groupId, urlId, name));
            }
        }
        msg.append(endMsg);
        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            sendWebProd(openid, prodSet,userStatusEntity,groupId,size ==0,hasMore);
        }else {
            //符合资质就推荐
            keFuMsgUtil.say(openid, msg.toString(), label,userStatusEntity);
        }
    }


    public String getLink(String openid, String url, String msg){
        String link = null;
        try {
            link = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + weChatConfig.getAppId(openid) + "&redirect_uri=" + URLEncoder.encode(url,"utf-8")
                    + "&response_type=code&scope=snsapi_userinfo&state=10004#wechat_redirect";
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "<a href=\""+ link  + "\">"+msg+"</a>";
    }

    private int generateRandom(int min,int max){
        return (int) ( min + Math.random() * ( max - min));
    }

    private void sendWebProd(String openid ,ArrayList<String> prodSet,UserStatusEntity userStatusEntity,String groupId,boolean isFirst,boolean hasMore){

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("prodList",prodSet);
        jsonObject.put("msgtype","prod");
        jsonObject.put("groupId",groupId);

        if (isFirst) {
            jsonObject.put("tip", WebChatConstant.TIP1);
        }
        jsonObject.put("hasMore",hasMore);
        keFuMsgUtil.syncJsonMsg(openid,jsonObject,"Web推荐产品",userStatusEntity);
    }

    //发送用户要求的产品
    public void sendProductLink(String openid, UserStatusEntity userStatusEntity, JSONArray prodName, int sendSize) {

        logger.info("发送产品链接：userStatusEntity ：" + JSONObject.toJSONString(userStatusEntity) + " openid:" + openid);

        String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openid), userStatusEntity.getMediaNo());

        String groupId = "25108";
        //已经推荐给用户
        HashSet<String> productSet = new HashSet<>() ;

        ArrayList<String> prodSet = new ArrayList<>();

        List<Map<String, Object>> prodList = iWechatListConfigDao.getProdInfoByName(prodName);
        int size = productSet.size();
        boolean hasMore = false;
        StringBuilder msg = new StringBuilder(URLConstant.AI_TIPS83);
        for (int i = 0; i < prodList.size(); i++) {
            Map<String, Object> productInfo = prodList.get(i);
            String lenderId = String.valueOf(productInfo.get("id"));
            if (productSet.contains(lenderId)) {
                logger.info("不推荐：已经推荐过链接 openid:" + openid + " lenderid:" + lenderId);
                continue;
            }

            if ( productSet.size() >= size + sendSize) {
                hasMore = true;
                break;
            }
            String name = String.valueOf(productInfo.get("name"));
            String urlId = String.valueOf(productInfo.get("urlId"));
            prodSet.add(lenderId);
            productSet.add(lenderId);
            msg.append(String.format(URLConstant.AI_TO_URL,weChatConfig.getDomain(openid), openid, chn, lenderId,groupId,urlId, name));

        }

        String name = Thread.currentThread().getName();
        if (size < productSet.size()) {
            if (name.startsWith("webChat")){
                sendWebProd(openid, prodSet,userStatusEntity,groupId,size == 0,hasMore);
            }else {
                //符合资质就推荐
                keFuMsgUtil.say(openid, msg.toString(),"推荐产品",userStatusEntity);
            }
        } else {
            if (name.startsWith("webChat")){
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS84,"",userStatusEntity);
            }else {
                keFuMsgUtil.say(openid, URLConstant.AI_TIPS84,userStatusEntity);
            }
        }

    }

}
