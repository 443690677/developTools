package com.eqianzhuang.efinancial.ai.service;

import com.eqianzhuang.efinancial.entity.UserStatusEntity;

public interface HongbaoService {


    void hongbaoProcess(String openid, UserStatusEntity userStatusEntity);

    void lingHongbaoProcess(String openid);
}
