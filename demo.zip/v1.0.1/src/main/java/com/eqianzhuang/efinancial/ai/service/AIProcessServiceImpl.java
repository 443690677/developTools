package com.eqianzhuang.efinancial.ai.service;


import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.SendProdLinkUtil;
import com.eqianzhuang.efinancial.ai.constant.FeedbackStatusEnum;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.HttpUtil;
import com.eqianzhuang.efinancial.dao.DispatchUserDao;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.dao.V3SubscriptionRecordDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class AIProcessServiceImpl implements AIProcessService {

    /**
     * 调测日志记录器。
     */
    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private UserStatusDao userStatusDao;

    @Autowired
    private AIWorker aIWorker;

    @Autowired
    private SendProdLinkUtil sendProdLinkUtil;

    @Autowired
    private KeFuMsgUtil keFuMsgUtil;

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    private DispatchUserDao dispatchUserDao;


    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private WeChatConfig weChatConfig;

    @Autowired
    private V3SubscriptionRecordDao v3SubscriptionRecordDao;

    @Autowired
    private HongbaoService hongbaoService;


    @Value("${DISPATCH_HOST}")
    private String DISPATCH_HOST;

    @Override
    @Async("asyncWorker")
    public void wxChatProcess(String openid, String answer,UserStatusEntity userStatusEntity) {
        if (dispatchUserDao.isDispatchUser(openid)){
            try {

                JSONObject result = JSONObject.parseObject(httpUtil.getForObject( DISPATCH_HOST + "/eqzh-admin-common/dialogue/message/receive?openid="+openid+"&content="+answer));
                String code = result.getString("code");
                if( !"000000".equals(code)){
                    dispatchUserDao.deleteDispatchUser(openid);
                    AIProcess(openid,answer,userStatusEntity);
                }else {
                    //用户回复偏好，转到人工客服；则后续流程进行产品推荐
                    if (userStatusEntity.getStatus() == 6) {
                        aIWorker.invokingAIService(openid, "偏好", answer, URLConstant.QUESTIONS6_KEY, userStatusEntity.getPreviousQuestion(), userStatusEntity.getQualificationMap(), "userPlan");
                        //userStatusEntity.setStatus(996);
                    }
                }

            }catch (Exception e){
                logger.error("调用接口报错wxChatProcess",e);
                dispatchUserDao.deleteDispatchUser(openid);
                AIProcess(openid,answer,userStatusEntity);
            }
        }else {
            AIProcess(openid,answer,userStatusEntity);
        }

        //更新用户状态
        userStatusDao.setUserStatusEntity( openid,userStatusEntity);
    }

    @Override
    @Async("webChatAsyncWorker")
    public void webChatProcess(String openid, String answer,UserStatusEntity userStatusEntity) {

        AIProcess(openid,answer,userStatusEntity);

        if( userStatusDao.getUserStatusEntity(openid) != null){
            userStatusDao.setUserStatusEntity(openid,userStatusEntity);
        }
    }

    @Override
    @Async("webChatAsyncWorker")
    public void webChatPrevious(String openId, UserStatusEntity userStatusEntity) {
        HashMap<String, String> qualification = userStatusEntity.getQualificationMap();

        String key = userStatusEntity.getLastQuestion();
        qualification.remove(key);
        logger.info("webChatPrevious(),openId=" + openId+",key="+key);
        aIWorker.chooseQuestion(openId,qualification,userStatusEntity,"");
        userStatusDao.setUserStatusEntity(openId,userStatusEntity);
    }

    @Override
    @Async("webChatAsyncWorker")
    public void webChatGuide(String openId) {

        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if(userStatusEntity == null){
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","链接超时，请重新点击菜单。");
            jsonObject.put("msgtype","text");
            simpMessagingTemplate.convertAndSendToUser(openId,  "/web-message"  ,jsonObject);
            logger.info(" webChat消息,openId=" + openId + ",message="+jsonObject.toJSONString());
        }else {
            HashMap<String, String> qualification = userStatusEntity.getQualificationMap();
            if (!"True".equals(qualification.get("webChatGuideIsFinish"))) {
                qualification.put("webChatGuideIsFinish","True");
                if (!"True".equals(userStatusEntity.getQualificationMap().get("mainIsFinish"))) {
                    keFuMsgUtil.say(openId,"推荐产品前了解一下您的贷款情况，方便做贷款渠道推荐。","web引导语",userStatusEntity);
                }
                aIWorker.chooseQuestion(openId,userStatusEntity.getQualificationMap(),userStatusEntity,"");
                userStatusDao.setUserStatusEntity(openId,userStatusEntity);
            }else {
                if (!"True".equals(userStatusEntity.getQualificationMap().get("mainIsFinish"))) {
                    aIWorker.chooseQuestion(openId,userStatusEntity.getQualificationMap(),userStatusEntity,"");
                    userStatusDao.setUserStatusEntity(openId,userStatusEntity);
                }
            }
        }
    }




    private void AIProcess(String openid, String answer,UserStatusEntity userStatusEntity) {

        //有回复AI
        userStatusEntity.setReplyAI(true);

        //特殊回复1
        if ("方案".equals(answer)) {

            userStatusEntity.setGroupId("25030");
            sendProdLinkUtil.sendProdByReplyFA(openid,userStatusEntity,URLConstant.AI_TIPS51);
        //特殊回复2
        }else if ("新品".equals(answer)) {

            userStatusEntity.setGroupId("25038");
            sendProdLinkUtil.sendProdByReplyXP(openid,userStatusEntity,URLConstant.AI_TIPS52);
        }else if("放水".equals(answer)){

            String groupId = "25049";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendProductLinkKeyWords(openid,userStatusEntity,5,URLConstant.AI_TIPS55_START,URLConstant.AI_TIPS55_END,URLConstant.AI_TIPS55_MORE,URLConstant.AI_TIPS55_MORE_URL,"放水");
        }else if("不查征信".equals(answer)){

            String groupId = "25050";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendProductLinkKeyWords(openid,userStatusEntity,5,URLConstant.AI_TIPS56_START,URLConstant.AI_TIPS56_END,URLConstant.AI_TIPS56_MORE,URLConstant.AI_TIPS56_MORE_URL,"不查征信");
        }else if("低息".equals(answer)){

            String groupId = "25061";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendProductLinkKeyWords(openid,userStatusEntity,5,URLConstant.AI_TIPS66_START,URLConstant.AI_TIPS66_END,URLConstant.AI_TIPS66_MORE,URLConstant.AI_TIPS66_MORE_URL,"低息");
        }else if("白户".equals(answer)){

            String groupId = "25062";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendProductLinkKeyWords(openid,userStatusEntity,5,URLConstant.AI_TIPS67_START,URLConstant.AI_TIPS67_END,URLConstant.AI_TIPS67_MORE,URLConstant.AI_TIPS67_MORE_URL,"白户");
        }else if("大额".equals(answer)){
            String groupId = "25063";
            userStatusEntity.setGroupId(groupId);
            sendProdLinkUtil.sendProductLinkKeyWords(openid,userStatusEntity,5,URLConstant.AI_TIPS68_START,URLConstant.AI_TIPS68_END,URLConstant.AI_TIPS68_MORE,URLConstant.AI_TIPS68_MORE_URL,"大额");
        }else if("红包".equals(answer)){
            hongbaoService.hongbaoProcess(openid,userStatusEntity);
        }else if("领红包".equals(answer)){
            hongbaoService.lingHongbaoProcess(openid);
//        }else if("取消订阅".equals(answer)){
//            v3SubscriptionRecordDao.delete(openid);
//            keFuMsgUtil.say(openid,"已取消新品订阅的通知，感谢你对小易的支持，缺钱了记得来找小易哦～[嘿哈]",userStatusEntity);
        }else {
            //通过用户状态处理进行流程选择
            statusSwitch(openid,answer,userStatusEntity);
        }

        // 处理由机构反馈状态引起的流程
        handleFeedbackStatus(openid, answer, userStatusEntity);
    }


    private void statusSwitch( String openid, String answer ,UserStatusEntity userStatusEntity){

        //整理用户状态：1.获取用户资质；2.过流程判断当前所在步骤
        int status = userStatusEntity.getStatus();
        logger.info("status:" + status);
        switch (status) {
            //提问贷款多少金额,每次都重新获取
            case 0:
                aIWorker.ProcessAnswerMain( "金额", URLConstant.QUESTIONS0,"amount" , openid, answer, userStatusEntity);
                break;

            //提问信用卡
            case 3:
                aIWorker.ProcessAnswerMain( "卡",URLConstant.QUESTIONS3,"creditCard" , openid, answer, userStatusEntity);
                break;
            //提问芝麻分
            case 4:
                aIWorker.ProcessAnswerMain( "芝麻",URLConstant.QUESTIONS4,"zhimaScore" , openid, answer, userStatusEntity);
                break;

            //提问偏好
            case 6:
                aIWorker.ProcessAnswerMain( "偏好",URLConstant.QUESTIONS6_KEY,"userPlan" , openid, answer, userStatusEntity);
                break;

            //提问社保
            case 7:
                aIWorker.ProcessAnswerMain( "社保",URLConstant.QUESTIONS7,"social_insurance" , openid, answer, userStatusEntity);
                break;

            //提问公积金缴纳时间
            case 10:
                aIWorker.ProcessAnswerMain( "公积金",URLConstant.QUESTIONS10,"publicFund" , openid, answer, userStatusEntity);
                break;

            //征信是否逾期
            case 11:
                aIWorker.ProcessAnswerMain( "逾期",URLConstant.QUESTIONS11,"Bank_Credit" , openid, answer, userStatusEntity);
                break;

            //是否有车
            case 12:
                aIWorker.ProcessAnswerMain( "车",URLConstant.QUESTIONS12,"ownCar" , openid, answer, userStatusEntity);
                break;

            //是否有房
            case 13:
                aIWorker.ProcessAnswerMain( "房",URLConstant.QUESTIONS13,"ownHousing" , openid, answer, userStatusEntity);
                break;

            //是否有保单
            case 14:
                aIWorker.ProcessAnswerMain( "保单",URLConstant.QUESTIONS14,"insurance" , openid, answer, userStatusEntity);
                break;

            //是否有淘宝账号
            case 15:
                aIWorker.ProcessAnswerMain( "淘宝",URLConstant.QUESTIONS15,"ownTBAccount" , openid, answer, userStatusEntity);
                break;

            //工作是否大于三千
            case 16:
                aIWorker.ProcessAnswerMain( "收入",URLConstant.QUESTIONS16,"salary" , openid, answer, userStatusEntity);
                break;

            //是否代发
            case 17:
                aIWorker.ProcessAnswerMain( "代发",URLConstant.QUESTIONS17,"Bank_Behalf" , openid, answer, userStatusEntity);
                break;

            //菜单用户选择服务。
            case 34:
                aIWorker.ProcessAnswerChooseService( "选择服务",URLConstant.AI_TIPS27,"QUESTIONS30" , openid, answer, userStatusEntity);
                break;

            //模板消息选择服务。
            case 38:
                aIWorker.ProcessAnswerChooseService( "选择服务",URLConstant.AI_TIPS27,"QUESTIONS30" , openid, answer, userStatusEntity);
                break;

            //选择服务
            case 39:
                aIWorker.ProcessAnswerStatus39( "选择服务",URLConstant.AI_TIPS28,"AI_TIPS28" , openid, answer, userStatusEntity);
                break;

            //金额变更
            case 40:
                aIWorker.ProcessAnswerMain( "金额变更",URLConstant.AI_TIPS42,"amountIsChange" , openid, answer, userStatusEntity);
                break;

            //是否被拒
            case 41:
                aIWorker.ProcessAnswerStatus41( "被拒",URLConstant.AI_TIPS57,"isRefused" , openid, answer, userStatusEntity);
                break;

            //欢迎语选择服务
            case 42:
                aIWorker.ProcessAnswerChooseService(  "选择服务", URLConstant.AI_TIPS27, "QUESTIONS30" , openid, answer, userStatusEntity);
                break;

            //下一步流程
            case 43:
                aIWorker.ProcessAnswerStatus43(  "下一步", "", "nextStep" , openid, answer, userStatusEntity);
                break;

            //需要资质筛选，推荐产品。
            case 996:
                aIWorker.ProcessAnswerStatus996( openid, answer, userStatusEntity);
                break;

            //不需要资质筛选，推荐产品。
            case 997:
                aIWorker.ProcessAnswerStatus997( openid,answer, userStatusEntity);
                break;

            //初始状态
            case 999:
                aIWorker.ProcessAnswerStatus999( openid, answer, userStatusEntity);
                break;

            // 机构反馈状态‘未出额度’的具体原因
            case 1000:
                userStatusEntity.setStatus(999);
                break;

            default:
                aIWorker.ProcessAnswerStatus999( openid, answer, userStatusEntity);
                break;
        }
    }

    private void handleFeedbackStatus(String openid, String answer, UserStatusEntity userStatusEntity) {
        int feedbackStatus = userStatusEntity.getFeedbackStatus();
        logger.info("openId=" + openid + ", feedbackStatus=" + feedbackStatus);
        switch (feedbackStatus) {
            // 未出额
            case 2:
                aIWorker.ProcessFeedbackStatus2("选择服务", URLConstant.AI_FEEDBACK2, "AI_FEEDBACK2",
                    openid, answer, userStatusEntity);
                break;

            // 未验证
            case 3:
                aIWorker.ProcessFeedbackStatus3("选择服务", URLConstant.AI_FEEDBACK3, "AI_FEEDBACK3",
                    openid, answer, userStatusEntity);
                break;

            // 未提交
            case 4:
                aIWorker.ProcessFeedbackStatus4("选择服务", URLConstant.AI_FEEDBACK4, "AI_FEEDBACK4",
                    openid, answer, userStatusEntity);
                break;
            default:
                break;
        }

    }
}
