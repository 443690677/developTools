package com.eqianzhuang.efinancial.common.userAgent;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MobileType {

    private static Log logger = LogFactory.getLog(MobileType.class);
    // 从user-agent中取出手机类型
//    private static Pattern pattern = Pattern.compile(";\\s?[^;\\s]*?(\\s?\\S*?)\\s?(Build)?/");

//    private static Pattern pattern  = Pattern.compile(".+;(.+)Build/(.+\\))");
    private  static Pattern pattern = Pattern.compile(";\\s?(\\S*?\\s?\\S*?)\\s?(Build/)?(.*)/");
    /**
     * 获取手机类型
     * @param agent
     * @return
     */
    public static String [] getMobileType(String agent){
        if(agent.indexOf("iPhone") != -1){
            return new String[]{"iPhone","Apple"};
        }else if (agent.indexOf("iPad") != -1){
            return new String[]{"iPad","Apple"};
        }

        try {
            int start = agent.indexOf("(");
            int second = agent.indexOf("(",start+1);
            int end = agent.indexOf(")");

            if (start < second && second < end){
                end = agent.indexOf(")",end+1);
                return parseMobileType(start,end,agent);
            }else {
                return parseMobileType(start,end,agent);
            }
        }catch(Exception e){
            logger.error(String.format("解析请求头异常：useragent=%s",agent),e);
        }
        return null;
    }

    private static String [] parseMobileType(int start,int end,String agent){
        String s = "";
        if (start != -1 && end != -1) {
            s = agent.substring(start, end + 1);
        }

        String[] splits = s.split("Build/");

        if (splits.length == 2) {
            String[] modes = splits[0].split(";");
            logger.debug("解析手机型号：" + modes[modes.length - 1].trim() + "        " + splits[1].split(";")[0].split("\\)")[0].trim());
            return new String[]{modes[modes.length - 1].trim(), splits[1].split(";")[0].split("\\)")[0].trim()};
        }
        return null;
    }
}
