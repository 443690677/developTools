package com.eqianzhuang.efinancial.ai.service;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface AdditionalDataService {
    public void updateAdditionalData(Map<String,String> fields);

    public void parseRequest(String openid,HttpServletRequest request);
}
