package com.eqianzhuang.efinancial.ai.timerJob;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.SendProdLinkUtil;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.MediaUtil;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.dao.V3CustomerBlackListDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;

@Component
public class SatisfactionSurveyFunction {


    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private KeFuMsgUtil keFuMsgUtil;

    @Autowired
    private AIWorker aIWorker;

    @Autowired
    private UserStatusDao userStatusDao;

    @Autowired
    private SendProdLinkUtil sendProdLinkUtil;

    @Autowired
    public V3CustomerBlackListDao v3CustomerBlackListDao;

    @Autowired
    public WeChatConfig weChatConfig;


    //30分钟毫秒数（测试用）
    private final static long min30_t = 1000 * 31 * 4 ;


    //24小时毫秒数（测试用）
    private final static long hour24_t = 1000 * 31 * 7;


    //47小时毫秒数（测试用）
    private final static long hour47_t = 1000 * 31 * 10;


    public void execute(String openId , boolean isWorkingTime , boolean isTest){

        long currentTime = System.currentTimeMillis();

        UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openId);
        if (userStatusEntity == null) {
            userStatusDao.delUserStatusEntity(openId);
            logger.error("用户不存在:" + openId);
            return;
        }

        //半小时毫秒数
        long min30 = 1000 * 60 * 30;

        //24小时毫秒数
        long hour24 = 1000 * 60 * 60 * 24;

        //47小时毫秒数
        long hour47 = 1000 * 60 * 60 * 47;

        if (isTest){
            min30 = min30_t;
            hour24 = hour24_t;
            hour47 = hour47_t;
        }

        long time = userStatusEntity.getLastSessionDate();

        //超时则移除在线用户
        if ( time + hour47 < currentTime ) {

            if (openId.length() < 6) {
                userStatusDao.delUserStatusEntity(openId);
                return;
            }

            JSONObject msg = URLConstant.AI_TIPS85.getJSONObject(openId.substring(0,6));

            if (CollectionUtils.isEmpty(msg)) {
                msg = URLConstant.AI_TIPS85.getJSONObject("default");
            }

            String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openId), userStatusEntity.getMediaNo());
            String title;
            String amount = userStatusEntity.getQualificationMap().get("amount");
            //查看金额是不存在才会问金额
            if(!ValidUtils.isNumeric(amount) || amount.length() > 8 || Integer.valueOf(amount) < 500 || Integer.valueOf(amount) > 200000){
                title = "5千内";
            }else {
                if ( Integer.valueOf(amount) <= 1000 ) {
                    title = "1千内";
                }else if( Integer.valueOf(amount) <= 5000){
                    title = "5千内";
                }else if( Integer.valueOf(amount) <= 10000){
                    title = "1万内";
                }else if( Integer.valueOf(amount) <= 20000){
                    title = "2万内";
                }else if( Integer.valueOf(amount) <= 50000){
                    title = "5万内";
                }else {
                    title = "5万以上";
                }
            }
            String userPlan = userStatusEntity.getQualificationMap().get("userPlan");

            if ("1".equals(userPlan)) {
                title+= "费用低的产品";
            }else if( "3".equals(userPlan)){
                title+= "额度高的产品";
            }else {
                title+= "批款快的产品";
            }
            String orUrl = "%s/jzpp/index.html?openId=%s&groupId=25098&channel=%s&pageType=P1027&source=article_25098&title=%s";
            String url = String.format(orUrl,weChatConfig.getDomain(openId),openId,chn,title);
            try {
                url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + weChatConfig.getAppId(openId) + "&redirect_uri=" + URLEncoder.encode(url,"utf-8")
                        + "&response_type=code&scope=snsapi_userinfo&state=10004#wechat_redirect";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            JSONObject news = msg.getJSONObject("news");
            JSONArray articles = news.getJSONArray("articles");
            JSONObject article = articles.getJSONObject(0);
            article.put("url",url);
            //创建一个全新的jsonMsg
            keFuMsgUtil.syncJsonMsg(openId,msg,"47小时图文消息",userStatusEntity);

            userStatusDao.delUserStatusEntity(openId);
            return;
        }

        //非工作时间定时任务不执行
        if (!isWorkingTime) {
            return;
        }


        //30分钟定时任务
        if (time + min30 < currentTime && !userStatusEntity.isNotifyOfMin30()) {
            userStatusEntity.setNotifyOfMin30(true);
            if (v3CustomerBlackListDao.isBlackUser(openId)) {
                logger.info("NotifyOfMin30() 黑名单用户 openid:" + openId);
                userStatusDao.setUserStatusEntity(openId, userStatusEntity);
                return;
            }
            logger.info("NotifyOfMin30() openid:" + openId + JSONObject.toJSONString(userStatusEntity));
            userStatusEntity.setMediaNo(1);
            HashMap<String,String> qualification = userStatusEntity.getQualificationMap();
            String amount =qualification.get("amount");
            String chatCount = qualification.get("chatCount");
        	if ("1".equals(chatCount)){
                aIWorker.nextStepService(openId,userStatusEntity);
                //第二次对话才触发的流程
            }else if ("2".equals(chatCount)){
                HashSet<String> productSet = userStatusEntity.getProductSet();
                if (CollectionUtils.isEmpty(productSet)) {
                    if (StringUtils.isEmpty(amount)){
                        keFuMsgUtil.say(openId, String.format(URLConstant.AI_TIPS46,"10000"), "二次对话30分钟提示1", userStatusEntity);
                    }else {
                        keFuMsgUtil.say(openId, String.format(URLConstant.AI_TIPS46,amount), "二次对话30分钟提示1", userStatusEntity);
                    }
                }else{
                    keFuMsgUtil.say(openId, URLConstant.AI_TIPS47, "二次对话30分钟提示2", userStatusEntity);
                }
                aIWorker.nextStepService(openId,userStatusEntity);
            }else {
                provideNotApplied(openId,userStatusEntity);
            }
        }
        //24小时定时任务(原12小时定时任务，变量名暂时不变)
        else if ( time + hour24 < currentTime && !userStatusEntity.isNotifyOf12Hour()) {
            userStatusEntity.setNotifyOf12Hour(true);
            if (v3CustomerBlackListDao.isBlackUser(openId)) {
                logger.info("NotifyOf12Hour() 黑名单用户 openid:" + openId);
                userStatusDao.setUserStatusEntity(openId, userStatusEntity);
                return;
            }
            logger.info("NotifyOf12Hour() openid:" + openId + JSONObject.toJSONString(userStatusEntity));
            userStatusEntity.setMediaNo(6);
            HashMap<String,String> qualification = userStatusEntity.getQualificationMap();
            //第二次对话才触发的流程
            String chatCount = qualification.get("chatCount");
            if ("1".equals(chatCount)){
                aIWorker.nextStepService(openId,userStatusEntity);
            }else if ("2".equals(chatCount)){
                aIWorker.nextStepService(openId,userStatusEntity);
            }else {
                provideNotApplied(openId,userStatusEntity);
            }
        }
        //更新用户状态
        userStatusDao.setUserStatusEntity(openId, userStatusEntity);
    }

    private void provideNotApplied(String openId,UserStatusEntity userStatusEntity)
    {
        userStatusEntity.setGroupId("25037");
        sendProdLinkUtil.sendProductLinkNotQ(openId,userStatusEntity,5,URLConstant.AI_TIPS16);
    }
}
