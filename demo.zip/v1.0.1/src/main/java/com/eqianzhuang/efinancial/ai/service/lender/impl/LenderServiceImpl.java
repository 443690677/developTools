package com.eqianzhuang.efinancial.ai.service.lender.impl;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.ai.service.lender.LenderService;
import com.eqianzhuang.efinancial.common.MediaUtil;
import com.eqianzhuang.efinancial.dao.IWechatListConfigDao;
import com.eqianzhuang.efinancial.dao.UserStatusDao;
import com.eqianzhuang.efinancial.dao.V3CusAptitudeAiDao;
import com.eqianzhuang.efinancial.dao.lender.LenderDimensionDao;
import com.eqianzhuang.efinancial.dao.sysparam.SysParamDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import com.eqianzhuang.efinancial.entity.lender.RecLenderPo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author huangzhigang
 */
@Service
public class LenderServiceImpl implements LenderService {
	
	Logger logger = LoggerFactory.getLogger(LenderServiceImpl.class);
	
	@Autowired
    private IWechatListConfigDao iWechatListConfigDao;
	@Autowired
	private SysParamDao sysParamDao;
	@Autowired
	private KeFuMsgUtil keFuMsgUtil;
	@Autowired
	private LenderDimensionDao lenderDimensionDao;
	@Autowired
	private V3CusAptitudeAiDao cusAptitudeAiDao;
	@Autowired
    private WeChatConfig weChatConfig;

	@Autowired
	private UserStatusDao userStatusDao;
	
	/**
	 * 推荐产品
	 * @param message 消息内容JSON-{"openId":"","text":"","groupId":"","match":1/2,"num":"10"}
	 * @return ResultVO
	 */
	@Override
	public ResponseEntity<Map<String,Object>> recLender(JSONObject message) {
		HashMap<String,Object> map = new HashMap<>();
		int recNum = 0;
		try {
			// 转换
			RecLenderPo recLender = JSONObject.parseObject(message.toString(), RecLenderPo.class);
			// 参数非空判断
			if (StringUtils.isEmpty(recLender.getGroupId())){
				map.put("code", "400");
	            map.put("message","参数不正确");
	            return new ResponseEntity<>(map,HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isEmpty(recLender.getOpenId())){
				map.put("code", "400");
	            map.put("message","参数不正确");
	            return new ResponseEntity<>(map,HttpStatus.BAD_REQUEST);
			}
			String groupId = recLender.getGroupId();
			String openId = recLender.getOpenId();
			// 查询IP消息内容
			String text = sysParamDao.getByNameAndType("ai_rec_lender_msg", "wx_template_rec_lender_msg");
			// 根据groupId查询产品列表
			UserStatusEntity userStatusEntity = new UserStatusEntity();
			userStatusDao.initUserQualification(openId,userStatusEntity);
			List<Map<String, Object>> lenderList = iWechatListConfigDao.getProdInfoByGroupId(groupId,userStatusEntity,openId);
			List<Map<String, Object>> lenders = new ArrayList<>();
			// match 为 1，则需要经过资质筛选，反之不经过
			if (!StringUtils.isEmpty(recLender.getMatch()) && "1".equals(recLender.getMatch())){
				// 查询产品筛选条件
				List<Map<String, Object>> cornList = lenderDimensionDao.selData("8");
				for (Map<String, Object> lenderMap : lenderList){
					String lenderId = String.valueOf(lenderMap.get("id"));
					List<Map<String,Object>> list = cornList.stream().filter(sc -> lenderId.equals(sc.get("lenderId").toString())).collect(Collectors.toList());
					if (list.size() == 0) {
						lenders.add(lenderMap);
					}else {
						for (Map<String,Object> dataMap : list){
							String nd = String.valueOf(dataMap.get("nd"));
							String rd = String.valueOf(dataMap.get("rd"));
							if (!StringUtils.isEmpty(nd) && !StringUtils.isEmpty(rd)) {
								int aptitudeCheck = cusAptitudeAiDao.checkCusAptitudeIsSatisfy(openId, nd);
								int cityCheck = cusAptitudeAiDao.checkCusCitysIsSatisfy(openId, rd);
								if (aptitudeCheck > 0 && cityCheck > 0 ) {
									lenders.add(lenderMap);
								}
							}
							if (!StringUtils.isEmpty(nd) && StringUtils.isEmpty(rd)) {
								int aptitudeCheck = cusAptitudeAiDao.checkCusAptitudeIsSatisfy(openId, nd);
								if (aptitudeCheck > 0 ) {
									lenders.add(lenderMap);
								}
							}
							if (StringUtils.isEmpty(nd) && !StringUtils.isEmpty(rd)) {
								int cityCheck = cusAptitudeAiDao.checkCusCitysIsSatisfy(openId, rd);
								if (cityCheck > 0 ) {
									lenders.add(lenderMap);
								}
							}
						}
					}
				}
				logger.info("资质筛选后的List = " + lenders.size());
			}
			if (!StringUtils.isEmpty(recLender.getNum())){
				recNum = Integer.parseInt(recLender.getNum());
			}
			// 若筛选结果为无，推荐热门5个产品
			if (lenders.size() == 0){
				List<Map<String, Object>> hotRecList = iWechatListConfigDao.getProdInfoByGroupId("3014",userStatusEntity,openId);
				lenders = hotRecList.subList(0, recNum);
			}
			if (lenders.size() > recNum){
				List<Map<String, Object>> dataList = lenders.subList(0, recNum);
				logger.info(" dataList List = " + dataList.size());
				StringBuilder link = new StringBuilder(URLConstant.AI_TIPS16);
				dataList.stream().forEach(prod -> {
					String lenderId = String.valueOf(prod.get("id"));
					String urlId = String.valueOf(prod.get("urlId"));
					String name = String.valueOf(prod.get("name"));
					String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openId), 0);
					link.append(String.format(URLConstant.AI_TO_URL, weChatConfig.getDomain(openId), openId, chn, lenderId, "25048", urlId, name));
				});
				keFuMsgUtil.say(openId, link.toString(), new UserStatusEntity());
			}else {
				logger.info("lenders List = " + lenders.size());
				if (lenders.size() > 0) {
					StringBuilder link = new StringBuilder(URLConstant.AI_TIPS16);
					lenders.stream().forEach(prod -> {
						String lenderId = String.valueOf(prod.get("id"));
						String urlId = String.valueOf(prod.get("urlId"));
						String name = String.valueOf(prod.get("name"));
						String chn = MediaUtil.getMedia(weChatConfig.getMediaName(openId), 0);
						link.append(String.format(URLConstant.AI_TO_URL, weChatConfig.getDomain(openId), openId, chn, lenderId, "25048", urlId, name));
					});
					keFuMsgUtil.say(openId, link.toString(), new UserStatusEntity());
				}
			}
			if (lenders.size() == 0) {
				keFuMsgUtil.say(openId, text, userStatusEntity);
			}
		} catch (Exception e) {
			logger.info("推荐产品失败 Error Msg" + e.getMessage(), e);
		}
		map.put("code", "0");
        map.put("message","发送成功");
        return new ResponseEntity<>(map,HttpStatus.OK);
	}

}
