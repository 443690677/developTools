package com.eqianzhuang.efinancial.common;

import freemarker.template.ObjectWrapper;

public class StringUtils extends org.springframework.util.StringUtils {

    public static String valueOf(Object obj){
        return obj == null ? null : obj.toString();
    }
}
