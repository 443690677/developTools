package com.eqianzhuang.efinancial.ai.service;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.HttpUtil;
import com.eqianzhuang.efinancial.common.StringUtils;
import com.eqianzhuang.efinancial.dao.HongbaoPartyDao;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Coordinate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;

import javax.annotation.PostConstruct;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;


@Service
public class HongbaoServiceImpl implements HongbaoService {

    /**
     * 调测日志记录器。
     */
    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    HttpUtil httpUtil;

    @Autowired
    WeChatConfig weChatConfig;

    @Autowired
    KeFuMsgUtil keFuMsgUtil;


    @Autowired
    HongbaoPartyDao hongbaoPartyDao;

    private static File tmpDir ;

    private static BufferedImage orgImg ;

    @Override
    public void hongbaoProcess(String openid, UserStatusEntity userStatusEntity) {

        if (System.currentTimeMillis() > 1551369600000L) {
            keFuMsgUtil.say(openid,"活动已经结束啦，请多多关注公众号，更多精彩福利活动等着你来参加。[嘿哈]",new UserStatusEntity());
            return;
        }

        if (hongbaoPartyDao.getUserCount() > 7999) {
            keFuMsgUtil.say(openid,"活动参与人数已达到上限，请多多关注公众号，更多精彩福利活动等着你来参加。[嘿哈]",new UserStatusEntity());
            return;
        }
        
        String mediaId = hongbaoPartyDao.getMediaIdByOpenid(openid);
        if (!StringUtils.isEmpty(mediaId)) {
            JSONObject msg  = new JSONObject();
            msg.put("msgtype","image");
            JSONObject image = new JSONObject();
            image.put("media_id",mediaId);
            msg.put("image",image);
            keFuMsgUtil.say(openid,"你已经参加了活动啦，直接将小易给你的二维码转发给朋友邀请关注我们公众号即可。[机智]",new UserStatusEntity());
            keFuMsgUtil.syncJsonMsg(openid,msg,"红包关键字二维码",new UserStatusEntity());
            return;
        }
        imgMake(openid,userStatusEntity);
    }

    @Override
    public void lingHongbaoProcess(String openid) {

        if (System.currentTimeMillis() > 1551369600000L) {
            keFuMsgUtil.say(openid,"活动已经结束啦，请多多关注公众号，更多精彩福利活动等着你来参加。[嘿哈]",new UserStatusEntity());
            return;
        }

        int count= hongbaoPartyDao.getUserByLeader(openid);
        if ( count > 0  ){
            if (count > 99) {
                count = 100;
            }
            keFuMsgUtil.say(openid,"经过你的努力，已成功邀请了 " + count +" 位好友关注了我们的公众号，赢得了 " + count * 5 +" 元现金红包，活动结束后我们会在公众号内联系您，请及时关注，谢谢！[呲牙]",new UserStatusEntity());
        }else {
            keFuMsgUtil.say(openid,"很遗憾，你还没有成功邀请到任何好友关注我们的公众号，继续邀请，加油哦！[拳头][拳头][拳头]",new UserStatusEntity());
        }
    }

    @Value("${properties.path}")
    private String PROPERTIES_PATH;


    @PostConstruct
    private void init(){
        tmpDir = new File(PROPERTIES_PATH + "/../imgTmp");
        try {
            orgImg = ImageIO.read(new File(tmpDir.getCanonicalPath() + File.separator+"LaoDX.png"));
        } catch (IOException e) {
            logger.error("程序异常",e);
        }
    }

    private void imgMake(String openid,UserStatusEntity userStatusEntity){

        String access_token  = weChatConfig.getAccessToken(openid);
        File imgUpdate ;
        try {
            imgUpdate = new File(tmpDir.getCanonicalPath() + File.separator +openid+ ".png");
        } catch (IOException e) {
            logger.error("程序异常，openid="+openid,e);
            return;
        }

        //第一步获取带参数的二维码
        String qrcodeCreate = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token="+access_token;
        JSONObject param = new JSONObject();
        param.put("expire_seconds", 2592000);
        param.put("action_name", "QR_STR_SCENE");
        JSONObject action_info = new JSONObject();
        JSONObject scene = new JSONObject();
        scene.put("scene_str", openid);
        action_info.put("scene", scene);
        param.put("action_info", action_info);
        String result = httpUtil.postForObject(qrcodeCreate, param.toJSONString());

        String ticket ="";
        if (!StringUtils.isEmpty(result)) {
            ticket = JSONObject.parseObject(result).getString("ticket");
        }

        if (StringUtils.isEmpty(ticket)) {
            logger.error("获取二维码失败,openid="+openid);
            return;
        }

        try {
            BufferedImage qrcode = ImageIO.read(new URL("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=" + URLEncoder.encode(ticket,"utf-8")));
            logger.info("开始合成图片,openid="+openid);
            Thumbnails.of(orgImg)
                    .watermark(new Coordinate(437, 183),Thumbnails.of(qrcode).scale(0.38).rotate(13).asBufferedImage() , 1f)
                    .scale(1.00f)
                    .toFile(imgUpdate);
        } catch (IOException e) {
            logger.error("程序异常，openid="+openid,e);
            return;
        }

        //上传临时素材
        logger.info("开始上传临时素材,openid="+openid);
        FileSystemResource resource = new FileSystemResource(imgUpdate);
        String mediaUpload = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token="+access_token+"&type=image";
        LinkedMultiValueMap<String,Object> parameter = new LinkedMultiValueMap<>();
        parameter.add("media",resource);
        String  mediaResult =  httpUtil.postFormForObject(mediaUpload, parameter);

        logger.info("开始发送二维码消息,openid="+openid);
        String media_id = JSONObject.parseObject(mediaResult).getString("media_id");
        if (!StringUtils.isEmpty(media_id)) {

            keFuMsgUtil.say(openid,"亲爱的<#if nickname?? >${nickname}<#else>用户</#if>，感谢您对本次活动的参与和支持，你离百万现金红包奖励只差分享下图给好友了！\uD83D\uDCB0\uD83D\uDCB0\uD83D\uDCB0",userStatusEntity);
            JSONObject msg  = new JSONObject();
            msg.put("msgtype","image");
            JSONObject image = new JSONObject();
            image.put("media_id",media_id);
            msg.put("image",image);
            keFuMsgUtil.syncJsonMsg(openid,msg,"红包二维码消息",userStatusEntity);
            hongbaoPartyDao.insertMedia(openid,media_id);
        }
        imgUpdate.delete();
    }
}
