package com.eqianzhuang.efinancial.common.dbutils;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.WriteModel;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MongoDbUtils {

	@Value("${mongo.dbname}")
	private String databaseName;
	
	@Value("${mongo.uri}")
	private String mongodbURL;

	private static MongoDatabase mongoDatabase = null;
	
	private static final Object lock = new Object();
	

	private MongoDatabase getDatabase(String dbName) {
		return new MongoClient(new MongoClientURI(mongodbURL)).getDatabase(dbName);
	}

	public MongoDatabase mongoInstance() {
		synchronized (lock) {
			if (mongoDatabase == null) {

				mongoDatabase = getDatabase(databaseName);
			}
		}
		return mongoDatabase;
	}

	public void save(MongoCollection<Document> collections, Document doc) {
		collections.insertOne(doc);
	}

	/**
	 * 根据id查询文档
	 * 
	 * @param collections
	 *            集合
	 * @param id
	 *            objectid
	 * @return
	 */
	public Document findById(MongoCollection<Document> collections, String id) {
		try {
			return collections.find(new Document("_id", new ObjectId(id))).first();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}


	/**
	 * 根据id，添加数组元素
	 * @param collections
	 * @param id
	 * @param doc
	 * @return
	 */
	public UpdateResult pushById(MongoCollection<Document> collections,String id,String key,Document doc){
		try{
			return collections.updateOne(Filters.eq("_id", new ObjectId(id)), new Document("$push",new Document(key,doc)));
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * 根据id删除文档
	 * 
	 * @param collections
	 *            集合
	 * @param id
	 * @return
	 */
	public DeleteResult deleteById(MongoCollection<Document> collections, String id) {
		return collections.deleteOne(Filters.eq("_id", id));
	}

	/**
	 * 根据条件查询指定字段
	 * @param collections
	 * @param whereCol
	 * @param findCol
	 * @param args
	 * @return
	 */
	public List<String> in(MongoCollection<Document> collections, String whereCol,String findCol,List<String> args){

		if (args == null || args.size() == 0) {
			return null;
		}
		
		try{
			Document qCond = new Document();
			
			BasicDBList qlist = new BasicDBList();
			
			for(String t : args){
				qlist.add(t);
			}
			
			qCond.put(whereCol, new BasicDBObject("$in", qlist));
			
			MongoCursor<Document> cursor = collections.find(qCond).iterator();
			
			List<String> datas = new ArrayList<String>();
			try {
				while (cursor.hasNext()) {
					Document doc = cursor.next();
					datas.add(doc.getString(findCol));
				}
				return datas;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				cursor.close();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{}
		return null;
	}

	/**
	 * 查找和更新
	 * 
	 * @param collections
	 * @param colName
	 * @param args
	 * @return
	 */
	public Document findOneAndUpdate(MongoCollection<Document> collections, String colName, Object val,Document doc) {
		Document where = new Document();
		where.put(colName,val);
		return collections.findOneAndUpdate(where, doc);
	}


	/**
	 * 查找和更新
	 * 
	 * @param collections
	 * @param colName
	 * @param args
	 * @return
	 */
	public UpdateResult update(MongoCollection<Document> collections, String id,Document doc) {
		return collections.replaceOne(Filters.eq("_id", new ObjectId(id)), doc);
	}
	
	
	public Document findOne(MongoCollection<Document> collections, String colName, Object val){
		Document where = new Document();
		where.put(colName,val);
		FindIterable<Document> findIt = collections.find(where);
		if (findIt == null){
			return null;
		}
		
		return findIt.first();
	}


	/**
	 * 类似关系型数据库中的 or
	 * 
	 * @param collections
	 * @param args
	 * @return
	 */
	public MongoCursor<Document> or(MongoCollection<Document> collections, BasicDBObject... args) {
		if (args == null || args.length == 0) {
			return null;
		}

		try {

			Document qCond = new Document();
			BasicDBList values = new BasicDBList();

			for (BasicDBObject obj : args) {
				values.add(obj);
			}
			qCond.put("$or", values);
			return collections.find(qCond).iterator();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
	public void batch(MongoCollection<Document> collections, List<WriteModel<Document>> models){
		collections.bulkWrite(models).getMatchedCount(); 
		
	}

}
