package com.eqianzhuang.efinancial.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class V3CustomerBlackListDaoImpl implements V3CustomerBlackListDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public boolean isBlackUser(String openid) {
        try {
            String SQL = "SELECT count(*) FROM credit_cpa.v3_customer_black_list WHERE openId = ? AND state = 0 ;";
            return  jdbcTemplate.queryForObject(SQL,Integer.TYPE,openid) > 0;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
