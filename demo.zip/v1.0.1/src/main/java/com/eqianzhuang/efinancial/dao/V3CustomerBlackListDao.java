package com.eqianzhuang.efinancial.dao;

public interface V3CustomerBlackListDao {
    boolean isBlackUser(String openid);
}
