package com.eqianzhuang.efinancial.common;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * 读秒钱包工具类
 */
@Service
public class DMUtil {

    /**url地址*/
    @Value("${md_url}")
    private String url;

    /**渠道*/
    @Value("${md_partner}")
    private String partner;

    /**秘钥*/
    @Value("${md_key}")
    private String key;


    /**
     *
     * 秒读钱包拼接跳转地址
     *
     * @param applyId  申请记录ID
     * @return  String 秒读钱包跳转地址
     */
    public  String joinUrl(String applyId){

        Long timeMillis = System.currentTimeMillis();
        StringBuffer buffer = new StringBuffer()
                .append("openId=").append(applyId)
                .append("&partner=").append(this.partner)
                .append("&timestamp=").append(timeMillis)
                .append("&key=").append(this.key);

        String mdt5 = DigestUtils.md5Hex(buffer.toString()).toUpperCase();

        String url = new StringBuffer()
                .append(this.url).append("?")
                .append("openId=").append(applyId)
                .append("&partner=").append(this.partner)
                .append("&timestamp=").append(timeMillis)
                .append("&sign=").append(mdt5)
                .toString();

        return url;
    }


    /**
     *秒读钱包拼接跳转地址
     * @param applyId 申请记录ID
     * @param partner 渠道
     * @param key 加密秘钥
     * @return String 秒读钱包跳转地址
     */
    public  String joinUrl(String applyId,String url,String partner,String key){

        Long timeMillis = System.currentTimeMillis();
        StringBuffer buffer = new StringBuffer()
                .append("openId=").append(applyId)
                .append("&partner=").append(partner)
                .append("&timestamp=").append(timeMillis)
                .append("&key=").append(key);

        String mdt5 = DigestUtils.md5Hex(buffer.toString()).toUpperCase();

        String newUrl = new StringBuffer()
                .append(url).append("?")
                .append("openId=").append(applyId)
                .append("&partner=").append(partner)
                .append("&timestamp=").append(timeMillis)
                .append("&sign=").append(mdt5)
                .toString();

        return newUrl;
    }
}
