package com.eqianzhuang.efinancial.dao;

import org.bson.Document;

public interface ChatDAO {
	/**
	 * 保存对话记录，格式如下：
	 * {'openid':'asdfweoAde','comments':[{'m':'你好','d':12341234234},{'y':'你好','d':1234435234}]}
	 * @param openid  用户的openid
	 * @param whoSay  Y:公众号     I:用户
	 * @param sayContent     
	 */
	void chat(String openid, String whoSay, String sayContent);

	void insertWebChats(String openid, String whoSay, String sayContent);

	Document getWebChats(String openid);

}
