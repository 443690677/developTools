package com.eqianzhuang.efinancial.dao.lender;

import java.util.List;
import java.util.Map;

/**
 * 产品筛选维度Dao
 * 
 * @author huangzhigang
 */
public interface LenderDimensionDao {

	/**
	 * 查询产品维度List
	 * @param type 维度类型
	 * @return Map<String, String>
	 */
	List<Map<String, Object>> selData(String type);
	
}
