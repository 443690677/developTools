package com.eqianzhuang.efinancial.ai.constant;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;

@Component
public class WebChatConstant {


    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    RedisClient redisClient;

    @Autowired
    WeChatConfig weChatConfig;

    /**
     * 问金额
     */
    public static  JSONObject QUESTIONS0 = new JSONObject();


    /**
     * 问信用卡
     */
    public static  JSONObject QUESTIONS3 = new JSONObject();

    /**
     * 芝麻分
     */
    public static  JSONObject QUESTIONS4 = new JSONObject();

    /**
     * 贷款偏好
     */
    public static  JSONObject QUESTIONS6 = new JSONObject();


    /**
     *问社保
     */
    public static  JSONObject QUESTIONS7 = new JSONObject();


    /**
     * 问公积金
     */
    public static  JSONObject QUESTIONS10 = new JSONObject();

    /**
     * 问逾期
     */
    public static  JSONObject QUESTIONS11 = new JSONObject();

    /**
     * 问车
     */
    public static  JSONObject QUESTIONS12 = new JSONObject();

    /**
     * 问房
     */
    public static  JSONObject QUESTIONS13 = new JSONObject();

    /**
     * 问保单
     */
    public static  JSONObject QUESTIONS14 = new JSONObject();


    /**
     * 问淘宝账号
     */
    public static  JSONObject QUESTIONS15 = new JSONObject();

    /**
     * 问收入
     */
    public static  JSONObject QUESTIONS16 = new JSONObject();

    /**
     * 问代发
     */
    public static  JSONObject QUESTIONS17 = new JSONObject();

    /**
     * 首次推荐额外文本消息。
     */
    public static  String TIP1 = "推荐产品如下，一般申请三个以上产品能批到款的可能性较大。点”立即申请“进行借钱";



    //初始化所以静态常量
    @PostConstruct
    private void init(){
        {
            QUESTIONS0 = new JSONObject();
            QUESTIONS0.put("msgtype", "radio");
            JSONArray radios = new JSONArray();
            radios.add("500-1000");
            radios.add("1001-5000");
            radios.add("5001-1万");
            radios.add("1万-2万");
            radios.add("2万-5万");
            radios.add("5万以上");
            QUESTIONS0.put("radios", radios);
            QUESTIONS0.put("text", "请问要贷多少钱呢？我们的贷款金额可在500元~20万元之间的");
        }
        {
            QUESTIONS3 = new JSONObject();
            QUESTIONS3.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("没有");
            radios.add("6个月以下");
            radios.add("6个月以上(含)");
            QUESTIONS3.put("radios",radios);
            QUESTIONS3.put("text","请问信用卡使用是否超过6个月呢？");
        }
        {
            QUESTIONS4.put("msgtype","number");
            QUESTIONS4.put("min",350);
            QUESTIONS4.put("max",950);
            QUESTIONS4.put("text","ok，芝麻分有多少分啊？");
        }
        {
            QUESTIONS6 = new JSONObject();
            QUESTIONS6.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("费用低");
            radios.add("批款快");
            radios.add("额度高");
            QUESTIONS6.put("radios",radios);
            QUESTIONS6.put("text","请问你喜欢哪一类贷款产品？");
        }
        {
            QUESTIONS7 = new JSONObject();
            QUESTIONS7.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("未缴");
            radios.add("有缴小于6个月");
            radios.add("有缴大于6个月(含)");
            QUESTIONS7.put("radios",radios);
            QUESTIONS7.put("text","好，请问社保缴纳有超过六个月么");
        }
        {
            QUESTIONS10 = new JSONObject();
            QUESTIONS10.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            QUESTIONS10.put("radios",radios);
            QUESTIONS10.put("text","你有公积金么？");
        }

        {
            QUESTIONS11 = new JSONObject();
            QUESTIONS11.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            QUESTIONS11.put("radios",radios);
            QUESTIONS11.put("text","征信有没有逾期呢？");
        }
        {
            QUESTIONS12 = new JSONObject();
            QUESTIONS12.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            QUESTIONS12.put("radios",radios);
            QUESTIONS12.put("text","了解一下有没有车啊？");
        }
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            jsonObject.put("radios",radios);
            jsonObject.put("text","请问有房么？");
            QUESTIONS13 = jsonObject;
        }
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            jsonObject.put("radios",radios);
            jsonObject.put("text","有没有寿险保单呢？");
            QUESTIONS14 = jsonObject;
        }
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("有");
            radios.add("没有");
            jsonObject.put("radios",radios);
            jsonObject.put("text","请问是否使用过淘宝呢？");
            QUESTIONS15 = jsonObject;
        }
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msgtype","number");
            jsonObject.put("min",500);
            jsonObject.put("max",10000000);
            jsonObject.put("text","好的，请问您每月有多少收入？");
            QUESTIONS16 = jsonObject;
        }
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msgtype","radio");
            JSONArray radios = new JSONArray();
            radios.add("是");
            radios.add("否");
            jsonObject.put("radios",radios);
            jsonObject.put("text","请问工资是否银行代发？");
            QUESTIONS17 = jsonObject;
        }

        Class webChatConstant = WebChatConstant.class;
        Field[] fields = webChatConstant.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {

            Field field= fields[i];
            String key = weChatConfig.getWebChatConstantKeyPrefix()+field.getName();
            String fieldsValue = redisClient.getString(key);
            if (!StringUtils.isEmpty(fieldsValue)) {
                if ("com.alibaba.fastjson.JSONObject".equals(field.getGenericType().getTypeName())) {
                    try {
                        field.set(webChatConstant,redisClient.get(key));
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Scheduled(cron="0 */5 * * * ? ")
    public void redisToConstant() {
        init();
    }

}
