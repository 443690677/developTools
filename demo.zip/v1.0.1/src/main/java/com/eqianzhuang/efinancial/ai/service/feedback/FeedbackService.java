package com.eqianzhuang.efinancial.ai.service.feedback;

import com.eqianzhuang.efinancial.common.response.R;

public interface FeedbackService {

    /**
     *
     * 功能描述: 处理机构反馈状态
     *
     * @param: [openId, status]
     * @return: java.lang.Object
     * @auther: junjin Lin
     * @date: 2019/2/26 10:36
     */
    R handleOrgFeedbackStatus(String openId, Integer status);
}
