package com.eqianzhuang.efinancial.ai.timerJob;


import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.dao.LocalDAO;
import com.eqianzhuang.efinancial.entity.LocalEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Component
public class LocalMsgSaveJob{

    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private LocalDAO localDao;


    @Autowired
    private RedisClient redisClient;


    @Scheduled(cron="0 */5 * * * ? ")
    public void execute() {

        Map<String, List<LocalEntity>> maps = new HashMap<>();
        LocalEntity t = new LocalEntity();
        LocalEntity l = redisClient.pop("efinancial_locals", t);

        while ( l != null ) {
            List<LocalEntity> td = maps.get(l.getOpenid());
            if (td == null) {
                List<LocalEntity> list = new ArrayList<>();
                list.add(l);
                maps.put(l.getOpenid(), list);
            } else {
                td.add(l);
            }
            l = redisClient.pop("efinancial_locals", t);
        }
        if (!CollectionUtils.isEmpty(maps)){
            logger.info("新增地理位置:" + maps);
        }

        List<String> existsOpenids = localDao.init().queryOpenids(
                maps.keySet().toArray(new String[maps.size()]));

        if (!CollectionUtils.isEmpty(existsOpenids)){
            logger.info("已经存在的openid:" + existsOpenids);
        }

        if (existsOpenids == null) {
            existsOpenids = new ArrayList<>();
        }

        // 插入地理位置
        List<LocalEntity> inserts = new ArrayList<>();
        List<String> rmKeys = new ArrayList<>();
        for (Iterator<Map.Entry<String, List<LocalEntity>>> it = maps.entrySet()
                .iterator(); it.hasNext();) {

            Map.Entry<String, List<LocalEntity>> entry = it.next();

            // 如果mongo db locals集合中没有则新增
            if (!existsOpenids.contains(entry.getKey())) {
                List<LocalEntity> rpPoint = entry.getValue();
                inserts.add(rpPoint.get(0));
                rpPoint.remove(0);

                if (rpPoint.size() == 0) {
                    rmKeys.add(entry.getKey());
                }
            }
        }

        // 移除仅新增的地理位置
        for (String openid : rmKeys) {
            maps.remove(openid);
        }

        if (inserts.size() != 0) {
            // 先新增地理位置
            localDao.batchInsert(inserts);
        }

        if ( maps.size() != 0) {
            // 然后更新地理位置
            localDao.batchUpdateByOpenid(maps);
        }

        logger.info("结束入库");
    }




}
