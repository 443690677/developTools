package com.eqianzhuang.efinancial.ai.constant;

public enum FeedbackStatusEnum {
    /**
     * 未出额
     */
    OUTSTANDING_AMOUNT(2, "未出额度"),

    /**
     * 未验证
     */
    UNVERIFIED(3, "未验证运营商"),

    /**
     * 未提交
     */
    UNSUBMIT(4, "未提交订单"),;
    private Integer status;
    private String message;

    FeedbackStatusEnum(Integer status, String message) {
        this.status = status;
        this.message = message;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * 验证状态有效性
     *
     * @param status
     * @return
     */
    public static boolean checkStatus(Integer status) {
        for (FeedbackStatusEnum feedbackStatusEnum : FeedbackStatusEnum.values()) {
            if (feedbackStatusEnum.getStatus().equals(status)) {
                return true;
            }
        }

        return false;

    }

    public static String getMessageByStatus(Integer status) {
        for (FeedbackStatusEnum feedbackStatusEnum : FeedbackStatusEnum.values()) {
            if (feedbackStatusEnum.getStatus().equals(status)) {
                return feedbackStatusEnum.getMessage();
            }
        }

        return "";
    }
}
