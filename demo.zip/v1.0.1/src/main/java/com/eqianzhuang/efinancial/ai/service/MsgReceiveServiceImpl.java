package com.eqianzhuang.efinancial.ai.service;

import com.alibaba.fastjson.JSON;
import com.eqianzhuang.efinancial.ai.AIWorker;
import com.eqianzhuang.efinancial.ai.KeFuMsgUtil;
import com.eqianzhuang.efinancial.ai.SendProdLinkUtil;
import com.eqianzhuang.efinancial.ai.WeiXinUserInfoUtil;
import com.eqianzhuang.efinancial.ai.constant.FeedbackStatusEnum;
import com.eqianzhuang.efinancial.ai.constant.URLConstant;
import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.DMUtil;
import com.eqianzhuang.efinancial.common.MediaUtil;
import com.eqianzhuang.efinancial.common.ValidUtils;
import com.eqianzhuang.efinancial.common.dbutils.RedisClient;
import com.eqianzhuang.efinancial.dao.*;
import com.eqianzhuang.efinancial.entity.LocalEntity;
import com.eqianzhuang.efinancial.entity.UserStatusEntity;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 *  微信公众号相关服务
 * @author kongzhimin
 *
 */
@Service
public class MsgReceiveServiceImpl implements MsgReceiveService
{



	protected Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private ChatDAO chatDAO;

	@Autowired
	MsgProcessDAO msgProcessDAO;

	@Autowired
	private QLoanBindWXDAO qLoanBindWXDAO;

	@Autowired
	private ILenderUrlDao lenderUrlDao;

	@Autowired
	private RedisClient redisClient;

	@Autowired
	private IV3CpaApplyRecDao v3CpaApplyRecDao;

	@Autowired
	private UserStatusDao userStatusDao;

	@Autowired
	private AIProcessService aIProcessService;

	@Autowired
	private WeiXinUserInfoUtil weiXinUserInfoUtil;

	@Autowired
	private KeFuMsgUtil keFuMsgUtil;

	@Autowired
	private AIWorker aIWorker;

	@Autowired
	private IWechatListConfigDao iWechatListConfigDao;

	@Autowired
	private V3CusAptitudeAiDao v3CusAptitudeAiDao;

	@Autowired
	private IV3CpaApplyRecDao iV3CpaApplyRecDao;

	@Autowired
	private V3CpaApplyRec v3CpaApplyRec;

	@Autowired
	private SendProdLinkUtil sendProdLinkUtil;

    @Autowired
    private WeChatConfig weChatConfig;

	@Autowired
	private DMUtil dmUtil;

	@Autowired
	private CompJoinConfigDAO compJoinConfigDAO;


    @Autowired
    private HongbaoPartyDao hongbaoPartyDao;


	@Override
	@Async("asyncWorker")
	public void receiveWeiXinMsg(Map<String,String> processRequestXml)
	{
		String msgType = processRequestXml.get("MsgType");
		String event = processRequestXml.get("Event");
		String openId = processRequestXml.get("FromUserName");
		String ghId = processRequestXml.get("ToUserName");
		if ( openId == null || openId.length() != 28){
			return;
		}

		if(!MediaUtil.EVENT_TYPE_LOCATION.equals(event))
		{
			logger.info("微信消息推送 " + JSON.toJSONString(processRequestXml));

			// 记录埋点
			String eventKey = processRequestXml.get("EventKey");
			if(!StringUtils.isEmpty(eventKey))
			{

				if(MediaUtil.EVENT_TYPE_CLICK.equals(event))
				{

					if(eventKey.equals("key_get_message1"))
					{
						msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId),10000,openId);
					}

                    if (eventKey.equals("key_get_message2")) {
                        msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId), 20000, openId);
                    }

                    if (eventKey.equals("key_get_message3")) {
                        msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId), 30000, openId);
                    }

				}

				String state = "state=";
				int strStartIndex = eventKey.indexOf(state);
				int strEndIndex = eventKey.indexOf("#wechat_redirect");

				if(strStartIndex >= 0 && strEndIndex >= 0)
				{
					/* 开始截取 */
					int menuId = Integer.valueOf(eventKey.substring(strStartIndex,strEndIndex).substring(state.length()));
					msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId),menuId,openId);
				}

			}

		}

		if(MediaUtil.REQ_MESSAGE_TYPE_TEXT.equals(msgType))
		{
			UserStatusEntity userStatusEntity = userStatusDao.updateLastDate(openId);
			String content = processRequestXml.get("Content");
			// 记录聊天信息到MYSQl,mongodb
			saveMsgToDataBase(openId,ghId,content,userStatusEntity);

			// 对话流程
			aIProcessService.wxChatProcess(openId,content,userStatusEntity);

		} else if(MediaUtil.REQ_MESSAGE_TYPE_EVENT.equals(msgType))
		{
			if(MediaUtil.EVENT_TYPE_UNSUBSCRIBE.equals(event))
			{
				userStatusDao.delUserStatusEntity(openId);
				saveMsgToDataBase(openId,ghId,"取消关注",null);
				// 取消关注
				wxchatSubscribe(openId,1);

			} else if(MediaUtil.EVENT_TYPE_LOCATION.equals(event))
			{
				addLocalMsg(processRequestXml);
			} else if(MediaUtil.EVENT_TYPE_SUBSCRIBE.equals(event))
			{
				UserStatusEntity userStatusEntity = userStatusDao.updateLastDate(openId);
				// 记录聊天信息到MYSQl,mongodb
				saveMsgToDataBase(openId,ghId,"关注",userStatusEntity);

				HashMap<String,String> qualification = userStatusEntity.getQualificationMap();

				int subscribeCount = 0;
				if (qualification.get("subscribeCount") != null){
					subscribeCount = Integer.valueOf(qualification.get("subscribeCount")) + 1;
				}else{
					subscribeCount = 1;
				}

				qualification.put("subscribeCount",String.valueOf(subscribeCount));
				qualification.put("chatCount","1");
				userStatusDao.setUserStatusEntity(openId,userStatusEntity);
				if(subscribeCount == 1)
				{
                    userStatusEntity.setStatus(42);
					keFuMsgUtil.sendJsonMsg(openId,URLConstant.WELCOME_MSG,"欢迎语",userStatusEntity);
                    userStatusDao.setUserStatusEntity(openId,userStatusEntity);

				} else if(subscribeCount == 2)
				{
					long time = System.currentTimeMillis() - 30 * 24 * 60 * 60 * 1000L;
					String amount = qualification.get("amount");
					if(!ValidUtils.isNumeric(amount) || CollectionUtils.isEmpty(v3CpaApplyRec.selectProdApplyRec(openId,new Date(time))))
					{
					    keFuMsgUtil.sendJsonMsg(openId,URLConstant.WELCOME_MSG,"欢迎语",userStatusEntity);
                        userStatusEntity.setStatus(42);
                        userStatusDao.setUserStatusEntity(openId,userStatusEntity);

					} else
					{
						keFuMsgUtil.say(openId,String.format(URLConstant.AI_TIPS42,amount),"二次_欢迎语",userStatusEntity);
						userStatusEntity.setStatus(40);
						userStatusDao.setUserStatusEntity(openId,userStatusEntity);
					}
				} else
				{
					keFuMsgUtil.say(openId,URLConstant.AI_TIPS43,"多次_欢迎语",userStatusEntity);
				}

				String ticket = processRequestXml.get("Ticket");
				int media = 0;
				// 同步关注用户到微信绑定表
				if(!StringUtils.isEmpty(ticket))
				{
					String eventKey = processRequestXml.get("EventKey");
					if(!StringUtils.isEmpty(eventKey) && eventKey.contains("_"))
					{
                        if (eventKey.length() == 36) {
                            hongbaoPartyDao.insertUser(openId,eventKey.substring(8,36));
                        }else {
                            String[] array = eventKey.split("_");
                            if(array.length == 2)
                            {
                                if(ValidUtils.isNumeric(array[1]))
                                {
                                    media = Integer.parseInt(array[1]);
                                }
                            }
                        }
					}
				}
				// 默认渠道为：0
				qLoadUserBind(openId,media);
				// 关注
				wxchatSubscribe(openId,0);
			} else if(MediaUtil.EVENT_TYPE_CLICK.equals(event))
			{
			    advisorMenu(openId);
			} else if(MediaUtil.EVENT_TYPE_VIEW.equals(event))
			{
				UserStatusEntity userStatusEntity = userStatusDao.updateLastDate(openId);
				userStatusEntity.setClickMenu(true);
				userStatusDao.setUserStatusEntity(openId,userStatusEntity);

			}
			// 语音消息
		} else if(MediaUtil.REQ_MESSAGE_TYPE_VOICE.equals(msgType))
		{
			UserStatusEntity userStatusEntity = userStatusDao.updateLastDate(openId);
			// 语音识别结果
			String Recognition = processRequestXml.get("Recognition");
			if(StringUtils.isEmpty(Recognition))
			{
				String msg = "抱歉，听不太清。麻烦发文字可以答复你^_^";
				keFuMsgUtil.say(openId,msg,new UserStatusEntity());
			} else
			{
				// 记录聊天信息到MYSQl,mongodb
				saveMsgToDataBase(openId,ghId,Recognition,userStatusEntity);
				// 对话流程
				aIProcessService.wxChatProcess(openId,Recognition,userStatusEntity);
			}
		}
		// 视频、短视频
		else if(MediaUtil.RESP_MESSAGE_TYPE_VIDEO.equals(msgType) || MediaUtil.RESP_MESSAGE_TYPE_SHORTVIDEO.equals(msgType))
		{
			userStatusDao.updateLastDate(openId);
			String msg = "不好意思，目前不方便看视频，麻烦发文字可以答复你^_^";
			keFuMsgUtil.say(openId,msg,new UserStatusEntity());
			// 未识别消息类型
		} else
		{
			userStatusDao.updateLastDate(openId);
			String msg = "不好意思，目前不方便看视频，麻烦发文字可以答复你^_^";
			keFuMsgUtil.say(openId,msg,new UserStatusEntity());
		}

	}

	/**
	 * 线下产品申请
	 * @param openid openid
	 * @param lenderId 产品ids
	 */
	@Override
	public boolean applyOffline(String openid,String name,String mobile,String lenderId,String cityId)
	{

		UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openid);
		boolean isOnLine = true;
		if(userStatusEntity == null)
		{
			userStatusEntity = new UserStatusEntity();
			userStatusDao.initUserQualification(openid,userStatusEntity);
			isOnLine = false;
		}

		HashMap<String,String> qualificationMap = userStatusEntity.getQualificationMap();

		if(StringUtils.isEmpty(qualificationMap.get("name")))
		{
			weiXinUserInfoUtil.insertOrUpdateAptitudeAI(openid,"name",name);
			qualificationMap.put("name",name);
		}

		if(StringUtils.isEmpty(qualificationMap.get("mobile")))
		{
			weiXinUserInfoUtil.insertOrUpdateAptitudeAI(openid,"mobile",mobile);
			qualificationMap.put("mobile",mobile);
		}

		Map<String,Object> ApplyRec;
		if(isOnLine)
		{
			if(userStatusEntity.isInsertUserQualification())
			{
				weiXinUserInfoUtil.insertUserQualification(openid,qualificationMap);
				userStatusEntity.setInsertUserQualification(false);
			}
			userStatusDao.setUserStatusEntity(openid,userStatusEntity);
			ApplyRec = iV3CpaApplyRecDao.selectUserQualification(mobile);

		} else
		{
			ApplyRec = iV3CpaApplyRecDao.selectUserQualification(mobile);
			if(CollectionUtils.isEmpty(ApplyRec))
			{
				weiXinUserInfoUtil.insertUserQualification(openid,qualificationMap);
				ApplyRec = iV3CpaApplyRecDao.selectUserQualification(mobile);
			}
		}

		if(CollectionUtils.isEmpty(ApplyRec))
		{
			logger.error("没有获客，后台不出库：" + openid);
			return false;
		}

		String applyId = String.valueOf(ApplyRec.get("applyId"));
		String mobile_des = String.valueOf(ApplyRec.get("mobile_des"));

		return aIWorker.outLibOffline(lenderId,qualificationMap,cityId,applyId,mobile_des,openid);
	}

    /**
     * 线上产品申请
     * @param openid
     * @param channel
     * @return
     */
    @Override
    public HashMap<String,Object> applyOnline(String openid, String channel, String lenderId, String groupId, String urlId, boolean isWebChat)
    {

        String url = "";
        HashMap<String,Object> dataMap = new HashMap<>();

        if(ValidUtils.isNumeric(urlId))
        {
            url = lenderUrlDao.get(Integer.valueOf(urlId));
        }

        long id = v3CpaApplyRecDao.insertApplyRec(2,openid,lenderId,channel,channel,groupId,0,0,url);

        if(id > 0)
        {
            if(StringUtils.isEmpty(url))
            {
                String name = "";
                String mobile = "";
                // 从个人中心同步资质到session
                Map qualification = v3CusAptitudeAiDao.getCusAptitudeAi(openid);
                if(!CollectionUtils.isEmpty(qualification))
                {
                    String full_name = String.valueOf(qualification.get("full_name"));
                    if(ValidUtils.validName(full_name) && !CollectionUtils.isEmpty(v3CusAptitudeAiDao.selectUpdateOr(openid,"full_name")))
                    {
                        name = full_name;
                    }
                    String mobile_ai = String.valueOf(qualification.get("mobile"));
                    if(ValidUtils.isNumeric(mobile_ai) && mobile_ai.length() == 11 && !CollectionUtils.isEmpty(v3CusAptitudeAiDao.selectUpdateOr(openid,"mobile")))
                    {
                        mobile = mobile_ai;
                    }
                }

                try
                {
                    url = String.format(URLConstant.AI_TO_URL_OFFLINE,weChatConfig.getDomain(openid),openid,lenderId,URLEncoder.encode(URLEncoder.encode(name,"utf-8"),"utf-8"),mobile,channel);
					if (!isWebChat) {
						url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + weChatConfig.getAppId(openid) + "&redirect_uri=" + URLEncoder.encode(url,"utf-8")
								+ "&response_type=code&scope=snsapi_userinfo&state=10004#wechat_redirect";
					}
                } catch(UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
                aIWorker.addOps(openid,10006,"线下产品申请");
            }

			//机构对接处理  优化后的代码还未测试,所以注释（张秋平）
            String joinConfig = compJoinConfigDAO.getCompLenderJoinConfig(Long.valueOf(lenderId));
            if(null != joinConfig){

            	//51人品贷-新增用户分组功能
            	if("1071".equals(lenderId) || "107101".equals(lenderId) ){
                    String wxType = weChatConfig.getWXType(openid);
            		//查询当前用户、当前公众号上、当前产品，今天是否有分组记录，每天只能加一条
            		boolean check = v3CpaApplyRecDao.usersGroupBool(Integer.valueOf(lenderId),openid);
            		if (check){
            			//查询当前公众号上、当前产品，今天最新记录的用户分组类型
            			String groupNumber = v3CpaApplyRecDao.usersGroupRecordNew(Integer.valueOf(lenderId),wxType);
            			String groupNumberNew = "A";
            			if("A".equals(groupNumber)){
            				groupNumberNew="B";
            			}else{
            				groupNumberNew="A";
            			}
            			//新增分组记录
            			v3CpaApplyRecDao.insertUsersGroupRecord(Integer.valueOf(lenderId),wxType,openid,groupNumberNew);
            		}
            	}

                //读秒钱包
                if ("1102".equals(lenderId) || "110201".equals(lenderId) || "110202".equals(lenderId) ) {
                    url =  dmUtil.joinUrl(""+id);
                }else{
                    url = String.format(joinConfig,id);
                }
            }

            // 包有钱
//            if(Integer.valueOf(lenderId).equals(117601))
//            {
//                url += "&applyId=" + id;
//            }
//            // 万达普惠跳转链接
//            if(Integer.valueOf(lenderId) == 1139 || Integer.valueOf(lenderId) == 113901)
//            {
//                url = url + "&userid=" + id;
//            }
//
//			//U钱包  未对接好，先注释
//			if(1263 == Integer.valueOf(lenderId).intValue() || 125507 == Integer.valueOf(lenderId).intValue())
//			{
//				url = url + id;
//			}
//
//			//省呗 未对接好，先注释
//			if(1103 == Integer.valueOf(lenderId).intValue() || 110301 == Integer.valueOf(lenderId).intValue())
//			{
//				url = url + id;
//			}
//
//			//优款
//			if(1129 == Integer.valueOf(lenderId).intValue() || 112901 == Integer.valueOf(lenderId).intValue())
//			{
//				url = url + id;
//			}
//
//			// 房司令
//			if(125834 == Integer.valueOf(lenderId).intValue() || 1216 == Integer.valueOf(lenderId).intValue())
//			{
//				url = url + id;
//			}
//
//			//读秒钱包
//			if ("1102".equals(lenderId) || "110201".equals(lenderId) || "110202".equals(lenderId) ) {
//				url =  dmUtil.joinUrl(""+id);
//			}
//
//			// 快闪卡贷链接处理
//			if ("1149".equals(lenderId) || "114901".equals(lenderId)){
//				url = url + "&applyId2=" + id;
//			}
//
//            // 购ta
//            if("125562".equals(lenderId))
//            {
//                url = "https://www.gouta.cn/api/v1/login/getParameter?applyId=" + id + "&mobile=";
//            }
//
//            // 杏仁派
//            if("116301".equals(lenderId) || "116302".equals(lenderId))
//            {
//                if(url.contains("?"))
//                {
//                    String[] urls = url.split("\\?");
//                    url = urls[0] + "?flag=xr_yqz&applyId=" + id + "&" + urls[1];
//                }
//            }

            dataMap.put("resultCode",0);
            dataMap.put("resultMsg","申请成功!");
            dataMap.put("url",url);
        } else
        {
            dataMap.put("resultCode","11111");
            dataMap.put("resultMsg","申请失败!");
            dataMap.put("url","");
        }
        return dataMap;

	}

	/**
	 * 保存对话记录，格式如下：
	 * {'openid':'asdfweoAde','comments':[{'m':'你好','d':12341234234},{'y':'你好','d':1234435234}]}
	 * @param openId  用户的openid
	 * @param text
	 */
	private void saveMsgToDataBase(String openId,String ghId,String text,UserStatusEntity userStatusEntity)
	{
		try
		{

            // 添加对话到mongodb @param whoSay Y:公众号 I:用户
            chatDAO.chat(openId, "I", text);
            String content = text != null ? text.replaceAll("[^\\u0000-\\uFFFF]", "") : "";

            // 如果有机构反馈状态，则打上对应的标签 修改: 林俊进
            String feedbackLabel = null;
            if (userStatusEntity != null) {
                feedbackLabel = FeedbackStatusEnum.getMessageByStatus(userStatusEntity.getFeedbackStatus());
            }

            msgProcessDAO.insertMsg(openId, ghId, null, 3, content, "",
                !StringUtils.isEmpty(feedbackLabel) ? feedbackLabel : keFuMsgUtil.getLabel(userStatusEntity));
            if (!"关注".equals(text) && !"取消关注".equals(text)) {
                // 记录埋点
                msgProcessDAO.addWeChatMenuOr(weChatConfig.getWXType(openId), 9002, openId);
            }

		} catch(Exception e)
		{
			logger.error("记录AI对话失败:",e);
		}
	}

	/**
	* @return  点小易顾问菜单回复：您好,请问有什么可以帮助您吗？
	*/
	@Override
	public void advisorMenu(String openid)
	{

		UserStatusEntity userStatusEntity = userStatusDao.getUserStatusEntity(openid);

		if(userStatusEntity == null)
		{
			userStatusEntity = new UserStatusEntity();
			userStatusEntity.setClickMenu(true);
			userStatusEntity.setStatus(0);
			userStatusDao.initUserQualification(openid,userStatusEntity);
			userStatusEntity.setLastSessionDate(System.currentTimeMillis());
			userStatusDao.setUserStatusEntity(openid,userStatusEntity);
			keFuMsgUtil.say(openid,URLConstant.AI_TIPS25,userStatusEntity);
			return;
		}

		userStatusEntity.setClickMenu(true);
		if(userStatusEntity.getLastSessionDate() + 200 > System.currentTimeMillis())
		{
			userStatusEntity.setLastSessionDate(System.currentTimeMillis());
			userStatusDao.setUserStatusEntity(openid,userStatusEntity);
			return;
		}

		HashMap<String,String> qualification = userStatusEntity.getQualificationMap();

		// 第1,2次对话才触发的流程
		String chatCount = qualification.get("chatCount");
		if("1".equals(chatCount) || "2".equals(chatCount))
		{
			String amount = qualification.get("amount");
			if(StringUtils.isEmpty(amount))
			{
				if(userStatusEntity.getLastSessionDate() + 4000 < System.currentTimeMillis())
				{
					userStatusEntity.setStatus(34);
					// 请问你需要哪种服务
					keFuMsgUtil.sendJsonMsg(openid,URLConstant.QUESTIONS30_MENU,userStatusEntity);
				} else
				{
					if(userStatusEntity.getStatus() != 34)
					{
						userStatusEntity.setStatus(34);
						// 请问你需要哪种服务
						keFuMsgUtil.sendJsonMsg(openid,URLConstant.QUESTIONS30_MENU,userStatusEntity);
					} else
					{
						keFuMsgUtil.say(openid,URLConstant.AI_TIPS13,userStatusEntity);
					}
				}
			} else
			{
				String creditCard = qualification.get("creditCard");
				String zhimaScore = qualification.get("zhimaScore");
				if(StringUtils.isEmpty(creditCard))
				{
                    userStatusEntity.setStatus(3);
					keFuMsgUtil.say(openid,URLConstant.AI_TIPS14,userStatusEntity);
				} else if(!ValidUtils.isNumeric(zhimaScore))
				{
                    userStatusEntity.setStatus(4);
					keFuMsgUtil.say(openid,URLConstant.AI_TIPS15,userStatusEntity);

				} else
				{
					if(!"True".equals(creditCard) && Integer.valueOf(zhimaScore) < 600)
					{

						userStatusEntity.setGroupId("13008");
						userStatusEntity.setMediaNo(4);

						sendProdLinkUtil.sendProductLinkNotQ(openid,userStatusEntity,5,URLConstant.AI_TIPS16);

					} else
					{

						HashSet<String> productSet = userStatusEntity.getProductSet();
						// 有芝麻分或信用卡（还没有推荐产品）
						if(CollectionUtils.isEmpty(productSet))
						{
							userStatusEntity.setMediaNo(4);
							userStatusEntity.setGroupId("13030");
						}
						sendProdLinkUtil.sendProductLinkNotQ(openid,userStatusEntity,5,URLConstant.AI_TIPS17);
					}
				}
			}
		} else
		{
			userStatusEntity.setMediaNo(4);
			userStatusEntity.setGroupId("25036");
			sendProdLinkUtil.sendProductLinkNotQ(openid,userStatusEntity,5,URLConstant.AI_TIPS16);
		}

		userStatusEntity.setLastSessionDate(System.currentTimeMillis());
		userStatusDao.setUserStatusEntity(openid,userStatusEntity);
	}

	private void addLocalMsg(Map<String,String> weiXinMessage)
	{
		LocalEntity l = new LocalEntity();
		l.setY(Double.valueOf(weiXinMessage.get("Latitude")));
		l.setS(Double.valueOf(weiXinMessage.get("Precision")));
		l.setX(Double.valueOf(weiXinMessage.get("Longitude")));
		l.setT(System.currentTimeMillis());
		l.setOpenid(weiXinMessage.get("FromUserName"));
		redisClient.push("efinancial_locals",l);
	}

	private void qLoadUserBind(String openId,int media)
	{
		synchronized(this)
		{
			Map qLoanBindWX = qLoanBindWXDAO.getByOpenId(openId);
			if( qLoanBindWX == null)
			{
				qLoanBindWXDAO.insertQLoanBindWX(openId,media);
			}
		}
	}

	// 关注或取消关注
	public void wxchatSubscribe(String openid,Integer state)
	{
		qLoanBindWXDAO.updateQloanBindWX(openid,weChatConfig.getWXType(openid),state);
	}
}
