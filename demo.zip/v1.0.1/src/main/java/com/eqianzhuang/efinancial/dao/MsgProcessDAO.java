package com.eqianzhuang.efinancial.dao;

public interface MsgProcessDAO {

    void insertMsg(String othId, String openId, String nickName, int cType, String content, String remark, String label);

    void addWeChatMenuOr(String wxType, int menuId, String openId);
}
