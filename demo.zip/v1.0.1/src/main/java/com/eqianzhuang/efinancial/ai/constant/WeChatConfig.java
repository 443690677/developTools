package com.eqianzhuang.efinancial.ai.constant;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.common.HttpUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;


/**
 * 微信缓存
 *
 */
@Component
public class WeChatConfig {


    @Value("${WX_CENTER}")
    private String WX_CENTER;

    @Value("${AI_HOST}")
    private String AI_HOST;

    @Value("${CONSTANT_VERSION}")
    private String CONSTANT_VERSION;

    protected Log logger = LogFactory.getLog(this.getClass());

    private static HashMap<String,HashMap<String,String>> configs = new HashMap<>();

    @Autowired
    HttpUtil httpUtil;

    public String getWXType(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "8";
            }
        }
        return config.get("wxtype");
    }

    public String getGhid(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "gh_86eeab48a43f";
            }
        }
        return config.get("wechatid");
    }

    public String getAppId(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "wx0d7f66283b172c62";
            }
        }
        return config.get("appid");
    }

    public String getMediaId(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "10367";
            }
        }
        return config.get("mediaId");
    }

    public String getMediaName(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "AI_AUTO_XYR";
            }
        }

        String name = Thread.currentThread().getName();
        if (name.startsWith("webChat")){
            return config.get("mediaName")+"_WEB";
        }
        return config.get("mediaName");
    }

    public String getDomain(String openid) {
        String openidPrefix = openid.substring(0,6);
        HashMap<String,String> config = configs.get(openidPrefix);
        if (CollectionUtils.isEmpty(config)){
            setConfig(openidPrefix);
            config = configs.get(openidPrefix);
            if (CollectionUtils.isEmpty(config)) {
                return "http://xyr.591jq.cn";
            }
        }
        return "http://" + config.get("domain2");
    }

    public String getAIHost() {
        return AI_HOST;
    }

    public String getConstantKeyPrefix() {
        if ("v0".equals(CONSTANT_VERSION)){
            return "efinancial_";
        }
        return "efinancial_" + CONSTANT_VERSION + "_";
    }

    public String getDispatchUserKey() {
        return "dispatch_user_key_" + CONSTANT_VERSION ;
    }

    public String getWebChatConstantKeyPrefix() {
        if ("v0".equals(CONSTANT_VERSION)){
            return "webChatCons_";
        }
        return "webChatCons_" + CONSTANT_VERSION + "_";
    }

    public String getAccessToken(String openid) {
        String openidPrefix = openid.substring(0,6);
        JSONObject result = JSONObject.parseObject(httpUtil.getForObject(WX_CENTER+"/wechat/wxcenter/wechat/get?openId=" + openidPrefix));
        JSONObject data = result.getJSONObject("datas");
        if (!CollectionUtils.isEmpty(data)){
            return data.getString("token");
        }
        return null;
    }


    private void setConfig(String openidPrefix) {
        JSONObject result = JSONObject.parseObject(httpUtil.getForObject(WX_CENTER+"/wechat/wxcenter/wechat/get?openId=" + openidPrefix));
        JSONObject data = result.getJSONObject("datas");
        if (!CollectionUtils.isEmpty(data)){
            HashMap<String,String> config = new HashMap<>();
            config.put("wechatid",data.getString("wechatId"));
            config.put("appid",data.getString("appId"));
            config.put("wxtype",data.getString("wxType"));
            config.put("domain2",data.getString("domain2"));
            config.put("mediaName",data.getString("mediaName"));
            config.put("mediaId",data.getString("mediaId"));
            configs.put(openidPrefix,config);
        }
    }

}

