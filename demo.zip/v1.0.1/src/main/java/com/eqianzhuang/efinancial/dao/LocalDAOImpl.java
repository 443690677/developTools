package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.common.dbutils.MongoDbUtils;
import com.eqianzhuang.efinancial.entity.LocalEntity;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.InsertOneModel;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.WriteModel;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.Map.Entry;

@Repository
public class LocalDAOImpl  implements LocalDAO {

	
	private static final String COLLECTIONSNAME = "locals";

	@Autowired
	private MongoDbUtils mongoDbUtils;
	

	private MongoCollection<Document> collection ;
	
	@Override
	public LocalDAO init(){
		collection = mongoDbUtils.mongoInstance().getCollection(COLLECTIONSNAME);
		return this;
	}
	
	/**
	 * 根据openid查询返回存在的openid
	 * @param openids openid列表
	 * @return  存在的openid列表
	 */
	public List<String> queryOpenids(String ...openids){
		return mongoDbUtils.in(collection, "openid", "openid", Arrays.asList(openids));
	}


	/**
	 * 批量更新
	 * @param params
	 */
	public void batchUpdateByOpenid(Map<String,List<LocalEntity>> params){
		if (params == null){
			return;
		}
		
		List<WriteModel<Document>> requests = new ArrayList<WriteModel<Document>>(); 
		Iterator<Entry<String, List<LocalEntity>>> it = params.entrySet().iterator();
		while(it.hasNext()){
			Entry<String,List<LocalEntity>> entry = it.next();
			List<LocalEntity> localDtos = entry.getValue();
	        //更新条件  
	        Document queryDocument = new Document("openid",entry.getKey());
	        
	        for (LocalEntity ld : localDtos){
		        Document doc = new Document();
		        doc.put("x", ld.getX());
		        doc.put("y", ld.getY());
		        doc.put("t", ld.getT());
		        doc.put("s", ld.getS());
		        //更新内容
		        Document updateDocument = new Document("$push",new Document("locals",doc));  
		        
		        //构造更新单个文档的操作模型  
		        UpdateOneModel<Document> uom = new UpdateOneModel<Document>(queryDocument,updateDocument,new UpdateOptions().upsert(false));
		        
		        requests.add(uom);
	        }
			
		}
		
		mongoDbUtils.batch(collection, requests);
	}
	
	/**
	 * 批量插入
	 * @param locals 位置信息
	 */
	public void batchInsert(List<LocalEntity> locals){
		if (locals == null){
			return;
		}
		
		List<WriteModel<Document>> insertDatas = new ArrayList<WriteModel<Document>>();
		
		for(LocalEntity local : locals){
			Document d = new Document();
			d.put("openid", local.getOpenid());
			
			Document l = new Document();
	        l.put("x", local.getX());
	        l.put("y", local.getY());
	        l.put("t", local.getT());
	        l.put("s", local.getS());
	        List<Document> arr = new ArrayList<Document>();
	        arr.add(l);
			d.put("locals",arr);

	        //构造插入单个文档的操作模型  
	        InsertOneModel<Document>  iom = new InsertOneModel<Document>(d);  
	        insertDatas.add(iom);
		}

		mongoDbUtils.batch(collection, insertDatas);
	}

}
