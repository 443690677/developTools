package com.eqianzhuang.efinancial.common;
import org.springframework.util.StringUtils;

public class ValidUtils{


    //只做非空校验
    public static boolean validName(String name){
        return !StringUtils.isEmpty(name) && !"null".equals(name);
    }
    //只做是否为纯数字
    public static boolean isNumeric(String str) {
        if (StringUtils.isEmpty(str)){
            return false;
        }

        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
