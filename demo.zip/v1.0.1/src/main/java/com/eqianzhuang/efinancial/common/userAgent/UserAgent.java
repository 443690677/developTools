package com.eqianzhuang.efinancial.common.userAgent;

public class UserAgent {

    private boolean mobile; // false
    private String browser; // Firefox
    private String platform; // Windows
    private String os; // Windows 7
    private String engine;
    private String version; // 5
    private String engineVersion;
    private String mobileType;
    private String brand;

    public boolean isMobile()
    {
        return mobile;
    }
    public void setMobile(boolean mobile)
    {
        this.mobile = mobile;
    }
    public String getBrowser()
    {
        return browser;
    }
    public void setBrowser(String browser)
    {
        this.browser = browser;
    }
    public String getPlatform()
    {
        return platform;
    }
    public void setPlatform(String platform)
    {
        this.platform = platform;
    }
    public String getOs()
    {
        return os;
    }
    public void setOs(String os)
    {
        this.os = os;
    }
    public String getEngine()
    {
        return engine;
    }
    public void setEngine(String engine)
    {
        this.engine = engine;
    }
    public String getVersion()
    {
        return version;
    }
    public void setVersion(String version)
    {
        this.version = version;
    }
    public String getEngineVersion()
    {
        return engineVersion;
    }
    public void setEngineVersion(String engineVersion)
    {
        this.engineVersion = engineVersion;
    }

    public String getMobileType() {
        return mobileType;
    }

    public void setMobileType(String mobileType) {
        this.mobileType = mobileType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public String toString() {
        return "UserAgent{" +
                "mobile=" + mobile +
                ", browser='" + browser + '\'' +
                ", platform='" + platform + '\'' +
                ", os='" + os + '\'' +
                ", engine='" + engine + '\'' +
                ", version='" + version + '\'' +
                ", engineVersion='" + engineVersion + '\'' +
                ", mobileType='" + mobileType + '\'' +
                ", brand='" + brand + '\'' +
                '}';
    }
}