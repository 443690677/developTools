package com.eqianzhuang.efinancial.common.configbean;


import com.eqianzhuang.efinancial.common.HttpUtil;
import com.zaxxer.hikari.HikariDataSource;
import freemarker.template.TemplateExceptionHandler;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.client.RestTemplate;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class ExecutorConfig {

    @Bean
    public Executor asyncWorker() {
            /** Set the ThreadPoolExecutor's core pool size. */
            int corePoolSize = 40;
            /** Set the ThreadPoolExecutor's maximum pool size. */
            int maxPoolSize = 500;
            /** Set the capacity for the ThreadPoolExecutor's BlockingQueue. */
            int queueCapacity = 30;
            ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
            executor.setCorePoolSize(corePoolSize);
            executor.setMaxPoolSize(maxPoolSize);
            executor.setQueueCapacity(queueCapacity);
            executor.setThreadNamePrefix("Async-Worker-");
            // rejection-policy：当pool已经达到max size的时候，如何处理新任务
            // CALLER_RUNS：不在新线程中执行任务，而是有调用者所在的线程来执行
            executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
            executor.initialize();
            return executor;
    }

    @Bean(name = "webChatAsyncWorker")
    public Executor webChatAsyncWorker() {
        /** Set the ThreadPoolExecutor's core pool size. */
        int corePoolSize = 20;
        /** Set the ThreadPoolExecutor's maximum pool size. */
        int maxPoolSize = 250;
        /** Set the capacity for the ThreadPoolExecutor's BlockingQueue. */
        int queueCapacity = 15;
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("webChat-Async-Worker-");
        // rejection-policy：当pool已经达到max size的时候，如何处理新任务
        // CALLER_RUNS：不在新线程中执行任务，而是有调用者所在的线程来执行
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }


    @Bean
    public ThreadPoolTaskScheduler threadPoolTaskScheduler()
    {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(20);
        scheduler.setThreadNamePrefix("Scheduler-");
        scheduler.setAwaitTerminationSeconds(60);
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        scheduler.setErrorHandler(Throwable::printStackTrace);
        return scheduler;
    }



    @Bean
    public ClientHttpRequestFactory simpleClientHttpRequestFactory(){
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setReadTimeout(100000);//ms
        factory.setConnectTimeout(150000);//ms
        return factory;
    }

    @Bean
    public HttpUtil httpUtil(ClientHttpRequestFactory factory){
        HttpHeaders headersForm = new HttpHeaders();
        headersForm.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headersForm.add("Accept", MediaType.APPLICATION_FORM_URLENCODED_VALUE);
        HttpHeaders headersJson = new HttpHeaders();
        headersJson.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headersJson.add("Accept", MediaType.APPLICATION_JSON_UTF8_VALUE);
        RestTemplate restTemplate = new RestTemplate(factory);
        restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        return new HttpUtil(restTemplate,headersForm,headersJson);
    }


    @Bean
    public freemarker.template.Configuration configuration(){
        freemarker.template.Configuration   cfg =  new freemarker.template.Configuration(freemarker.template.Configuration.VERSION_2_3_27);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.DEBUG_HANDLER);
        return cfg;
    }

    @Value("${redis.address1}")
    private String REDIS_ADDRESS1;

    @Value("${redis.address2}")
    private String REDIS_ADDRESS2;

    @Value("${redis.address3}")
    private String REDIS_ADDRESS3;

    @Value("${redis.address4}")
    private String REDIS_ADDRESS4;

    @Value("${redis.address5}")
    private String REDIS_ADDRESS5;

    @Value("${redis.address6}")
    private String REDIS_ADDRESS6;

    @Value("${redis.password}")
    private String REDIS_PASSWORD;

    @Bean
    public JedisCluster jedisCluster(){

        GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        genericObjectPoolConfig.setMaxWaitMillis(-1);
        genericObjectPoolConfig.setMaxTotal(1000);
        genericObjectPoolConfig.setMinIdle(100);
        genericObjectPoolConfig.setMaxIdle(200);

        Set<HostAndPort> hostSet = new HashSet<>();
        hostSet.add(processRedisHost(REDIS_ADDRESS1));
        hostSet.add(processRedisHost(REDIS_ADDRESS2));
        hostSet.add(processRedisHost(REDIS_ADDRESS3));
        hostSet.add(processRedisHost(REDIS_ADDRESS4));
        hostSet.add(processRedisHost(REDIS_ADDRESS5));
        hostSet.add(processRedisHost(REDIS_ADDRESS6));
        return new JedisCluster(hostSet, 300000,300000, 6,REDIS_PASSWORD, genericObjectPoolConfig);
    }


    private HostAndPort processRedisHost(String host){
        String[] ipAndPort = host.split(":");
        return new HostAndPort(ipAndPort[0], Integer.parseInt(ipAndPort[1]));
    }


    @Value("${jdbc.driver}")
    private String JDBC_DRIVER;

    @Value("${jdbc.url}")
    private String JDBC_URL;

    @Value("${jdbc.user}")
    private String JDBC_USER;

    @Value("${jdbc.password}")
    private String JDBC_PASSWORD;

    @Bean
    public HikariDataSource dataSource(){
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(JDBC_DRIVER);
        dataSource.setJdbcUrl(JDBC_URL);
        dataSource.setUsername(JDBC_USER);
        dataSource.setPassword(JDBC_PASSWORD);
        dataSource.setMinimumIdle(10);
        dataSource.setMaximumPoolSize(100);
        return dataSource;
    }
}
