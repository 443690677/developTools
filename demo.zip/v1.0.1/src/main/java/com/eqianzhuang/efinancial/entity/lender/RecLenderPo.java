package com.eqianzhuang.efinancial.entity.lender;

/**
 * @author huangzhigang
 */
public class RecLenderPo {
	/** 用户openId */
	private String openId;
	/** 消息内容 */
	private String text;
	/** 产品组Id groupId */
	private String groupId;
	/** 是否精准筛选 1：是，2：否 */
	private String match;
	/** 产品显示条数 */
	private String num;

	public RecLenderPo() {
		super();
	}

	public RecLenderPo(String openId, String text, String groupId, String match, String num) {
		super();
		this.openId = openId;
		this.text = text;
		this.groupId = groupId;
		this.match = match;
		this.num = num;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getMatch() {
		return match;
	}

	public void setMatch(String match) {
		this.match = match;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

}
