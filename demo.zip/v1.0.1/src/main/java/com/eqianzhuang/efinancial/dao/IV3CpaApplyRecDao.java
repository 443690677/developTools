/*
 * 文件名：IV3CpaApplyRecDao.java
 * 版权：深圳融信信息咨询有限公司
 * 修改人：chengwenzhuo
 * 修改时间：@create_date 2017年8月3日 下午2:06:06
 * 修改内容：新增
 */
package com.eqianzhuang.efinancial.dao;


import java.util.Map;


/**
 * TODO 添加类的一句话简单描述。
 * <p>
 * TODO 详细描述
 * 
 * 
 * @author chengwenzhuo
 * @since 2.2.4
 * @create_date 2017年8月3日 下午2:06:06
 */
public interface IV3CpaApplyRecDao {

	long insertApplyRec(int bType,String businessId,String prodId,String createdBy,String updatedBy,String groupId,int nPriority,int status,String redirectUrl);

	void insertUserQualification(String amount,String name,String mobile,String mobile_des,String cityName,String cityId,String creditCard,String zhimaScore,String social_insurance,String publicFund,String ownCar,String ownHousing,String insurance,String insuranceFee ,String salary,String openid);

	Map<String,Object> selectUserQualification(String mobile);

	/**
	 * 判断当前用户今天是否已经记录分组
	 * @param lenderId 产品ID
	 * @param wxType 公众号类型
	 * @param openid 公众号openid
	 * @return true：没有记录，false：有记录
	 */
	boolean usersGroupBool(int lenderId,String openid);
	
	/**
	 * 查询当前最新的分组记录
	 * @param lenderId 产品ID
	 * @param wxType 公众号类型 
	 * @return groupNumberNew 
	 */
	String usersGroupRecordNew(int lenderId,String wxType);
	
	/**
	 * 新增用户产品分组记录
	 * @param lenderId 产品ID 
	 * @param openid 公众号openid
	 * @param wxType 公众号类型  
	 * @param groupNumber 分组编号
	 * @return 
	 */
	void insertUsersGroupRecord(int lenderId,String wxType,String openid,String groupNumber);
	
}
