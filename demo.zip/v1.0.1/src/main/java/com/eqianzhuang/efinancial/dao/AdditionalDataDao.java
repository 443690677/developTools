package com.eqianzhuang.efinancial.dao;

import java.util.Map;

public interface AdditionalDataDao {
    void add(String openid,int gender,String city,String reqUrl,String model,String brand,String userAgent,String ip,String os);

    void update(String openid,int gender,String city,String reqUrl,String model,String brand,String userAgent,String ip,String os);

    Map<String,Object> selectAdditionalDataByOpenId(String openId);
}
