package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class UserActionAuditDAOImpl implements UserActionAuditDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    WeChatConfig weChatConfig;

    @Override
    public void insert(String openid, int action) {

        jdbcTemplate.update("INSERT INTO credit_xyb.e_financial_user_action_audit " +
                "(openid, action, createdDate, createdBy) VALUES ( ?, ?,now(),?);",openid,action, weChatConfig.getMediaName(openid));
    }
}
