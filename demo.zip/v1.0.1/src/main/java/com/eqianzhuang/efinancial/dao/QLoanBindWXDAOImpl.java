package com.eqianzhuang.efinancial.dao;

import com.eqianzhuang.efinancial.ai.constant.WeChatConfig;
import com.eqianzhuang.efinancial.common.ValidUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;




/**
 * //TODO 添加类/接口功能描述
 * 
 * @author luduntao
 */
@Repository
public class QLoanBindWXDAOImpl implements QLoanBindWXDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    WeChatConfig weChatConfig;

    @Override
    public Map<String, Object> getByOpenId(String openId) {
        try {
            return jdbcTemplate.queryForMap("select * from credit_agency.v2_qloan_bindwx t where t.openId = ? limit 1;",openId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void insertQLoanBindWX(String openid, int media) {

        jdbcTemplate.update("insert into credit_agency.v2_qloan_bindwx(openId,createdBy,createdDate,updatedBy,updatedDate,media)" +
                "values( ?, ?,now(), ?, now(), ?);"  ,openid, weChatConfig.getMediaName(openid) , weChatConfig.getMediaName(openid),media);

    }

    @Override
    public void updateQloanBindWX(String openid, String name) {
        jdbcTemplate.update("update credit_agency.v2_qloan_bindwx set name= ? ,updatedBy=? , updatedDate = now() where openId=? ;",name , weChatConfig.getMediaName(openid) ,openid);
    }

    @Override
    public void updateQloanBindWX(String openid, String mobile, String mobile_des) {
        jdbcTemplate.update("update credit_agency.v2_qloan_bindwx set mobile= ?, mobile_des= ?, updatedBy=? , updatedDate = now() where openId=? ;",mobile ,mobile_des , weChatConfig.getMediaName(openid) ,openid);
    }

    @Override
    public void updateQloanBindWX(String openid, String wxType, int state) {
        if(state == 0)
        {
            jdbcTemplate.update("update credit_agency.v2_qloan_bindwx set  wxType=?, state=?, updatedBy=?,updatedDate = now() ,follow_time = now() where openId=? ;",wxType,state, weChatConfig.getMediaName(openid) ,openid);
        } else
        {
            jdbcTemplate.update("update credit_agency.v2_qloan_bindwx set  wxType=?, state=?, updatedBy=?,updatedDate = now() ,unfollow_time = now() where openId=? ;",wxType,state, weChatConfig.getMediaName(openid) ,openid);
        }
    }

    @Override
    public Map queryDMByMobileNumber(String mobileNumber) {
        if (ValidUtils.isNumeric(mobileNumber)&&mobileNumber.length() == 11 )
        {
            try {
                return jdbcTemplate.queryForMap("select * from credit_agency.v2_dm_mobile where MobileNumber=? limit 1;",mobileNumber.substring(0,7));
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return new HashMap();
    }

    @Override
    public Map selectCity(String cityName) {
        try {
            return jdbcTemplate.queryForMap("select id,name from credit_cpa.c_cities where level=2 and name like ? limit 1;","%"+cityName+"%");
        }catch (Exception e){
            e.printStackTrace();
        }
        return new HashMap();
    }

    @Override
    public String selectCityIdsByGroupID(Integer id) {
        try {
            return jdbcTemplate.queryForObject("SELECT a.cityIds FROM credit_cpa.v3_dispatchcityb_group a WHERE id=?;",String.class,id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }

    @Override
    public Integer selectDistributWait(int compId, String mobile) {
        try {
            return jdbcTemplate.queryForObject("SELECT count(a.id) FROM credit_cpa.v3_distribut_wait a WHERE a.compId=? AND a.mobile=? limit 1;" , Integer.class,compId,mobile);
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void insertDistributWait(int compId, String applyId, String mobile , String ruleId, String outChannel, String distributBGroupId, String mobile_des,String openid) {

        jdbcTemplate.update("insert into credit_cpa.v3_distribut_wait(compId,applyId,mobile,mobile_des,ruleId,outChannel,distributBGroupId,status,sendNum,createdBy,createdDate,updatedBy,updatedDate)" +
                " values(?,?,?,?,?,?,?,0,0,?,now(),?,now());",             compId,applyId,mobile,mobile_des,ruleId,outChannel,distributBGroupId, weChatConfig.getMediaName(openid), weChatConfig.getMediaName(openid))  ;
    }

}
