package com.eqianzhuang.efinancial.ai.controller.lender;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.eqianzhuang.efinancial.ai.service.lender.LenderService;

/**
 * 产品相关Controller
 * @author huangzhigang
 */
@RequestMapping(value = "/efinancial/ai")
@RestController
public class LenderController {

	@Autowired
	private LenderService lenderService;

	@RequestMapping(value = "/lender-rec",method = RequestMethod.POST,produces = { "application/json;charset=UTF-8" })
	public ResponseEntity<Map<String,Object>> recLender(@RequestBody JSONObject message, HttpServletRequest request){
		if (message == null) {
			HashMap<String,Object> map = new HashMap<>();
            map.put("code", "400");
            map.put("message","参数不正确");
            return new ResponseEntity<>(map,HttpStatus.BAD_REQUEST);
		}
		return lenderService.recLender(message);
	}
	
	
}
