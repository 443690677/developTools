/**
 * 
 */
/**
 * @author huangzhigang
 *
 */
package com.eqianzhuang.efinancial.entity.lender;