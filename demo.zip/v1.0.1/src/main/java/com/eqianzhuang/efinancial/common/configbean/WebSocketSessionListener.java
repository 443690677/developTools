package com.eqianzhuang.efinancial.common.configbean;

import com.eqianzhuang.efinancial.ai.service.AIProcessService;
import com.eqianzhuang.efinancial.dao.UserActionAuditDAO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.util.HashMap;

@Component
public class WebSocketSessionListener {

    private Log logger = LogFactory.getLog(this.getClass());

    private static HashMap<String,String> session = new HashMap<>();

    @Autowired
    AIProcessService aIProcessService;

    @Autowired
    UserActionAuditDAO userActionAuditDAO;

    @EventListener
    public void sessionEvent(SessionDisconnectEvent event) {

        Message<byte[]> message  = event.getMessage();
        String simpSessionId = (String) message.getHeaders().get("simpSessionId");
        String openid = session.get(simpSessionId);
        session.remove(simpSessionId);
        if ( openid != null && openid.length() == 28 ) {
            userActionAuditDAO.insert(openid,1);
        }
        logger.info("链接断开,openid= " + openid + ",simpSessionId="+simpSessionId);
    }

    @EventListener
    public void sessionEvent(SessionSubscribeEvent event) {
        Message<byte[]>  message  = event.getMessage();
        String simpSessionId = (String) message.getHeaders().get("simpSessionId");
        String simpDestination = (String) message.getHeaders().get("simpDestination");
        String openid = simpDestination.split("/")[2];
        session.put(simpSessionId,openid);
        aIProcessService.webChatGuide(openid);
        if ( openid != null && openid.length() == 28 ) {
            userActionAuditDAO.insert(openid,0);
        }
        logger.info("关注消息,openid= " + openid + ",simpSessionId="+simpSessionId);
    }

}
